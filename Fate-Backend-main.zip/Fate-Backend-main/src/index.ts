import { Hono } from "hono";
import Config from "./wrappers/Env.wrapper";
import Logger, { LogLevel } from "./utilities/logging";
import Database from "./wrappers/Database.wrapper";
import UserService from "./wrappers/database/UserService";
import { loadRoutes } from "./utilities/routing";
import path from "node:path";
import AccountService from "./wrappers/database/AccountService";
import TokensService from "./wrappers/database/TokensService";
import ProfilesService from "./wrappers/database/ProfilesService";
import HypeService from "./wrappers/database/HypeService";
import FriendsService from "./wrappers/database/FriendsService";
import { ItemStorageService } from "./wrappers/database/ItemStorageService";
import type { User } from "./tables/user";
import type { Account } from "./tables/account";
import { QuestManager } from "./utilities/managers/QuestManager";
import { cors } from "hono/cors";
import type PermissionInfo from "./utilities/permissions/permissioninfo";
import errors from "./utilities/errors";
import { QuestsService } from "./wrappers/database/QuestsService";
import ServersService from "./wrappers/database/ServersService";
import SessionsService from "./wrappers/database/SessionsService";
import ReceiptsService from "./wrappers/database/ReceiptsService";
import SeasonStatsService from "./wrappers/database/SeasonStatsService";
import DisplayAssetsService from "./wrappers/database/DisplayAssetsService";
import insertDisplayAssets from "./utilities/inserts/insertDisplayAssets";
import QuestRewardsService from "./wrappers/database/QuestRewardsService";
import insertQuestRewards from "./utilities/inserts/insertQuestRewards";
import LauncherUpdatesService from "./wrappers/database/LauncherUpdatesService";
import { ContentPageService } from "./wrappers/database/ContentPageService";
import MatchmakingService from "./wrappers/database/MatchmakingService";
import MatchmakingKeysService from "./wrappers/database/MatchmakingKeyService";
import ClientService from "./wrappers/database/ClientService";
import Matchmaker from "./modules/matchmaker/matchmaker";
import { WebSocketServer } from "ws";
import BanService from "./wrappers/database/BanService";
import HardwaresService from "./wrappers/database/HardwaresService";
import DeviceAuthService from "./wrappers/database/DeviceAuthService";
import {
  launcherWebSocketHandlers,
  upgradeLauncherWS,
} from "./utilities/launcher/ws";
import type { LauncherSocket } from "./utilities/launcher/sessions";

export type Variables = {
  user: User;
  account: Account;
  permission: PermissionInfo;
};

export const app = new Hono<{ Variables: Variables }>({ strict: false });
export const logger = new Logger(LogLevel.DEBUG);
export const config = new Config().getConfig();

app.use("*", cors());

app.notFound((c) =>
  c.json(
    errors.createError(
      404,
      c.req.url,
      "The specified route was not found.",
      new Date().toISOString(),
    ),
    404,
  ),
);

app.use(async (c, next) => {
  if (c.req.path === "/images/icons/gear.png" || c.req.path === "/favicon.ico") await next();
  else {
    await next();
    logger.info(`(${c.req.path}) ${c.req.method} : Status ${c.res.status}`);
  }
});

export const db = new Database({
  connectionString: config.databaseUrl,
});

export let userService: UserService;
export let accountService: AccountService;
export let tokensService: TokensService;
export let profilesService: ProfilesService;
export let hypeService: HypeService;
export let friendsService: FriendsService;
export let itemStorageService: ItemStorageService;
export let questsService: QuestsService;
export let serversService: ServersService;
export let sessionsService: SessionsService;
export let receiptsService: ReceiptsService;
export let seasonStatsService: SeasonStatsService;
export let displayAssetsService: DisplayAssetsService;
export let questRewardsService: QuestRewardsService;
export let launcherUpdatesService: LauncherUpdatesService;
export let contentPageService: ContentPageService;
export let matchmakingService: MatchmakingService;
export let matchmakingKeysService: MatchmakingKeysService;
export let clientService: ClientService;
export let banService: BanService;
export let hardwaresService: HardwaresService;
export let deviceAuthService: DeviceAuthService;
export let matchmaker: Matchmaker;

async function startDiscordBot() {
  try {
    await import("./modules/bot/deployment");
    await import("./modules/bot/bot");
    logger.info("Discord bot started.");
  } catch (error) {
    logger.error(`Discord bot startup failed: ${error}`);
  }
}

async function init() {
  await db.connect();

  logger.info("Initializing services...");
  userService = new UserService(db);
  accountService = new AccountService(db);
  tokensService = new TokensService(db);
  profilesService = new ProfilesService(db);
  hypeService = new HypeService(db);
  friendsService = new FriendsService(db);
  itemStorageService = new ItemStorageService(db);
  questsService = new QuestsService(db);
  serversService = new ServersService(db);
  sessionsService = new SessionsService(db);
  receiptsService = new ReceiptsService(db);
  seasonStatsService = new SeasonStatsService(db);
  displayAssetsService = new DisplayAssetsService(db);
  questRewardsService = new QuestRewardsService(db);
  launcherUpdatesService = new LauncherUpdatesService(db);
  contentPageService = new ContentPageService(db);
  matchmakingService = new MatchmakingService(db);
  matchmakingKeysService = new MatchmakingKeysService(db);
  clientService = new ClientService(db);
  banService = new BanService(db);
  hardwaresService = new HardwaresService(db);
  deviceAuthService = new DeviceAuthService(db);
  logger.info("Services initialized.");

  logger.info("Loading routes...");
  await loadRoutes(path.join(__dirname, "services", "routes"), app);
  logger.info("Routes loaded.");

  import("./modules/shop/rotate/autorotate");

  logger.info("Starting matchmaker...");
  const wss = new WebSocketServer({ port: 80 });
  matchmaker = new Matchmaker(wss, db, matchmakingService);
logger.info("mm started")

  logger.info("Initializing quests...");
  await QuestManager.initQuests();

  logger.info("Inserting display assets...");
  await insertDisplayAssets();
  logger.info("Inserting quest rewards...");
  await insertQuestRewards();

  Bun.serve<LauncherSocket>({
    port: config.port,
    fetch(request, server) {
      const url = new URL(request.url);
      if (url.pathname.replace(/\/+$/, "") === "/launcher-ws") {
        return upgradeLauncherWS(request, server);
      }

      return app.fetch(request, undefined);
    },
    websocket: launcherWebSocketHandlers,
  });

  logger.startup(`Running on port ${config.port}`);
  logger.info(`Launcher WebSocket mounted on port ${config.port} at /launcher-ws.`);
  await startDiscordBot();
}

init().catch((err) => {
  logger.error(`Fatal startup error: ${err}`);
  process.exit(1);
});
