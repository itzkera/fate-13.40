import { Command } from "../../handlers/Command";
import {
  ApplicationCommandOptionType,
  ChatInputCommandInteraction,
  Client,
  EmbedBuilder,
} from "discord.js";
import { accountService, logger, profilesService, userService } from "../../../..";
import { User } from "../../../../tables/user";
import { handleProfileSelection } from "../../../../utilities/profile_cache";

export default class BanCommand extends Command {
  constructor(client: Client) {
    super(client, {
      name: "ban",
      description: "Ban or unban a user.",
      options: [
        {
          name: "ban",
          type: ApplicationCommandOptionType.Subcommand,
          description: "Ban a user.",
          options: [
            {
              name: "user",
              type: ApplicationCommandOptionType.User,
              description: "The user you want to ban.",
              required: true,
            },
            {
              name: "reason",
              type: ApplicationCommandOptionType.String,
              description: "The reason you want to ban the user for.",
              choices: [
                {
                  name: "Exploiting",
                  value: "Exploiting",
                },
                {
                  name: "Teaming",
                  value: "Teaming",
                },
              ],
              required: true,
            },
            {
              name: "duration",
              description: "The duration you want to ban the user for.",
              type: ApplicationCommandOptionType.String,
              choices: [
                {
                  name: "24 Hours",
                  value: "1",
                },
                {
                  name: "3 Days",
                  value: "3",
                },
                {
                  name: "7 Days",
                  value: "7",
                },
                {
                  name: "14 Days",
                  value: "14",
                },
                {
                  name: "30 Days",
                  value: "30",
                },
                {
                  name: "90 Days",
                  value: "90",
                },
                {
                  name: "Permanent",
                  value: "91",
                },
              ],
              required: true,
            },
          ],
        },
        {
          name: "unban",
          type: ApplicationCommandOptionType.Subcommand,
          description: "Unban a user.",
          options: [
            {
              name: "user",
              type: ApplicationCommandOptionType.User,
              description: "The user you want to unban.",
              required: true,
            },
          ],
        },
      ],
      permissions: ["BanMembers"],
    });
  }

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    await interaction.deferReply({ ephemeral: true });

    const subcommand = interaction.options.getSubcommand();
    const iconURL = interaction.user.avatarURL()!;

    if (!interaction.memberPermissions!.has("BanMembers")) {
      const embed = new EmbedBuilder()
        .setTitle("Missing permissions")
        .setDescription("You do not have the required permissions to run this command.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    if (subcommand === "ban") {
      await this.handleBan(interaction, iconURL);
    } else if (subcommand === "unban") {
      await this.handleUnban(interaction, iconURL);
    }
  }

  private async handleBan(
    interaction: ChatInputCommandInteraction,
    iconURL: string,
  ): Promise<void> {
    const discordUser = interaction.options.getUser("user");
    const reason = interaction.options.getString("reason");
    const duration = interaction.options.getString("duration");

    if (!discordUser) {
      const embed = new EmbedBuilder()
        .setTitle("Invalid user")
        .setDescription("Invalid user provided.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    const user = await userService.findUserByDiscordId(discordUser.id);

    if (!user) {
      const embed = new EmbedBuilder()
        .setTitle("User not found")
        .setDescription("The user you provided could not be found.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    const account = await accountService.findUserByDiscordId(discordUser.id);

    if (!account) {
      const embed = new EmbedBuilder()
        .setTitle("Account not found")
        .setDescription("The account you provided could not be found.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    if (user.banned) {
      const embed = new EmbedBuilder()
        .setTitle("User already banned")
        .setDescription("The user you provided is already banned.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    const common_core = await handleProfileSelection("common_core", user.accountId);
    if (!common_core) {
      const embed = new EmbedBuilder()
        .setTitle("Profile not found")
        .setDescription("Profile 'common_core' could not be found.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    if (!reason) {
      const embed = new EmbedBuilder()
        .setTitle("Invalid reason")
        .setDescription("Invalid reason provided.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    if (!duration) {
      const embed = new EmbedBuilder()
        .setTitle("Invalid duration")
        .setDescription("Invalid duration provided.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    const durationNum = parseInt(duration);
    if (isNaN(durationNum)) {
      const embed = new EmbedBuilder()
        .setTitle("Invalid duration")
        .setDescription("Invalid duration provided.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    common_core.stats.attributes.ban_status!.banReasons.push(reason);
    common_core.stats.attributes.ban_status!.bRequiresUserAck = true;
    common_core.stats.attributes.ban_status!.bBanHasStarted = true;

    const durationMap: { [key: string]: number } = {
      "1": 1.0,
      "3": 3.0,
      "7": 7.0,
      "14": 14.0,
      "30": 30.0,
      "90": 90.0,
    };

    try {
      if (durationMap.hasOwnProperty(duration)) {
        common_core.stats.attributes.ban_status!.banDurationDays = durationMap[duration];
      } else if (duration === "91") {
        await User.createQueryBuilder()
          .update(User)
          .set({ banned: true })
          .where("accountId = :accountId", { accountId: user.accountId })
          .execute();
      }

      common_core.stats.attributes.ban_history!.banCount![reason] =
        (common_core.stats.attributes.ban_history!.banCount![reason] || 0) + 1;

      await profilesService.createOrUpdate(user.accountId, "common_core", common_core);

      const embed = new EmbedBuilder()
        .setTitle("User Successfully Banned")
        .setDescription(
          `Successfully banned user ${user.username} for ${
            duration === "91" ? "permanently" : `${duration} day(s)`
          }.`,
        )
        .addFields(
          { name: "Reason", value: reason, inline: true },
          {
            name: "Duration",
            value: duration === "91" ? "Permanent" : `${duration} day(s)`,
            inline: true,
          },
        )
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });

      try {
        const userEmbed = new EmbedBuilder()
          .setTitle("You have been banned.")
          .setDescription(`You have been banned from the service.`)
          .addFields(
            { name: "Reason", value: reason, inline: true },
            {
              name: "Duration",
              value: duration === "91" ? "Permanent" : `${duration} day(s)`,
              inline: true,
            },
          )
          .setColor("Red")
          .setTimestamp();

        await discordUser.send({ embeds: [userEmbed] });
      } catch (dmError) {
        logger.warn(`Could not send DM to ${discordUser.username}: ${dmError}`);
      }
    } catch (error) {
      logger.error(`Error banning user: ${error}`);
      const embed = new EmbedBuilder()
        .setTitle("Error banning user")
        .setDescription("There was an error banning the user.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
    }
  }

  private async handleUnban(
    interaction: ChatInputCommandInteraction,
    iconURL: string,
  ): Promise<void> {
    const discordUser = interaction.options.getUser("user");

    if (!discordUser) {
      const embed = new EmbedBuilder()
        .setTitle("Invalid user")
        .setDescription("Invalid user provided.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    const user = await userService.findUserByDiscordId(discordUser.id);

    if (!user) {
      const embed = new EmbedBuilder()
        .setTitle("User not found")
        .setDescription("The user you provided could not be found.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    const account = await accountService.findUserByDiscordId(discordUser.id);

    if (!account) {
      const embed = new EmbedBuilder()
        .setTitle("Account not found")
        .setDescription("The account you provided could not be found.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    let common_core = await handleProfileSelection("common_core", user.accountId);
    if (!common_core) {
      const embed = new EmbedBuilder()
        .setTitle("Profile not found")
        .setDescription("Profile 'common_core' could not be found.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    try {
      if (!common_core.stats.attributes.ban_status) {
        const embed = new EmbedBuilder()
          .setTitle("User Not Banned")
          .setDescription(`User ${user.username} is not currently banned.`)
          .setColor("Yellow")
          .setTimestamp()
          .setAuthor({ name: interaction.user.username, iconURL });

        await interaction.editReply({ embeds: [embed] });
        return;
      }

      const banStatus = common_core.stats.attributes.ban_status;

      banStatus.bRequiresUserAck = false;
      banStatus.bBanHasStarted = false;
      banStatus.banReasons = [];
      banStatus.banDurationDays = 0;

      if (user.banned) {
        await User.createQueryBuilder()
          .update(User)
          .set({ banned: false })
          .where("accountId = :accountId", { accountId: user.accountId })
          .execute();
      }

      await profilesService.update(user.accountId, "common_core", common_core);

      const embed = new EmbedBuilder()
        .setTitle("User Successfully Unbanned")
        .setDescription(`Successfully unbanned user ${user.username}.`)
        .setColor("Green")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });

      try {
        const userEmbed = new EmbedBuilder()
          .setTitle("You have been unbanned.")
          .setDescription("Your ban has been lifted. You can now access the service again.")
          .setColor("Green")
          .setTimestamp();

        await discordUser.send({ embeds: [userEmbed] });
      } catch (dmError) {
        logger.warn(`Could not send DM to ${discordUser.username}: ${dmError}`);
      }
    } catch (error) {
      logger.error(`Error unbanning user: ${error}`);
      const embed = new EmbedBuilder()
        .setTitle("Error unbanning user")
        .setDescription("There was an error unbanning the user.")
        .setColor("Red")
        .setTimestamp()
        .setAuthor({ name: interaction.user.username, iconURL });

      await interaction.editReply({ embeds: [embed] });
    }
  }
}
