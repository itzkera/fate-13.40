import {
  ApplicationCommandOptionType,
  CommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
  type CacheType,
  type ColorResolvable,
} from "discord.js";
import { Command } from "../../handlers/Command";
import { accountService, profilesService, userService } from "../../../..";
import path from "node:path";
import { User } from "../../../../tables/user";
import RefreshAccount from "../../../../utilities/refresh";
import ProfileHelper from "../../../../utilities/profiles";

export default class ClearLockerCommand extends Command {
  constructor(client: any) {
    super(client, {
      name: "clearlocker",
      description: "Clears a users locker.",
      options: [
        {
          name: "user",
          type: ApplicationCommandOptionType.User,
          description: "The user you want to clear.",
          required: true,
        },
      ],
      permissions: [PermissionFlagsBits.BanMembers],
    });
  }

  async execute(interaction: CommandInteraction<CacheType>): Promise<any> {
    if (!interaction.memberPermissions?.has("BanMembers")) {
      return await interaction.reply({
        content: "You do not have permission to use this command.",
        ephemeral: true,
      });
    }

    await interaction.deferReply({ ephemeral: true });
    const user_data = await interaction.options.get("user", true);
    const user = await userService.findUserByDiscordId(user_data.user?.id as string);

    if (!user) {
      return await this.sendEmbed(
        interaction,
        "User not found.",
        "Failed to find user, please try again.",
        "Red",
      );
    }

    const account = await accountService.findUserByDiscordId(user.discordId);
    if (!account) {
      return await this.sendEmbed(
        interaction,
        "Account not found.",
        "Failed to find account, please try again.",
        "Red",
      );
    }

    if (user.banned) {
      return await this.sendEmbed(interaction, "User is Banned", "This user is banned.", "Red");
    }

    const athena = await ProfileHelper.getProfile(user.accountId, "athena");
    if (!athena) {
      return await this.sendEmbed(
        interaction,
        "Profile not found",
        "The profile 'athena' was not found.",
        "Red",
      );
    }

    try {
      const defaultItems = require(path.join(__dirname, "..", "..", "..", "memory", "athena.json"));
      athena.items = defaultItems.items;

      await profilesService.update(user.accountId, "athena", athena);

      await User.createQueryBuilder()
        .update(User)
        .set({ has_all_items: false })
        .where("accountId = :accountId", { accountId: user.accountId })
        .execute();

      await RefreshAccount(user.accountId, user.username);

      const embed = new EmbedBuilder()
        .setTitle("Success")
        .setDescription(`Successfully cleared locker for ${user_data.user?.username}'s account.`)
        .setColor("Blurple")
        .setTimestamp();

      return await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      return await interaction.reply({
        content: "Failed to clear locker. Please try again later.",
        ephemeral: true,
      });
    }
  }

  private async sendEmbed(
    interaction: CommandInteraction<CacheType>,
    title: string,
    description: string,
    color: ColorResolvable,
  ) {
    const embed = new EmbedBuilder()
      .setTitle(title)
      .setDescription(description)
      .setColor(color)
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  }
}
