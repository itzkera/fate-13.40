import {
  ApplicationCommandOptionType,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
  type ColorResolvable,
} from "discord.js";
import { Command } from "../../handlers/Command";

export default class GrantAllCommand extends Command {
  constructor(client: any) {
    super(client, {
      name: "grantall",
      description: "Grants a user all cosmetics.",
      options: [
        {
          name: "user",
          type: ApplicationCommandOptionType.User,
          description: "The user you want to grant all items to.",
          required: true,
        },
      ],
      permissions: [PermissionFlagsBits.BanMembers],
    });
  }

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.BanMembers)) {
      await interaction.reply({
        content: "You do not have permission to use this command.",
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      const { accountService, logger, profilesService, userService } = await import("../../../..");
      const path = await import("node:path");
      const { User } = await import("../../../../tables/user");
      const RefreshAccount = (await import("../../../../utilities/refresh")).default;
      const ProfileHelper = (await import("../../../../utilities/profiles")).default;

      const user_data = interaction.options.getUser("user", true);
      const user = await userService.findUserByDiscordId(user_data.id);

      if (!user) {
        return await this.sendEmbed(
          interaction,
          "User not found.",
          "Failed to find user, please try again.",
          "Red",
        );
      }

      const account = await accountService.findUserByDiscordId(user.discordId);
      if (!account) {
        return await this.sendEmbed(
          interaction,
          "Account not found.",
          "Failed to find account, please try again.",
          "Red",
        );
      }

      if (user.banned) {
        return await this.sendEmbed(interaction, "User is Banned", "This user is banned.", "Red");
      }

      if (user.has_all_items) {
        return await this.sendEmbed(
          interaction,
          "Already has full locker.",
          "This user already has full locker.",
          "Red",
        );
      }

      const athena = await ProfileHelper.getProfile(user.accountId, "athena");
      if (!athena) {
        return await this.sendEmbed(
          interaction,
          "Profile not found",
          "The profile 'athena' was not found.",
          "Red",
        );
      }

      const allItems = require(path.default.join(
        __dirname,
        "..",
        "..",
        "..",
        "..",
        "memory",
        "all.json",
      ));
      athena.items = { ...athena.items, ...allItems };
      athena.rvn++;
      athena.commandRevision++;
      athena.updatedAt = new Date().toISOString();

      await profilesService.update(user.accountId, "athena", athena);

      const common_core = await ProfileHelper.getProfile(user.accountId, "common_core");
      if (common_core) {
        if (!common_core.items) common_core.items = {};
        const purchaseId = crypto.randomUUID();
        const lootList = Object.entries(allItems as Record<string, any>).map(([, item]) => ({
          itemType: item.templateId,
          itemGuid: item.templateId,
          quantity: 1,
        }));

        common_core.items[purchaseId] = {
          templateId: "GiftBox:GB_MakeGood",
          attributes: {
            fromAccountId: "",
            lootList,
            params: {
              userMessage: "Thanks for supporting Lexa!",
            },
            giftedOn: new Date().toISOString(),
          },
          quantity: 1,
        };

        common_core.rvn++;
        common_core.commandRevision++;
        common_core.updatedAt = new Date().toISOString();

        await profilesService.update(user.accountId, "common_core", common_core);
      }

      await User.createQueryBuilder()
        .update(User)
        .set({ has_all_items: true })
        .where("accountId = :accountId", { accountId: user.accountId })
        .execute();

      await RefreshAccount(user.accountId, user.username);

      const embed = new EmbedBuilder()
        .setTitle("Success")
        .setDescription(`Successfully granted all items to ${user_data.username}'s account.`)
        .setColor("Blurple")
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("Error granting all items:", error);

      const embed = new EmbedBuilder()
        .setTitle("Error")
        .setDescription("Failed to grant all items. Please try again later.")
        .setColor("Red")
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    }
  }

  private async sendEmbed(
    interaction: ChatInputCommandInteraction,
    title: string,
    description: string,
    color: ColorResolvable,
  ): Promise<void> {
    const embed = new EmbedBuilder()
      .setTitle(title)
      .setDescription(description)
      .setColor(color)
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  }
}
