import {
  ApplicationCommandOptionType,
  ChatInputCommandInteraction,
  Client,
  EmbedBuilder,
} from "discord.js";
import { Command } from "../../handlers/Command";
import { logger, matchmakingKeysService, matchmakingService } from "../../../..";

export default class MatchmakingCommand extends Command {
  private readonly DEFAULT_PORT = 7777;
  private readonly RESERVED_KEYS = ["clear"];

  constructor(client: Client) {
    super(client, {
      name: "matchmaking",
      description: "Manage custom matchmaking keys and server hosting.",
      options: [
        {
          name: "create",
          type: ApplicationCommandOptionType.Subcommand,
          description: "Create a custom matchmaking key for a gameserver.",
          options: [
            {
              name: "key",
              type: ApplicationCommandOptionType.String,
              description: "The custom key players can use (case-sensitive)",
              required: true,
            },
            {
              name: "address",
              type: ApplicationCommandOptionType.String,
              description: "A public IP or domain",
              required: true,
            },
            {
              name: "port",
              type: ApplicationCommandOptionType.String,
              description: "Port number (default: 7777)",
              required: false,
            },
          ],
        },
        {
          name: "delete",
          type: ApplicationCommandOptionType.Subcommand,
          description: "Delete an existing matchmaking key.",
          options: [
            {
              name: "key",
              type: ApplicationCommandOptionType.String,
              description: "The matchmaking key to delete (case-sensitive)",
              required: true,
            },
          ],
        },
        {
          name: "set",
          type: ApplicationCommandOptionType.Subcommand,
          description: "Set your current matchmaking key.",
          options: [
            {
              name: "key",
              type: ApplicationCommandOptionType.String,
              description: "The matchmaking key to set (case-sensitive)",
              required: true,
            },
          ],
        },
        {
          name: "check",
          type: ApplicationCommandOptionType.Subcommand,
          description: "Check your current matchmaking key.",
        },
        {
          name: "clear",
          type: ApplicationCommandOptionType.Subcommand,
          description: "Clear your current matchmaking key.",
        },
        {
          name: "host",
          type: ApplicationCommandOptionType.Subcommand,
          description: "Set your IP and port for hosting.",
          options: [
            {
              name: "address",
              type: ApplicationCommandOptionType.String,
              description: "A public IP or domain",
              required: true,
            },
            {
              name: "port",
              type: ApplicationCommandOptionType.String,
              description: "Port number (default: 7777)",
              required: false,
            },
          ],
        },
        {
          name: "list",
          type: ApplicationCommandOptionType.Subcommand,
          description: "List all available matchmaking keys.",
        },
      ],
      permissions: ["Administrator"],
    });
  }

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    await interaction.deferReply({ ephemeral: true });

    const subcommand = interaction.options.getSubcommand();
    const iconURL = interaction.user.avatarURL() || undefined;

    try {
      switch (subcommand) {
        case "create":
          await this.handleCreate(interaction, iconURL);
          break;
        case "delete":
          await this.handleDelete(interaction, iconURL);
          break;
        case "set":
          await this.handleSet(interaction, iconURL);
          break;
        case "check":
          await this.handleCheck(interaction, iconURL);
          break;
        case "clear":
          await this.handleClear(interaction, iconURL);
          break;
        case "list":
          await this.handleList(interaction, iconURL);
          break;
        default:
          await this.sendErrorEmbed(
            interaction,
            "Invalid Subcommand",
            "The subcommand you provided is not valid.",
            iconURL,
          );
      }
    } catch (error) {
      logger.error(`Matchmaking command error: ${error}`);
      await this.sendErrorEmbed(
        interaction,
        "Command Error",
        "An unexpected error occurred while processing your request.",
        iconURL,
      );
    }
  }

  private async handleCreate(
    interaction: ChatInputCommandInteraction,
    iconURL?: string,
  ): Promise<void> {
    if (!this.hasAdminPermission(interaction)) {
      await this.sendPermissionError(interaction, iconURL);
      return;
    }

    const key = interaction.options.getString("key", true);
    let address = interaction.options.getString("address", true);
    let port = interaction.options.getString("port") || String(this.DEFAULT_PORT);

    if (this.RESERVED_KEYS.includes(key.toLowerCase())) {
      await this.sendErrorEmbed(
        interaction,
        "Invalid Key",
        `The key \`${key}\` is reserved and cannot be created.`,
        iconURL,
      );
      return;
    }

    if (address.includes(":")) {
      const parts = address.split(":");
      address = parts[0];
      port = parts[1];
    }

    const portNum = parseInt(port, 10);
    if (isNaN(portNum) || portNum < 1 || portNum > 65535) {
      await this.sendErrorEmbed(
        interaction,
        "Invalid Port",
        "Port must be a number between 1 and 65535.",
        iconURL,
      );
      return;
    }

    const existingKey = await matchmakingService.findByKey(key);
    if (existingKey) {
      await this.sendErrorEmbed(
        interaction,
        "Key Exists",
        `The matchmaking key \`${key}\` already exists.`,
        iconURL,
      );
      return;
    }

    await matchmakingService.create({
      key,
      address,
      port: portNum,
    });

    const embed = new EmbedBuilder()
      .setTitle("Matchmaking Key Created")
      .setDescription(
        `Successfully created matchmaking key \`${key}\`\n\n` +
          `**Address:** ${address}\n` +
          `**Port:** ${portNum}`,
      )
      .setColor("Green")
      .setTimestamp()
      .setAuthor({ name: interaction.user.username, iconURL });

    await interaction.editReply({ embeds: [embed] });
  }

  private async handleDelete(
    interaction: ChatInputCommandInteraction,
    iconURL?: string,
  ): Promise<void> {
    if (!this.hasAdminPermission(interaction)) {
      await this.sendPermissionError(interaction, iconURL);
      return;
    }

    const key = interaction.options.getString("key", true);

    const existingKey = await matchmakingService.findByKey(key);
    if (!existingKey) {
      await this.sendErrorEmbed(
        interaction,
        "Key Not Found",
        `No matchmaking key found with the value \`${key}\`.`,
        iconURL,
      );
      return;
    }

    await matchmakingService.delete(existingKey.id);

    const embed = new EmbedBuilder()
      .setTitle("Matchmaking Key Deleted")
      .setDescription(`Successfully deleted matchmaking key \`${key}\`.`)
      .setColor("Green")
      .setTimestamp()
      .setAuthor({ name: interaction.user.username, iconURL });

    await interaction.editReply({ embeds: [embed] });
  }

  private async handleSet(
    interaction: ChatInputCommandInteraction,
    iconURL?: string,
  ): Promise<void> {
    const key = interaction.options.getString("key", true);

    const existingKey = await matchmakingService.findByKey(key);
    if (!existingKey) {
      await this.sendErrorEmbed(
        interaction,
        "Key Not Found",
        `No matchmaking key \`${key}\` was found.`,
        iconURL,
      );
      return;
    }

    const storedKey = await matchmakingKeysService.findByInteraction(interaction.user.id);

    if (!storedKey) {
      await matchmakingKeysService.create({
        interaction: interaction.user.id,
        key: key,
      });
    } else {
      await matchmakingKeysService.update(storedKey.id, { key });
    }

    const embed = new EmbedBuilder()
      .setTitle("Matchmaking Key Set")
      .setDescription(
        `Your matchmaking key has been set to \`${key}\`\n\n` +
          `**Server:** ${existingKey.address}:${existingKey.port}`,
      )
      .setColor("Green")
      .setTimestamp()
      .setAuthor({ name: interaction.user.username, iconURL });

    await interaction.editReply({ embeds: [embed] });
  }

  private async handleCheck(
    interaction: ChatInputCommandInteraction,
    iconURL?: string,
  ): Promise<void> {
    const userKey = await matchmakingKeysService.findByInteraction(interaction.user.id);

    if (!userKey) {
      await this.sendErrorEmbed(
        interaction,
        "No Key Set",
        "You do not have a matchmaking key set.",
        iconURL,
      );
      return;
    }

    const keyData = await matchmakingService.findByKey(userKey.key);
    const description = keyData
      ? `Your current matchmaking key is \`${userKey.key}\`\n\n` +
        `**Server:** ${keyData.address}:${keyData.port}`
      : `Your current matchmaking key is \`${userKey.key}\`\n\n` +
        `⚠️ Warning: This key no longer exists in the database.`;

    const embed = new EmbedBuilder()
      .setTitle("Current Matchmaking Key")
      .setDescription(description)
      .setColor(keyData ? "Green" : "Yellow")
      .setTimestamp()
      .setAuthor({ name: interaction.user.username, iconURL });

    await interaction.editReply({ embeds: [embed] });
  }

  private async handleClear(
    interaction: ChatInputCommandInteraction,
    iconURL?: string,
  ): Promise<void> {
    const userKey = await matchmakingKeysService.findByInteraction(interaction.user.id);

    if (!userKey) {
      await this.sendErrorEmbed(
        interaction,
        "No Key Set",
        "You do not have a matchmaking key to clear.",
        iconURL,
      );
      return;
    }

    await matchmakingKeysService.delete(userKey.id);

    const embed = new EmbedBuilder()
      .setTitle("Matchmaking Key Cleared")
      .setDescription("Your matchmaking key has been cleared successfully.")
      .setColor("Green")
      .setTimestamp()
      .setAuthor({ name: interaction.user.username, iconURL });

    await interaction.editReply({ embeds: [embed] });
  }

  private async handleList(
    interaction: ChatInputCommandInteraction,
    iconURL?: string,
  ): Promise<void> {
    const keys = await matchmakingService.findAll();

    if (keys.length === 0) {
      await this.sendErrorEmbed(
        interaction,
        "No Keys Found",
        "There are currently no matchmaking keys available.",
        iconURL,
      );
      return;
    }

    const keyList = keys
      .map((k, index) => `**${index + 1}.** \`${k.key}\` - ${k.address}:${k.port}`)
      .join("\n");

    const embed = new EmbedBuilder()
      .setTitle("Available Matchmaking Keys")
      .setDescription(keyList)
      .setColor("Blue")
      .setFooter({ text: `Total: ${keys.length} key(s)` })
      .setTimestamp()
      .setAuthor({ name: interaction.user.username, iconURL });

    await interaction.editReply({ embeds: [embed] });
  }

  private hasAdminPermission(interaction: ChatInputCommandInteraction): boolean {
    return interaction.memberPermissions?.has("Administrator") ?? false;
  }

  private async sendPermissionError(
    interaction: ChatInputCommandInteraction,
    iconURL?: string,
  ): Promise<void> {
    await this.sendErrorEmbed(
      interaction,
      "Missing Permissions",
      "You do not have the required permissions to use this command.",
      iconURL,
    );
  }

  private async sendErrorEmbed(
    interaction: ChatInputCommandInteraction,
    title: string,
    description: string,
    iconURL?: string,
  ): Promise<void> {
    const embed = new EmbedBuilder()
      .setTitle(title)
      .setDescription(description)
      .setColor("Red")
      .setTimestamp()
      .setAuthor({ name: interaction.user.username, iconURL });

    await interaction.editReply({ embeds: [embed] });
  }
}
