import {
  EmbedBuilder,
  type CacheType,
  CommandInteraction,
  ApplicationCommandOptionType,
} from "discord.js";
import { Command } from "../../handlers/Command";
import { accountService, logger, userService } from "../../../..";
import type { Abilities, AbilitiesCombination } from "../../../../../types/permissionsdefs";
import { getRandomAction } from "../../../../utilities/getRandomAction";

export default class PermissionCommand extends Command {
  constructor(client: any) {
    super(client, {
      name: "permission",
      description: "Manage permissions for a user's account",
      options: [
        {
          type: ApplicationCommandOptionType.Subcommand,
          name: "add",
          description: "Add a permission to a user's account",
          options: [
            {
              type: ApplicationCommandOptionType.User,
              name: "user",
              description: "The user to add permission to",
              required: true,
            },
            {
              type: ApplicationCommandOptionType.String,
              name: "permission",
              description: "The permission to add",
              required: true,
            },
            {
              type: ApplicationCommandOptionType.String,
              name: "abilities",
              description: "The abilities to assign.",
              choices: [
                { name: "READ", value: "READ" },
                { name: "DELETE", value: "DELETE" },
                { name: "LIST", value: "LIST" },
                { name: "CREATE", value: "CREATE" },
                { name: "*", value: "*" },
              ],
              required: true,
            },
          ],
        },
        {
          type: ApplicationCommandOptionType.Subcommand,
          name: "delete",
          description: "Delete a permission from a user's account",
          options: [
            {
              type: ApplicationCommandOptionType.User,
              name: "user",
              description: "The user to remove permission from",
              required: true,
            },
            {
              type: ApplicationCommandOptionType.String,
              name: "permission",
              description: "The permission to remove",
              required: true,
            },
            {
              type: ApplicationCommandOptionType.String,
              name: "abilities",
              description: "The abilities to assign.",
              choices: [
                { name: "READ", value: "READ" },
                { name: "DELETE", value: "DELETE" },
                { name: "LIST", value: "LIST" },
                { name: "CREATE", value: "CREATE" },
                { name: "*", value: "*" },
              ],
              required: true,
            },
          ],
        },
      ],
    });
  }

  async execute(interaction: CommandInteraction<CacheType>): Promise<any> {
    await interaction.deferReply({ ephemeral: false });

    const subcommand = interaction.options.data[0]?.name;

    if (!subcommand) {
      const embed = new EmbedBuilder()
        .setTitle("Subcommand Not Found.")
        .setDescription("Failed to find subcommand.")
        .setColor("Red")
        .setTimestamp();

      return await interaction.editReply({ embeds: [embed] });
    }

    const action = getRandomAction();

    try {
      if (subcommand === "add") {
        const discord = interaction.options.get("user", true);
        const permission = interaction.options.get("permission", true);
        const abilitiesSub = interaction.options.get("abilities", true);

        const abilities = abilitiesSub.value as Abilities | AbilitiesCombination;

        const account = await accountService.findUserByDiscordId(discord.user!.id);
        const user = await userService.findUserByDiscordId(discord.user!.id);
        if (!account || !user) {
          const embed = new EmbedBuilder()
            .setTitle("User Not Found")
            .setDescription("Failed to find user, please try again.")
            .setColor("Red")
            .setTimestamp();
          return await interaction.editReply({ embeds: [embed] });
        }

        const success = await this.addPermissionDirectly(
          account.accountId,
          permission.value as string,
          abilities,
          action,
        );

        const embed = new EmbedBuilder()
          .setTitle(success ? "✅ Permission Added" : "❌ Failed to Add Permission")
          .setDescription(
            `Permission "${permission.value}" with abilities "${abilities}" was ${
              success ? "successfully added" : "not added"
            }.`,
          )
          .setColor(success ? "Green" : "Red")
          .setTimestamp();
        return await interaction.editReply({ embeds: [embed] });
      } else if (subcommand === "delete") {
        const discord = interaction.options.get("user", true);
        const permission = interaction.options.get("permission", true);

        const account = await accountService.findUserByDiscordId(discord.user!.id);
        const user = await userService.findUserByDiscordId(discord.user!.id);
        if (!account || !user) {
          const embed = new EmbedBuilder()
            .setTitle("User Not Found")
            .setDescription("Failed to find user, please try again.")
            .setColor("Red")
            .setTimestamp();
          return await interaction.editReply({ embeds: [embed] });
        }

        const success = await this.removePermissionDirectly(
          account.accountId,
          permission.value as string,
        );

        const embed = new EmbedBuilder()
          .setTitle(success ? "✅ Permission Removed" : "❌ Failed to Remove Permission")
          .setDescription(
            `Permission "${permission.value}" was ${
              success ? "successfully removed" : "not removed"
            }.`,
          )
          .setColor(success ? "Green" : "Red")
          .setTimestamp();
        return await interaction.editReply({ embeds: [embed] });
      } else {
        const embed = new EmbedBuilder()
          .setTitle("Unknown Command")
          .setDescription("The specified command is not recognized.")
          .setColor("Red")
          .setTimestamp();
        return await interaction.editReply({ embeds: [embed] });
      }
    } catch (error) {
      logger.error(`Failed to handle permission: ${error}`);
      const embed = new EmbedBuilder()
        .setTitle("Internal Server Error")
        .setDescription("An internal server error has occurred.")
        .setColor("Red")
        .setTimestamp();
      return await interaction.editReply({ embeds: [embed] });
    }
  }

  private async addPermissionDirectly(
    accountId: string,
    resource: string,
    abilities: Abilities | AbilitiesCombination,
    action: number,
  ): Promise<boolean> {
    try {
      const account = await accountService.findUserByAccountId(accountId);
      if (!account) return false;

      const existingPermissions = account.permissions || [];
      const newPermission = { resource, abilities, action };

      const permissionExists = existingPermissions.some(
        (p: any) => p.resource === resource && p.abilities === abilities,
      );

      if (permissionExists) return true;
      const updatedPermissions = [...existingPermissions, newPermission];
      await accountService.updateAccount(accountId, { permissions: updatedPermissions });
      return true;
    } catch (error) {
      logger.error(`Error adding permission: ${error}`);
      return false;
    }
  }

  private async removePermissionDirectly(accountId: string, resource: string): Promise<boolean> {
    try {
      const account = await accountService.findUserByAccountId(accountId);
      if (!account) return false;

      const existingPermissions = account.permissions || [];
      const updatedPermissions = existingPermissions.filter((p: any) => p.resource !== resource);

      await accountService.updateAccount(accountId, { permissions: updatedPermissions });
      return true;
    } catch (error) {
      logger.error(`Error removing permission: ${error}`);
      return false;
    }
  }
}
