import { ChatInputCommandInteraction, PermissionFlagsBits, EmbedBuilder } from "discord.js";
import { Command } from "../../handlers/Command";

export default class RotateCommand extends Command {
  constructor(client: any) {
    super(client, {
      name: "rotate",
      description: "Rotates the item shop.",
      options: [],
      permissions: [PermissionFlagsBits.BanMembers],
    });
  }

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.BanMembers)) {
      await interaction.reply({
        content: "You do not have permission to use this command.",
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      const rotateModule = await import("../../../../modules/shop/rotate/rotate");
      const ro = await rotateModule.default();

      if (!ro) {
        const embed = new EmbedBuilder()
          .setTitle("Failed to Rotate")
          .setDescription("Failed to rotate storefront.")
          .setColor("Red")
          .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
        return;
      }

      const embed = new EmbedBuilder()
        .setTitle("Rotated Storefront")
        .setDescription("Successfully rotated storefront.")
        .setColor("Blurple")
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("Error rotating:", error);

      const embed = new EmbedBuilder()
        .setTitle("Error Rotating")
        .setDescription("An error occurred while rotating the storefront.")
        .setColor("Red")
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    }
  }
}
