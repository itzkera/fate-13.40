import { ChatInputCommandInteraction, Client, EmbedBuilder } from "discord.js";
import { v4 as uuid } from "uuid";
import { Command } from "../../handlers/Command";
import {
  accountService,
  friendsService,
  logger,
  profilesService,
  receiptsService,
  seasonStatsService,
  userService,
} from "../../../..";
import { createMobileAuthCode } from "../../../../utilities/launcher/mobileauthcodes";
import ProfileHelper from "../../../../utilities/ProfileHelper";

async function createAccount(discordId: string, username: string) {
  const accountId = username;
  const hashedPassword = await Bun.password.hash(uuid());

  const newUser = await userService.create({
    email: `${username}@epicgames.dev`,
    username,
    password: hashedPassword,
    accountId,
    discordId,
    roles: [],
    banned: false,
    has_all_items: false,
    lastLogin: "",
    ac: false,
  });

  if (!newUser) throw new Error("Failed to create user");

  const [
    athena, profile0, common_core, campaign, metadata,
    theater0, collection_book_people0, collection_book_schematics0, outpost0, creative,
  ] = await Promise.all([
    ProfileHelper.createProfile(newUser, "athena"),
    ProfileHelper.createProfile(newUser, "profile0"),
    ProfileHelper.createProfile(newUser, "common_core"),
    ProfileHelper.createProfile(newUser, "campaign"),
    ProfileHelper.createProfile(newUser, "metadata"),
    ProfileHelper.createProfile(newUser, "theater0"),
    ProfileHelper.createProfile(newUser, "collection_book_people0"),
    ProfileHelper.createProfile(newUser, "collection_book_schematics0"),
    ProfileHelper.createProfile(newUser, "outpost0"),
    ProfileHelper.createProfile(newUser, "creative"),
  ]);

  await accountService.create({ accountId: newUser.accountId, discordId, arenaHype: 0 });

  await Promise.all([
    profilesService.createOrUpdate(newUser.accountId, "profile0", profile0),
    profilesService.createOrUpdate(newUser.accountId, "athena", athena),
    profilesService.createOrUpdate(newUser.accountId, "common_core", common_core),
    profilesService.createOrUpdate(newUser.accountId, "common_public", common_core),
    profilesService.createOrUpdate(newUser.accountId, "campaign", campaign),
    profilesService.createOrUpdate(newUser.accountId, "metadata", metadata),
    profilesService.createOrUpdate(newUser.accountId, "theater0", theater0),
    profilesService.createOrUpdate(newUser.accountId, "outpost0", outpost0),
    profilesService.createOrUpdate(newUser.accountId, "creative", creative),
    profilesService.createOrUpdate(newUser.accountId, "collection_book_people0", collection_book_people0),
    profilesService.createOrUpdate(newUser.accountId, "collection_book_schematics0", collection_book_schematics0),
  ]);

  await friendsService.create({ accountId: newUser.accountId });
  await receiptsService.create(newUser.accountId, []);
  await accountService.createDefaultPermissions(newUser.accountId);

  const stats = ProfileHelper.createStatsTemplate();
  await seasonStatsService.create({
    solos: stats.solos,
    duos: stats.duos,
    squads: stats.squads,
    ltm: stats.ltm,
    accountId: newUser.accountId,
  });

  return newUser;
}

export default class MobileCommand extends Command {
  constructor(client: Client) {
    super(client, {
      name: "mobile",
      description: "Get a mobile login code for Fortnite. Creates an account if you don't have one.",
      options: [],
      permissions: [],
    });
  }

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    await interaction.deferReply({ ephemeral: true });

    const discordId = interaction.user.id;
    const username = interaction.user.username;
    const iconURL = interaction.user.avatarURL() ?? undefined;

    let user = await userService.findUserByDiscordId(discordId);
    let justCreated = false;

    if (!user) {
      try {
        user = await createAccount(discordId, username);
        justCreated = true;
      } catch (err) {
        logger.error(`Mobile auto-register failed for ${username}: ${err}`);
        await interaction.editReply({
          content: "Failed to create your account. Please try again or use `/register`.",
        });
        return;
      }
    }

    const code = createMobileAuthCode(user.accountId);

    const embed = new EmbedBuilder()
      .setTitle(justCreated ? "Account Created + Mobile Login" : "Mobile Login")
      .setColor(justCreated ? "Green" : "Blurple")
      .setAuthor({ name: username, iconURL })
      .addFields(
        { name: "Auth Code", value: `\`\`\`${code}\`\`\``, inline: false },
        { name: "What to do", value: "Go to the mobile login page, enter this code, and Fortnite will open automatically.", inline: false },
      )
      .setFooter({ text: "This code expires in 5 minutes." })
      .setTimestamp();

    if (justCreated) {
      embed.setDescription(`A new account has been created for you with username **${username}**.`);
    }

    await interaction.editReply({ embeds: [embed] });
  }
}
