import type { Client, GuildMember } from "discord.js";
import crypto from "node:crypto";
import path from "node:path";
import { config, logger, profilesService, userService } from "../..";
import { User } from "../../tables/user";
import ProfileHelper from "../../utilities/profiles";
import RefreshAccount from "../../utilities/refresh";

type DonatorFlag =
  | "bronze_donator"
  | "silver_donator"
  | "emerald_donator"
  | "og_donator"
  | "summer_donator"
  | "platinum_donator";

interface DonatorPack {
  flag: DonatorFlag;
  fullLocker?: boolean;
  cosmetics: string[];
}

const GIFT_MESSAGE = "Thanks for supporting Fate!";

type PackKey = "bronze" | "og" | "silver" | "summer" | "emerald" | "platinum";

const PACK_DEFINITIONS: Record<PackKey, DonatorPack> = {
  bronze: {
    flag: "bronze_donator",
    cosmetics: [
      "CID_052_Athena_Commando_F_PSBlue",
      "CID_046_Athena_Commando_F_HolidaySweater",
      "Pickaxe_ID_190_GolfClub",
    ],
  },
  og: {
    flag: "og_donator",
    cosmetics: [
      "CID_028_Athena_Commando_F",
      "CID_017_Athena_Commando_M",
      "CID_032_Athena_Commando_M_BlackKnight",
      "CID_029_Athena_Commando_F_Halloween",
      "CID_030_Athena_Commando_M_Halloween",
      "Pickaxe_Lockjaw",
      "Pickaxe_ID_013_Teslacoil",
      "EID_Floss",
      "EID_TakeTheL",
      "EID_OrangeJustice",
    ],
  },
  silver: {
    flag: "silver_donator",
    cosmetics: [
      "CID_175_Athena_Commando_M_Celestial",
      "CID_577_Athena_Commando_F_Volt",
      "CID_114_Athena_Commando_F_TacticalWhite",
      "Pickaxe_ID_094_Scythe",
    ],
  },
  summer: {
    flag: "summer_donator",
    cosmetics: [
      "CID_342_Athena_Commando_M_StreetRacerMetalmask",
      "CID_447_Athena_Commando_F_Beach",
      "CID_689_Athena_Commando_F_RedRidingSummer",
      "CID_762_Athena_Commando_F_CrystalSummer",
      "CID_694_Athena_Commando_M_BananaSummer",
      "CID_541_Athena_Commando_F_Shark",
      "CID_652_Athena_Commando_M_Flamingo",
      "EID_Waterworks",
      "EID_SmoothMoves",
      "EID_ElectroSwing",
      "EID_Scenario",
    ],
  },
  emerald: {
    flag: "emerald_donator",
    cosmetics: [
      "CID_644_Athena_Commando_M_Cyclone",
      "CID_645_Athena_Commando_M_AstroJack",
      "CID_149_Athena_Commando_F_SoccerGirlB",
      "CID_526_Athena_Commando_M_DarkVertex",
    ],
  },
  platinum: {
    flag: "platinum_donator",
    fullLocker: true,
    cosmetics: [],
  },
};

const ROLE_IDS: Record<"production" | "testing", Record<PackKey, string>> = {
  production: {
    bronze: "1466969800705048702",
    og: "1506036141579567144",
    silver: "1466969800705048703",
    summer: "1506035383421505856",
    emerald: "1466969800705048704",
    platinum: "1466969800705048705",
  },
  testing: {
    bronze: "1466969800705048702",
    og: "1506036141579567144",
    silver: "1466969800705048703",
    summer: "1506035383421505856",
    emerald: "1466969800705048704",
    platinum: "1466969800705048705",
  },
};

export const DONATOR_PACKS: Record<string, DonatorPack> = Object.fromEntries(
  (Object.keys(PACK_DEFINITIONS) as PackKey[]).map((key) => [
    ROLE_IDS[config.environment][key],
    PACK_DEFINITIONS[key],
  ]),
);

function resolveTemplateId(id: string): string {
  if (id.startsWith("CID_")) return `AthenaCharacter:${id}`;
  if (id.startsWith("EID_")) return `AthenaDance:${id}`;
  if (id.startsWith("Pickaxe")) return `AthenaPickaxe:${id}`;
  if (id.startsWith("Backpack_")) return `AthenaBackpack:${id}`;
  if (id.startsWith("Glider_")) return `AthenaGlider:${id}`;
  if (id.startsWith("Wrap_")) return `AthenaItemWrap:${id}`;
  return `AthenaCharacter:${id}`;
}

function createAthenaItem(templateId: string) {
  return {
    templateId,
    attributes: {
      max_level_bonus: 0,
      level: 1,
      item_seen: false,
      xp: 0,
      variants: [],
      favorite: false,
    },
    quantity: 1,
  };
}

async function grantFullLocker(accountId: string): Promise<void> {
  const athena = await ProfileHelper.getProfile(accountId, "athena");
  if (!athena) return;

  const allItems = require(path.join(__dirname, "..", "..", "memory", "all.json"));

  athena.items = { ...athena.items, ...allItems };
  athena.rvn++;
  athena.commandRevision++;
  athena.updatedAt = new Date().toISOString();

  await profilesService.update(accountId, "athena", athena);

  await User.createQueryBuilder()
    .update(User)
    .set({ has_all_items: true })
    .where("accountId = :accountId", { accountId })
    .execute();
}

async function grantPack(accountId: string, cosmetics: string[]): Promise<void> {
  const templateIds = cosmetics.map(resolveTemplateId);

  const athena = await ProfileHelper.getProfile(accountId, "athena");
  if (athena) {
    for (const templateId of templateIds) {
      athena.items[templateId] = createAthenaItem(templateId);
    }
    athena.rvn++;
    athena.commandRevision++;
    athena.updatedAt = new Date().toISOString();

    await profilesService.update(accountId, "athena", athena);
  }

  const common_core = await ProfileHelper.getProfile(accountId, "common_core");
  if (common_core) {
    if (!common_core.items) common_core.items = {};

    const purchaseId = crypto.randomUUID();
    const lootList = templateIds.map((templateId) => ({
      itemType: templateId,
      itemGuid: templateId,
      quantity: 1,
    }));

    common_core.items[purchaseId] = {
      templateId: "GiftBox:GB_MakeGood",
      attributes: {
        fromAccountId: "",
        lootList,
        params: {
          userMessage: GIFT_MESSAGE,
        },
        giftedOn: new Date().toISOString(),
      },
      quantity: 1,
    };

    common_core.rvn++;
    common_core.commandRevision++;
    common_core.updatedAt = new Date().toISOString();

    await profilesService.update(accountId, "common_core", common_core);
  }
}

export async function processDonatorRoles(member: GuildMember, user: User): Promise<void> {
  try {
    let granted = false;

    for (const [roleId, pack] of Object.entries(DONATOR_PACKS)) {
      if (!member.roles.cache.has(roleId)) continue;
      if ((user as unknown as Record<DonatorFlag, boolean>)[pack.flag]) continue;

      if (pack.fullLocker) await grantFullLocker(user.accountId);
      else await grantPack(user.accountId, pack.cosmetics);

      await User.createQueryBuilder()
        .update(User)
        .set({ [pack.flag]: true })
        .where("accountId = :accountId", { accountId: user.accountId })
        .execute();

      logger.info(`Granted ${pack.flag} rewards to ${user.username} (${user.accountId})`);
      granted = true;
    }

    if (granted) await RefreshAccount(user.accountId, user.username);
  } catch (error) {
    logger.error(`Error processing donator roles: ${error}`);
  }
}

export async function backfillDonators(client: Client): Promise<void> {
  try {
    const guild = await client.guilds.fetch(config.guild_id);
    const members = await guild.members.fetch();

    logger.startup(`Checking donator roles for ${members.size} members`);

    for (const member of members.values()) {
      const hasDonatorRole = Object.keys(DONATOR_PACKS).some((roleId) =>
        member.roles.cache.has(roleId),
      );
      if (!hasDonatorRole) continue;

      const user = await userService.findUserByDiscordId(member.id);
      if (!user || user.banned) continue;

      await processDonatorRoles(member, user);
    }

    logger.startup("Finished checking donator roles");
  } catch (error) {
    logger.error(`Error backfilling donator roles: ${error}`);
  }
}
