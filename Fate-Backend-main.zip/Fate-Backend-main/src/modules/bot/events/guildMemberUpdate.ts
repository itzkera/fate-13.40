import { Client, GuildMember, Role } from "discord.js";
import { Event } from "../handlers/Event";
import { logger, userService } from "../../..";
import { User } from "../../../tables/user";
import { processDonatorRoles } from "../donator";

export default class GuildMemberUpdateEvent extends Event<"guildMemberUpdate"> {
  constructor(client: Client) {
    super(client, "guildMemberUpdate");
  }

  async run(oldMember: GuildMember, newMember: GuildMember): Promise<void> {
    try {
      const oldRoles = oldMember.roles.cache;
      const newRoles = newMember.roles.cache;

      const addedRoles = this.getDifference(newRoles, oldRoles);
      const removedRoles = this.getDifference(oldRoles, newRoles);

      if (addedRoles.length === 0 && removedRoles.length === 0) return;

      const user = await userService.findUserByDiscordId(newMember.id);
      if (!user) return;

      const roleNames = newRoles.map((role) => role.name);
      await User.createQueryBuilder()
        .update(User)
        .set({ roles: roleNames })
        .where("accountId = :accountId", { accountId: user.accountId })
        .execute();

      await processDonatorRoles(newMember, user);
    } catch (error) {
      logger.error(`Error in guildMemberUpdate: ${error}`);
    }
  }

  private getDifference(
    a: Map<string, Role>,
    b: Map<string, Role>,
  ): Role[] {
    return [...a.values()].filter((role) => !b.has(role.id));
  }
}
