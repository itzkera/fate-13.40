import { Event } from "../handlers/Event";
import { ActivityType, Client } from "discord.js";
import { backfillDonators } from "../donator";
import { matchmaker } from "../../..";

export default class ReadyEvent extends Event<"ready"> {
  constructor(client: Client) {
    super(client, "ready");
  }

  async run(): Promise<void> {
    const updatePlayerCount = () => {
      const players = matchmaker?.getServerInfo().totalPlayers ?? 0;
      this.client.user?.setActivity(`${players} players`, {
        type: ActivityType.Watching,
      });
    };

    updatePlayerCount();
    setInterval(updatePlayerCount, 60_000);
    await backfillDonators(this.client);
  }
}
