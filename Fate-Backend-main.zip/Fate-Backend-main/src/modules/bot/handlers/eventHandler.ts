import { ExtendedClient } from "../types/ExtendedClient";
import { Event } from "./Event";
import fs from "fs";
import path from "path";

export const loadEvents = async (client: ExtendedClient): Promise<void> => {
  const eventFiles = fs
    .readdirSync(path.join(__dirname, "../events"))
    .filter((file) => file.endsWith(".ts"));

  for (const file of eventFiles) {
    try {
      const module = await import(`../events/${file}`);
      const EventClass = module.default;

      if (!EventClass) {
        console.warn(`Event file ${file} has no default export`);
        continue;
      }

      const eventInstance: Event<any> = new EventClass(client);

      if (eventInstance.name) {
        client.on(eventInstance.name, (...args) => eventInstance.run(...args));
      }
    } catch (error) {
      console.error(`Failed to load event ${file}:`, error);
    }
  }
};
