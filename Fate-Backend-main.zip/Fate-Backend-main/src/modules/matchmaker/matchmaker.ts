import WebSocket from "ws";
import crypto from "crypto";
import { WebSocketServer } from "ws";
import { IncomingMessage } from "http";
import QueueService from "../../wrappers/database/QueueService";
import ClientService from "../../wrappers/database/ClientService";
import ServerService from "../../wrappers/database/ServersService";
import type Database from "../../wrappers/Database.wrapper";
import { QueueStatus } from "../../tables/matchmaking/queue";
import { AuthUtils } from "./utils/auth";
import { config, logger } from "../..";
import type MatchmakingService from "../../wrappers/database/MatchmakingService";
import type { Matchmaking } from "../../tables/matchmaking";
import { handleXmppConnection } from "../xmpp";

interface ClientData {
  ws: WebSocket;
  playerId: string;
  accountId: string;
  socketId: string;
  ticketId: string;
  matchId: string;
  sessionId: string;
  playlist: string;
  region: string;
  season: number;
  customKey: string;
  bucketId: string;
  partyPlayerIds: string[];
  joinedAt: Date;
  status: string;
  preventMessage?: boolean;
  customServerId?: string;
}

interface GameServer {
  region: string;
  ip: string;
  port: number;
  status: string;
  currentPlayers: number;
  maxPlayers: number;
  customKey?: string;
}

export default class Matchmaker {
  private wss: WebSocketServer;
  private clients: Map<string, ClientData>;
  private gameServers: Map<string, GameServer>;
  private customServers: Map<string, GameServer>;
  private queueService: QueueService;
  private clientService: ClientService;
  private serverService: ServerService;
  private matchmakingKeys: Map<string, Matchmaking>;
  private keyToServerMap: Map<string, string>;
  private matchmakingService: MatchmakingService;

  constructor(wss: WebSocketServer, database: Database, matchmakingService: MatchmakingService) {
    this.wss = wss;
    this.clients = new Map();
    this.gameServers = new Map();
    this.customServers = new Map();
    this.matchmakingKeys = new Map();
    this.keyToServerMap = new Map();
    this.queueService = new QueueService(database);
    this.clientService = new ClientService(database);
    this.serverService = new ServerService(database);
    this.matchmakingService = matchmakingService;

    this.loadGameServers();
    this.loadMatchmakingKeys();
    this.setupWebSocket();
  }

  private async loadMatchmakingKeys(): Promise<void> {
    try {
      const keys = await this.matchmakingService.findAll();
      keys.forEach((key) => {
        if (key) {
          this.matchmakingKeys.set(key.key, key);
          logger.info(`Loaded matchmaking key: ${key.key} -> ${key.address}:${key.port}`);
        }
      });
    } catch (error) {
      logger.error(`Error loading matchmaking keys: ${error}`);
    }
  }

  private loadGameServers(): void {
    const regions = config.regions.length
      ? config.regions
      : process.env.REGIONS?.split(",").map((r) => r.trim()) || [];

    regions.forEach((region) => {
      const configKey = `${region.toLowerCase()}_gameserver` as keyof typeof config;
      const serverEnvKey = `${region}_GAMESERVER`;
      const serverAddress = String(config[configKey] || process.env[serverEnvKey] || "");

      if (serverAddress) {
        const [ip, port] = serverAddress.split(":");
        const server: GameServer = {
          region,
          ip,
          port: parseInt(port),
          status: "offline",
          currentPlayers: 0,
          maxPlayers: config.max_players,
        };
        this.gameServers.set(region, server);
        logger.info(`Loaded game server for ${region}: ${ip}:${port}`);
      } else {
        console.warn(`No game server configured for region: ${region}`);
      }
    });
  }

  public upsertGameServer(server: {
    region: string;
    ip: string;
    port: number;
    maxPlayers?: number;
    status?: string;
    currentPlayers?: number;
  }): void {
    this.gameServers.set(server.region, {
      region: server.region,
      ip: server.ip,
      port: server.port,
      status: server.status ?? "online",
      currentPlayers: server.currentPlayers ?? 0,
      maxPlayers: server.maxPlayers ?? config.max_players,
    });
  }

  private setupWebSocket(): void {
    this.wss.on("connection", async (ws: WebSocket, req: IncomingMessage) => {
      if (req.headers["sec-websocket-protocol"]?.toLowerCase().includes("xmpp")) {
        return handleXmppConnection(ws);
      }

      await this.handleConnection(ws, req);
    });
  }

  private async handleConnection(ws: WebSocket, req: IncomingMessage): Promise<void> {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
      logger.warn("Matchmaker WS rejected: missing authorization header");
      return ws.close(1008, "missing_authorization");
    }

    const matchmakingData = AuthUtils.extractMatchmakingData(authHeader, config.client_secret);

    if (!matchmakingData) {
      logger.warn("Matchmaker WS rejected: invalid authorization payload");
      return ws.close(1008, "invalid_payload");
    }

    if (matchmakingData.expireAt) {
      const expireTime = new Date(matchmakingData.expireAt).getTime();
      const currentTime = Date.now();
      if (currentTime - expireTime > 30000) {
        logger.warn(`Matchmaker WS rejected: expired ticket accountId=${matchmakingData.accountId}`);
        return ws.close(1008, "timestamp_expired");
      }
    }

    const accountId = matchmakingData.accountId;

    if (this.clients.has(accountId)) {
      const oldClient = this.clients.get(accountId);
      if (oldClient && oldClient.ws.readyState === WebSocket.OPEN) {
        oldClient.ws.close(1000, "reconnecting");
      }
      this.clients.delete(accountId);
    }

    const playerId = matchmakingData.playerId || accountId;
    const playlist = matchmakingData.playlist;
    const region = matchmakingData.region;
    const season = matchmakingData.season;
    const customKey = matchmakingData.customKey || "default";
    const bucketId = matchmakingData.bucketId;

    const ticketId = crypto.createHash("md5").update(`1${Date.now()}${accountId}`).digest("hex");
    const matchId = crypto.createHash("md5").update(`2${Date.now()}${accountId}`).digest("hex");
    const sessionId = crypto.createHash("md5").update(`3${Date.now()}${accountId}`).digest("hex");
    const socketId = crypto.randomBytes(8).toString("hex");

    const clientData: ClientData = {
      ws,
      playerId,
      accountId,
      socketId,
      ticketId,
      matchId,
      sessionId,
      playlist,
      region,
      season,
      customKey,
      bucketId,
      partyPlayerIds: matchmakingData.partyPlayerIds || [accountId],
      joinedAt: new Date(),
      status: "connecting",
      preventMessage: false,
    };

    if (customKey && customKey !== "default") {
      const keyData = this.matchmakingKeys.get(customKey);
      if (!keyData) {
        logger.warn(`Matchmaker WS rejected: invalid custom key ${customKey}`);
        return ws.close(1008, `invalid_matchmaking_key_${customKey}`);
      }

      const serverId = this.keyToServerMap.get(customKey);
      if (serverId) {
        const server = this.customServers.get(serverId);
        if (server && server.status === "online" && server.currentPlayers < server.maxPlayers) {
          await this.assignToCustomServer(clientData, server, serverId);
          return;
        }
      }
    }

    if (customKey === "default" && !this.gameServers.has(region)) {
      logger.warn(`Matchmaker WS rejected: no server for region ${region}`);
      return ws.close(1008, `no_server_for_region_${region}`);
    }

    this.clients.set(accountId, clientData);
    logger.info(
      `Matchmaker WS accepted: accountId=${accountId} region=${region} playlist=${playlist} customKey=${customKey}`,
    );

    try {
      const existingQueue = await this.queueService.findByPlayerId(playerId);

      if (existingQueue) {
        await this.queueService.updateByPlayerId(playerId, {
          accountId,
          playlist,
          region,
          season,
          customKey,
          ticketId,
          matchId,
          sessionId,
          status: QueueStatus.CONNECTING,
          joinedAt: new Date(),
          preventMessage: false,
        });
      } else {
        await this.queueService.create({
          playerId,
          accountId,
          playlist,
          region,
          season,
          customKey,
          ticketId,
          matchId,
          sessionId,
          status: QueueStatus.CONNECTING,
          joinedAt: new Date(),
          preventMessage: false,
        });
      }

      const existingClient = await this.clientService.findByPlayerId(playerId);

      if (existingClient) {
        await this.clientService.updateByPlayerId(playerId, {
          accountId,
          socketId,
          playlist,
          region,
          season,
          customKey,
          ticketId,
          matchId,
          sessionId,
          lastActivity: new Date(),
        });
      } else {
        await this.clientService.create({
          playerId,
          accountId,
          socketId,
          playlist,
          region,
          season,
          customKey,
          ticketId,
          matchId,
          sessionId,
          connectedAt: new Date(),
          lastActivity: new Date(),
        });
      }
    } catch (error) {
      logger.error("Error saving client to database:", { error });
    }

    setTimeout(() => this.sendConnecting(ws), 200);
    setTimeout(() => this.sendWaiting(ws, clientData), 1000);
    setTimeout(() => this.addToQueue(clientData), 2000);

    ws.on("close", async () => {
      logger.info(`Matchmaker WS closed: accountId=${accountId}`);
      await this.handleDisconnection(accountId);
    });

    ws.on("error", async (error: Error) => {
      logger.error(`WebSocket error for player ${accountId}:`, error);
      await this.handleDisconnection(accountId);
    });
  }

  private async assignToCustomServer(
    clientData: ClientData,
    server: GameServer,
    serverId: string,
  ): Promise<void> {
    clientData.status = QueueStatus.QUEUED;
    clientData.customServerId = serverId;

    server.currentPlayers++;

    this.clients.set(clientData.accountId, clientData);

    try {
      await this.queueService.updateByPlayerId(clientData.playerId, {
        status: QueueStatus.SESSIONASSIGNMENT,
      });
    } catch (error) {
      logger.error("Error updating custom assignment status:", { error });
    }

    setTimeout(() => this.sendConnecting(clientData.ws), 200);
    setTimeout(() => this.sendWaiting(clientData.ws, clientData), 1000);
    setTimeout(async () => {
      await this.sendSessionAssignment(clientData);
      setTimeout(async () => {
        await this.sendPlay(clientData, server);
      }, 200);
    }, 2000);
  }

  private async handleCustomKeyQueues(): Promise<void> {
    const customKeys = Array.from(this.matchmakingKeys.keys());

    for (const key of customKeys) {
      const queuedPlayers = this.getQueuedPlayersForCustomKey(key);
      const minPlayers = parseInt(process.env.MIN_PLAYERS_CUSTOM || "2");

      if (queuedPlayers.length >= minPlayers) {
        const keyData = this.matchmakingKeys.get(key);
        if (!keyData) continue;

        let serverId = this.keyToServerMap.get(key);
        let server = serverId ? this.customServers.get(serverId) : undefined;

        if (!server || server.status === "offline") {
          serverId = `custom_${key}_${Date.now()}`;
          const playerRegion = queuedPlayers[0]?.region || "NAE";
          server = {
            region: playerRegion,
            ip: keyData.address,
            port: keyData.port,
            status: "online",
            currentPlayers: 0,
            maxPlayers: parseInt(process.env.MAX_PLAYERS_CUSTOM || "16"),
            customKey: key,
          };
          this.customServers.set(serverId, server);
          this.keyToServerMap.set(key, serverId);
          logger.info(
            `Started custom server for key ${key}: ${server.ip}:${server.port} (Region: ${playerRegion})`,
          );
        }

        const playersToAssign = queuedPlayers.slice(0, server.maxPlayers - server.currentPlayers);
        for (const player of playersToAssign) {
          if (serverId) await this.assignToCustomServer(player, server, serverId);
        }
      }
    }
  }

  private getQueuedPlayersForCustomKey(customKey: string): ClientData[] {
    return Array.from(this.clients.values()).filter(
      (c) =>
        c.customKey === customKey &&
        c.status === "queued" &&
        !c.preventMessage &&
        !c.customServerId,
    );
  }

  private async handleDisconnection(accountId: string): Promise<void> {
    const client = this.clients.get(accountId);
    if (client) {
      if (client.customServerId) {
        const customServer = this.customServers.get(client.customServerId);
        if (customServer) {
          customServer.currentPlayers = Math.max(0, customServer.currentPlayers - 1);

          if (customServer.currentPlayers === 0) {
            customServer.status = "offline";
            logger.info(`Custom server ${client.customServerId} marked as offline (no players)`);
          }
        }
      }

      this.clients.delete(accountId);

      try {
        await this.queueService.deleteByPlayerId(client.playerId);
        await this.clientService.deleteByPlayerId(client.playerId);
      } catch (error) {
        logger.error(`Error removing client from database: ${error}`);
      }
    }
  }

  private sendConnecting(ws: WebSocket): void {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(
        JSON.stringify({
          payload: {
            state: "Connecting",
          },
          name: "StatusUpdate",
        }),
      );
    }
  }

  private sendWaiting(ws: WebSocket, clientData: ClientData): void {
    if (ws.readyState === WebSocket.OPEN) {
      let totalPlayers = this.clients.size;
      let connectedPlayers = 0;

      if (clientData.customKey && clientData.customKey !== "default") {
        connectedPlayers = Array.from(this.clients.values()).filter(
          (c) => c.customKey === clientData.customKey,
        ).length;
      } else {
        connectedPlayers = Array.from(this.clients.values()).filter(
          (c) =>
            c.playlist === clientData.playlist &&
            c.region === clientData.region &&
            c.customKey === clientData.customKey,
        ).length;
      }

      ws.send(
        JSON.stringify({
          payload: {
            totalPlayers,
            connectedPlayers,
            state: "Waiting",
          },
          name: "StatusUpdate",
        }),
      );
    }
  }

  private async addToQueue(clientData: ClientData): Promise<void> {
    if (clientData.ws.readyState !== WebSocket.OPEN) return;
    if (clientData.customServerId) return;

    clientData.status = "queued";

    try {
      await this.queueService.updateByPlayerId(clientData.playerId, {
        status: QueueStatus.QUEUED,
      });
    } catch (error) {
      logger.error("Error updating queue status:", { error });
    }

    let queuedPlayers = 0;

    if (clientData.customKey && clientData.customKey !== "default") {
      queuedPlayers = this.getQueuedPlayersForCustomKey(clientData.customKey).length;
    } else {
      queuedPlayers = Array.from(this.clients.values()).filter(
        (c) =>
          c.status === "queued" &&
          c.playlist === clientData.playlist &&
          c.region === clientData.region &&
          c.customKey === clientData.customKey,
      ).length;
    }

    if (clientData.ws.readyState === WebSocket.OPEN) {
      clientData.ws.send(
        JSON.stringify({
          payload: {
            ticketId: clientData.ticketId,
            queuedPlayers,
            estimatedWaitSec: Math.max(0, queuedPlayers * 2),
            status: {},
            state: "Queued",
          },
          name: "StatusUpdate",
        }),
      );
    }

    if (clientData.customKey && clientData.customKey !== "default") {
      setTimeout(() => this.handleCustomKeyQueues(), 1000);
    } else {
      const server = this.gameServers.get(clientData.region);
      if (server && server.status === "online") {
        await this.startServer(clientData.region, clientData.playlist);
      }
    }
  }

  private async sendSessionAssignment(clientData: ClientData): Promise<void> {
    if (clientData.ws.readyState === WebSocket.OPEN && !clientData.preventMessage) {
      clientData.status = "sessionassignment";

      try {
        await this.queueService.updateByPlayerId(clientData.playerId, {
          status: QueueStatus.SESSIONASSIGNMENT,
        });
      } catch (error) {
        logger.error("Error updating session assignment status:", { error });
      }

      clientData.ws.send(
        JSON.stringify({
          payload: {
            matchId: clientData.matchId,
            state: "SessionAssignment",
          },
          name: "StatusUpdate",
        }),
      );
    }
  }

  private async sendPlay(clientData: ClientData, server: GameServer): Promise<void> {
    if (clientData.ws.readyState === WebSocket.OPEN && !clientData.preventMessage) {
      clientData.status = "playing";
      clientData.preventMessage = true;

      try {
        await this.queueService.updateByPlayerId(clientData.playerId, {
          status: QueueStatus.PLAYING,
          preventMessage: true,
        });
      } catch (error) {
        logger.error("Error updating play status:", { error });
      }

      const payload: any = {
        payload: {
          matchId: clientData.matchId,
          sessionId: clientData.sessionId,
          joinDelaySec: 1,
        },
        name: "Play",
      };

      if (clientData.customKey && clientData.customKey !== "default") {
        payload.payload.serverInfo = {
          ip: server.ip,
          port: server.port,
          region: server.region,
        };
      }

      clientData.ws.send(JSON.stringify(payload));
    }
  }

  public async startServer(region: string, playlist: string): Promise<{ success: boolean; playersMoved: number }> {
    try {
      const server = this.gameServers.get(region);
      if (!server) throw new Error(`Server not found for region: ${region}`);

      server.status = "online";

      const matchingClients = Array.from(this.clients.values())
        .filter(
          (c) =>
            c.region === region &&
            c.playlist === playlist &&
            c.status === "queued" &&
            !c.preventMessage &&
            c.customKey === "default",
        )
        .sort((a, b) => a.joinedAt.getTime() - b.joinedAt.getTime())
        .slice(0, server.maxPlayers);

      for (const client of matchingClients) {
        await this.sendSessionAssignment(client);
      }

      setTimeout(async () => {
        for (const client of matchingClients) {
          await this.sendPlay(client, server);
        }
        server.currentPlayers = matchingClients.length;
      }, 200);

      return { success: true, playersMoved: matchingClients.length };
    } catch (error) {
      throw error;
    }
  }

  public async stopServer(region: string, playlist: string): Promise<{ success: boolean; message: string }> {
    try {
      const server = this.gameServers.get(region);
      if (!server) throw new Error(`Server not found for region: ${region}`);

      server.status = "offline";
      server.currentPlayers = 0;

      return { success: true, message: `Server ${region} ${playlist} stopped` };
    } catch (error) {
      throw error;
    }
  }

  public async addMatchmakingKey(keyData: Matchmaking): Promise<void> {
    this.matchmakingKeys.set(keyData.key, keyData);
    logger.info(`Added matchmaking key: ${keyData.key}`);
  }

  public async removeMatchmakingKey(key: string): Promise<void> {
    const playersUsingKey = Array.from(this.clients.values()).filter((c) => c.customKey === key);

    for (const player of playersUsingKey) {
      if (player.ws.readyState === WebSocket.OPEN) {
        player.ws.close(1008, `matchmaking_key_removed_${key}`);
      }
    }

    this.matchmakingKeys.delete(key);

    const serverId = this.keyToServerMap.get(key);
    if (serverId) {
      this.customServers.delete(serverId);
      this.keyToServerMap.delete(key);
    }

    logger.info(`Removed matchmaking key: ${key}`);
  }

  public getMatchmakingKey(key: string): Matchmaking | undefined {
    return this.matchmakingKeys.get(key);
  }

  public getAllMatchmakingKeys(): Matchmaking[] {
    return Array.from(this.matchmakingKeys.values());
  }

  public getServerInfo() {
    const servers = Array.from(this.gameServers.values());
    const customServers = Array.from(this.customServers.values());
    const totalPlayers = this.clients.size;
    const customKeyPlayers = Array.from(this.clients.values()).filter(
      (c) => c.customKey && c.customKey !== "default",
    ).length;

    const playersByRegion = new Map<string, number>();
    Array.from(this.clients.values()).forEach((client) => {
      if (client.customKey === "default") {
        const currentCount = playersByRegion.get(client.region) || 0;
        playersByRegion.set(client.region, currentCount + 1);
      }
    });

    servers.forEach((server) => {
      server.currentPlayers = playersByRegion.get(server.region) || 0;
    });

    return {
      servers: [...servers, ...customServers],
      totalPlayers,
      customKeyPlayers,
      clientCount: this.clients.size,
      activeMatchmakingKeys: this.matchmakingKeys.size,
    };
  }

  public getMatchmakingInfo() {
    const keyStats = Array.from(this.matchmakingKeys.values()).map((k) => ({
      key: k.key,
      address: `${k.address}:${k.port}`,
      playersUsing: Array.from(this.clients.values()).filter((c) => c.customKey === k.key).length,
      serverStatus: this.keyToServerMap.has(k.key) ? "active" : "inactive",
    }));

    return {
      totalKeys: this.matchmakingKeys.size,
      activeCustomServers: Array.from(this.customServers.values()).filter(
        (s) => s.status === "online",
      ).length,
      customKeyPlayers: Array.from(this.clients.values()).filter(
        (c) => c.customKey && c.customKey !== "default",
      ).length,
      keys: keyStats,
    };
  }

  public cleanupIdleServers(): void {
    const now = Date.now();
    Array.from(this.customServers.entries()).forEach(([serverId, server]) => {
      if (server.status === "online" && server.currentPlayers === 0) {
        server.status = "offline";
        logger.info(`Cleaned up idle custom server: ${serverId}`);
      }
    });
  }
}