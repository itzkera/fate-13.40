import jwt from "jsonwebtoken";
import { config } from "../../..";

interface MatchmakingData {
  accountId: string;
  playerId: string;
  bucketId: string;
  region: string;
  playlist: string;
  customKey: string;
  season: number;
  partyPlayerIds: string[];
  attributes: Record<string, any>;
  expireAt?: string;
  nonce?: string;
}

export class AuthUtils {
  static decodePayload(authHeader: string): any | null {
    if (!authHeader) {
      return null;
    }

    try {
      const parts = authHeader.split(" ");

      if (parts.length < 3 || parts[0] !== "Epic-Signed") {
        return null;
      }

      const base64Payload = parts[2];
      const normalized = base64Payload.replace(/\n/g, "").trim();
      const jsonString = Buffer.from(normalized, "base64").toString("utf-8");
      const payload = JSON.parse(jsonString);

      return payload;
    } catch (error) {
      console.error("Failed to decode matchmaking payload:", error);
      return null;
    }
  }

  static extractSignatureData(authHeader: string, jwtSecret?: string): any | null {
    if (!authHeader) {
      return null;
    }

    try {
      const parts = authHeader.split(" ");

      if (parts.length < 4 || parts[0] !== "Epic-Signed") {
        return null;
      }

      const jwtToken = parts[3];
      if (jwtSecret) {
        try {
          const decoded = jwt.verify(jwtToken, config.client_secret);
          return decoded;
        } catch (error) {
          console.error("JWT verification failed:", error);
        }
      }

      try {
        const decoded = jwt.decode(jwtToken);
        return decoded;
      } catch (error) {
        return null;
      }
    } catch (error) {
      console.error("Failed to extract signature data:", error);
      return null;
    }
  }

  static extractMatchmakingData(authHeader: string, jwtSecret?: string): MatchmakingData | null {
    if (!authHeader) {
      return null;
    }

    const payload = this.decodePayload(authHeader);
    if (!payload) {
      return null;
    }

    const signatureData = this.extractSignatureData(authHeader, jwtSecret);

    const accountId = signatureData?.accountId || payload.playerId;
    if (!accountId) {
      return null;
    }

    const bucketId = payload.bucketId;
    if (!bucketId) {
      return null;
    }

    const bucketParts = bucketId.split(":");
    const region = bucketParts[2] || "NAE";
    const playlist = bucketParts[3] || "playlist_default";

    const rawCustomKey = payload.attributes?.["player.option.customKey"];
    const customKey = rawCustomKey && rawCustomKey !== "none" ? rawCustomKey : "default";
    const season = payload.attributes?.["player.season"] || 1;
    const partyPlayerIds = payload.partyPlayerIds || [accountId];

    return {
      accountId,
      playerId: payload.playerId || accountId,
      bucketId,
      region,
      playlist,
      customKey,
      season,
      partyPlayerIds,
      attributes: payload.attributes || {},
      expireAt: payload.expireAt,
      nonce: payload.nonce,
    };
  }
}
