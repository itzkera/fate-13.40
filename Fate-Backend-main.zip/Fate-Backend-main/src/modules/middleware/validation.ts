import type { Context, Next } from "hono";
import errors from "../../utilities/errors";
import jwt, { JsonWebTokenError } from "jsonwebtoken";
import { accountService, config, tokensService, userService } from "../..";
import PermissionInfo from "../../utilities/permissions/permissioninfo";

export namespace Validation {
  export async function verifyToken(c: Context, next: Next) {
    await next();
  }

  export async function verifyBasicToken(c: Context, next: Next) {
    const authorizationHeader = c.req.header("Authorization");
    const timestamp = new Date().toISOString();

    if (!authorizationHeader || !authorizationHeader.startsWith("Basic "))
      return c.json(errors.createError(403, c.req.url, "Unauthorized", timestamp), 403);

    const token = authorizationHeader.split(" ")[1];

    await next();
  }
}
