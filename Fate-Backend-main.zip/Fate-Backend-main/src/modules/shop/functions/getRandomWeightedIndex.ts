export default function getRandomWeightedIndex(probabilities: number[], rng: () => number = Math.random): number {
  const total = probabilities.reduce((acc, p) => acc + p, 0);
  const threshold = rng() * total;
  let sum = 0;
  for (let i = 0; i < probabilities.length; i++) {
    sum += probabilities[i];
    if (threshold < sum) return i;
  }
  return probabilities.length - 1;
}
