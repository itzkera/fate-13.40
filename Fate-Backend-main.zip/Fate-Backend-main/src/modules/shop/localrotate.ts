import crypto from "node:crypto";
import path from "node:path";
import type { Entries, Shop } from "./interfaces/Declarations";
import { expiration } from "../../utilities/timestamp";

type LocalCosmeticItem = {
  offerId?: string;
  item: string;
  name?: string;
  items?: Array<{ item: string; categories?: string[]; variants?: unknown }>;
  price?: number;
  rarity?: string;
  displayAssetPath?: string;
  newDisplayAssetPath?: string;
  metaInfo?: Array<{ key: string; value: string }>;
  meta?: Record<string, string>;
  variants?: unknown;
  categories?: string[];
};

type SavedStorefrontData = {
  expiration?: string;
  cacheExpire?: string;
  catalogItems?: {
    BRDailyStorefront?: LocalCosmeticItem[];
    BRWeeklyStorefront?: LocalCosmeticItem[];
  };
};

const LOCAL_STOREFRONT_DIR = path.join(__dirname, "..", "..", "local", "storefront");
const COSMETIC_TYPES = ["characters", "dances", "pickaxes", "gliders", "wraps", "backpacks"] as const;
const PRICES: Record<string, Record<string, number>> = {
  characters: {
    uncommon: 800,
    rare: 1200,
    epic: 1500,
    legendary: 2000,
    dark: 800,
    dc: 1200,
    gaminglegends: 1200,
    frozen: 1200,
    lava: 1200,
    marvel: 1500,
    shadow: 1200,
    icon: 1500,
  },
  pickaxes: {
    uncommon: 500,
    rare: 800,
    epic: 1200,
    icon: 500,
    dark: 1200,
    frozen: 1000,
    slurp: 1500,
    dc: 1800,
    gaminglegends: 1200,
    lava: 1200,
    marvel: 1500,
    shadow: 1200,
  },
  gliders: {
    uncommon: 500,
    rare: 800,
    epic: 1200,
    legendary: 1500,
    icon: 500,
    dc: 1200,
    dark: 500,
    frozen: 1000,
    marvel: 1000,
    lava: 1200,
  },
  wraps: {
    uncommon: 300,
    rare: 500,
    epic: 500,
  },
  dances: {
    uncommon: 200,
    rare: 500,
    epic: 800,
    icon: 500,
    marvel: 500,
    dc: 300,
  },
  backpacks: {
    uncommon: 100,
    rare: 200,
    epic: 300,
  },
};

function randomId(): string {
  return crypto.randomBytes(32).toString("hex");
}

function pick<T>(items: T[], rng: () => number): T {
  return items[Math.floor(rng() * items.length)];
}

function normalizeRarity(rarity: unknown): string {
  return String(rarity || "rare").toLowerCase().replace(/\s/g, "");
}

async function readLocalItems(type: (typeof COSMETIC_TYPES)[number]): Promise<LocalCosmeticItem[]> {
  const file = Bun.file(path.join(LOCAL_STOREFRONT_DIR, "cosmetics", `${type}.json`));
  if (!(await file.exists())) return [];
  const items = (await file.json()) as LocalCosmeticItem[];
  return items.filter((item) => item && typeof item.item === "string");
}

function pickUnique(pool: LocalCosmeticItem[], usedIds: Set<string>, rng: () => number): LocalCosmeticItem | null {
  const available = pool.filter((i) => !usedIds.has(i.item));
  if (available.length === 0) return null;
  const item = pick(available, rng);
  usedIds.add(item.item);
  return item;
}

function getItemType(item: LocalCosmeticItem): string {
  if (item.item.includes("AthenaCharacter")) return "characters";
  if (item.item.includes("AthenaDance")) return "dances";
  if (item.item.includes("AthenaPickaxe")) return "pickaxes";
  if (item.item.includes("AthenaGlider")) return "gliders";
  if (item.item.includes("AthenaItemWrap")) return "wraps";
  if (item.item.includes("AthenaBackpack")) return "backpacks";
  return "characters";
}

function getBaseItemId(templateId: string): string {
  return templateId.replace(
    /^(AthenaCharacter|AthenaGlider|AthenaPickaxe|AthenaItemWrap|AthenaDance|AthenaBackpack):/,
    "",
  );
}

function buildEntry(item: LocalCosmeticItem, priority: number, sectionId: string): Entries {
  const rarity = normalizeRarity(item.rarity);
  const type = getItemType(item);
  const price = Number(item.price ?? PRICES[type]?.[rarity] ?? 800);
  const itemGrants = [
    { templateId: item.item, quantity: 1 },
    ...(Array.isArray(item.items)
      ? item.items
          .filter((entry) => typeof entry?.item === "string")
          .map((entry) => ({ templateId: entry.item, quantity: 1 }))
      : []),
  ];
  const requirements = itemGrants.map((grant) => ({
    requirementType: "DenyOnItemOwnership",
    requiredId: grant.templateId,
    minQuantity: 1,
  }));
  const baseItemId = getBaseItemId(item.item);
  const displayAssetPath =
    item.displayAssetPath ?? `/Game/Catalog/DisplayAssets/DA_${baseItemId}.DA_${baseItemId}`;
  const newDisplayAssetPath =
    item.newDisplayAssetPath ??
    `/Game/Catalog/NewDisplayAssets/DAv2_Featured_${baseItemId}.DAv2_Featured_${baseItemId}`;
  const metaInfo = item.metaInfo ?? [
    { key: "SectionId", value: sectionId },
    { key: "TileSize", value: sectionId === "Featured" ? "Small" : "Normal" },
    { key: "DisplayAssetPath", value: displayAssetPath },
    { key: "NewDisplayAssetPath", value: newDisplayAssetPath },
  ];

  return {
    devName: `[VIRTUAL]1 x ${item.item} for ${price} MtxCurrency`,
    offerId: `item://${randomId()}`,
    fulfillmentIds: [],
    dailyLimit: -1,
    weeklyLimit: -1,
    monthlyLimit: -1,
    categories: item.categories ?? [],
    prices: [
      {
        currencyType: "MtxCurrency",
        currencySubType: "Currency",
        dynamicRegularPrice: price,
        regularPrice: price,
        finalPrice: price,
        saleExpiration: "9999-12-31T23:59:59.999Z",
        basePrice: price,
      },
    ],
    requirements,
    offerType: "StaticPrice",
    giftInfo: {
      bIsEnabled: true,
      forcedGiftBoxTemplateId: "",
      purchaseRequirements: requirements,
      giftRecordIds: [],
    },
    refundable: true,
    metaInfo,
    meta: {
      NewDisplayAssetPath: newDisplayAssetPath,
      LayoutId: "",
      TileSize: sectionId === "Featured" ? "Small" : "Normal",
      AnalyticOfferGroupId: "",
      SectionId: sectionId,
      templateId: item.item,
      inDate: new Date().toISOString(),
      outDate: expiration(),
      displayAssetPath,
      bUseSharedDisplay: "false",
      SharedDisplayPriority: "0",
      IconSize: "Normal",
      OriginalOffer: "",
      ExtraBonus: 0,
      Priority: priority,
      FeaturedImageUrl: "",
      CurrencyAnalyticsName: "MtxCurrency",
      ...(item.meta ?? {}),
    },
    displayAssetPath,
    NewDisplayAssetPath: newDisplayAssetPath,
    itemGrants,
    title: "",
    sortPriority: priority,
    catalogGroupPriority: priority,
    shortDescription: "",
    description: "",
    appStoreId: [],
    bannerOverride: "",
    filterWeight: 0,
  };
}

function buildEntryFromStorefrontItem(
  item: LocalCosmeticItem,
  priority: number,
  storefrontName: "BRDailyStorefront" | "BRWeeklyStorefront",
): Entries {
  const sectionId = storefrontName === "BRWeeklyStorefront" ? "Featured" : "Daily";
  const itemGrants = [
    { templateId: item.item, quantity: 1 },
    ...(Array.isArray(item.items)
      ? item.items
          .filter((entry) => typeof entry?.item === "string")
          .map((entry) => ({ templateId: entry.item, quantity: 1 }))
      : []),
  ];
  const requirements = itemGrants.map((grant) => ({
    requirementType: "DenyOnItemOwnership",
    requiredId: grant.templateId,
    minQuantity: 1,
  }));
  const displayAssetPath =
    item.displayAssetPath ??
    `/Game/Catalog/DisplayAssets/DA_${getBaseItemId(item.item)}.DA_${getBaseItemId(item.item)}`;
  const newDisplayAssetPath =
    item.newDisplayAssetPath ??
    `/Game/Catalog/NewDisplayAssets/DAv2_Featured_${getBaseItemId(item.item)}.DAv2_Featured_${getBaseItemId(item.item)}`;

  return {
    devName: `[VIRTUAL]1 x ${item.item} for ${item.price ?? 0} MtxCurrency`,
    offerId: `item://${item.offerId ?? randomId()}`,
    fulfillmentIds: [],
    dailyLimit: -1,
    weeklyLimit: -1,
    monthlyLimit: -1,
    categories: item.categories ?? [],
    prices: [
      {
        currencyType: "MtxCurrency",
        currencySubType: "Currency",
        dynamicRegularPrice: Number(item.price ?? 0),
        regularPrice: Number(item.price ?? 0),
        finalPrice: Number(item.price ?? 0),
        saleExpiration: "9999-12-31T23:59:59.999Z",
        basePrice: Number(item.price ?? 0),
      },
    ],
    requirements,
    offerType: "StaticPrice",
    giftInfo: {
      bIsEnabled: true,
      forcedGiftBoxTemplateId: "",
      purchaseRequirements: requirements,
      giftRecordIds: [],
    },
    refundable: true,
    metaInfo:
      item.metaInfo ?? [
        { key: "SectionId", value: sectionId },
        { key: "TileSize", value: sectionId === "Featured" ? "Normal" : "Small" },
        { key: "DisplayAssetPath", value: displayAssetPath },
        { key: "NewDisplayAssetPath", value: newDisplayAssetPath },
      ],
    meta: {
      NewDisplayAssetPath: newDisplayAssetPath,
      LayoutId: "",
      TileSize: String(item.meta?.TileSize ?? (sectionId === "Featured" ? "Normal" : "Small")),
      AnalyticOfferGroupId: "",
      SectionId: String(item.meta?.SectionId ?? sectionId),
      templateId: item.item,
      inDate: new Date().toISOString(),
      outDate: expiration(),
      displayAssetPath,
      bUseSharedDisplay: "false",
      SharedDisplayPriority: "0",
      IconSize: "Normal",
      OriginalOffer: "",
      ExtraBonus: 0,
      Priority: priority,
      FeaturedImageUrl: "",
      CurrencyAnalyticsName: "MtxCurrency",
      ...(item.meta ?? {}),
    },
    displayAssetPath,
    NewDisplayAssetPath: newDisplayAssetPath,
    itemGrants,
    title: "",
    sortPriority: priority,
    catalogGroupPriority: priority,
    shortDescription: "",
    description: "",
    appStoreId: [],
    bannerOverride: "",
    filterWeight: 0,
  };
}

export async function generateSavedStorefrontShop(): Promise<Shop | null> {
  const file = Bun.file(path.join(LOCAL_STOREFRONT_DIR, "shop.json"));
  if (!(await file.exists())) return null;

  const saved = (await file.json()) as SavedStorefrontData;
  const dailyItems = saved.catalogItems?.BRDailyStorefront ?? [];
  const weeklyItems = saved.catalogItems?.BRWeeklyStorefront ?? [];

  if (dailyItems.length === 0 && weeklyItems.length === 0) return null;

  return {
    refreshIntervalHrs: 24,
    dailyPurchaseHrs: 24,
    expiration: expiration(),
    storefronts: [
      {
        name: "BRDailyStorefront",
        catalogEntries: dailyItems.map((item, index) =>
          buildEntryFromStorefrontItem(item, index + 1, "BRDailyStorefront"),
        ),
      },
      {
        name: "BRWeeklyStorefront",
        catalogEntries: weeklyItems.map((item, index) =>
          buildEntryFromStorefrontItem(item, index + 1, "BRWeeklyStorefront"),
        ),
      },
    ],
  };
}

export async function generateLocalShop(rng: () => number = Math.random): Promise<Shop> {
  const [characters, dances, pickaxes, gliders, backpacks] = await Promise.all([
    readLocalItems("characters"),
    readLocalItems("dances"),
    readLocalItems("pickaxes"),
    readLocalItems("gliders"),
    readLocalItems("backpacks"),
  ]);

  const usedIds = new Set<string>();

  const featuredItems: LocalCosmeticItem[] = [];
  for (let i = 0; i < 2; i++) {
    const item = pickUnique(characters, usedIds, rng);
    if (item) featuredItems.push(item);
  }

  const dailySlots: LocalCosmeticItem[][] = [characters, dances, dances, pickaxes, gliders, backpacks];
  const dailyItems: LocalCosmeticItem[] = [];
  for (const pool of dailySlots) {
    const item = pickUnique(pool, usedIds, rng);
    if (item) dailyItems.push(item);
  }

  return {
    refreshIntervalHrs: 24,
    dailyPurchaseHrs: 24,
    expiration: expiration(),
    storefronts: [
      {
        name: "BRDailyStorefront",
        catalogEntries: dailyItems.map((item, index) => buildEntry(item, index + 1, "Daily")),
      },
      {
        name: "BRWeeklyStorefront",
        catalogEntries: featuredItems.map((item, index) => buildEntry(item, index + 1, "Featured")),
      },
    ],
  };
}
