import { itemStorageService, logger } from "../../..";
import cron from "node-cron";
import { serverState } from "../../../utilities/state";
import { buildRotatedShop, hasCosmeticEntries } from "./shared";
import { todayDateString } from "../../../utilities/seededRng";

logger.startup("Starting AutoRotate");

async function rotateShop(): Promise<boolean> {
  const shop = await buildRotatedShop() as any;
  if (!hasCosmeticEntries(shop)) return false;

  shop.generatedDate = todayDateString();
  shop.resetAt = new Date().toISOString();

  const saved = await itemStorageService.addItems([{ data: shop, type: "storefront" }]);
  return !!saved;
}

cron.schedule("0 0 * * *", async () => {
  if (!serverState.autorotateEnabled) {
    logger.info("Autorotate is disabled, skipping shop rotation");
    return;
  }

  logger.info("Rotating Shop");
  const ok = await rotateShop();
  if (ok) logger.info("Shop Rotation Complete");
  else logger.error("Shop generation produced no cosmetic entries, keeping previous shop");
});

void (async () => {
  const existing = await itemStorageService.getItemByType("storefront");
  const existingShop = existing?.data as any;

  if (
    existingShop &&
    Array.isArray(existingShop.storefronts) &&
    hasCosmeticEntries(existingShop) &&
    existingShop.generatedDate === todayDateString()
  ) {
    logger.info(`Shop for ${todayDateString()} already exists, skipping generation`);
    return;
  }

  logger.info("Generating initial shop");
  const ok = await rotateShop();
  if (ok) logger.info("Initial shop generated");
  else logger.error("Initial shop generation produced no cosmetic entries");
})();
