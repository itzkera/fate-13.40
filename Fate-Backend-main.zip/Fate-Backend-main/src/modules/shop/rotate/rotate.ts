import { itemStorageService } from "../../..";
import { buildRotatedShop, hasCosmeticEntries } from "./shared";
import { todayDateString } from "../../../utilities/seededRng";

export default async function () {
  const shop = await buildRotatedShop() as any;

  if (!hasCosmeticEntries(shop)) return false;

  shop.generatedDate = todayDateString();
  shop.resetAt = new Date().toISOString();

  const addedItems = await itemStorageService.addItems([{ data: shop, type: "storefront" }]);
  return !!addedItems;
}
