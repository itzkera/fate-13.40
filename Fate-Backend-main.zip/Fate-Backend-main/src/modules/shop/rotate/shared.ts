import type { Shop } from "../interfaces/Declarations";
import { generateLocalShop } from "../localrotate";
import { ShopGenerator } from "../shop";
import { logger } from "../../..";
import { createRng, todaySeed } from "../../../utilities/seededRng";

function isBattlePassStorefront(name: string): boolean {
  return name.startsWith("BRSeason");
}

export function hasCosmeticEntries(shop: Shop): boolean {
  return shop.storefronts.some(
    (storefront) =>
      !isBattlePassStorefront(storefront.name) && storefront.catalogEntries.length > 0,
  );
}

export async function buildRotatedShop(): Promise<Shop> {
  const rng = createRng(todaySeed());

  ShopGenerator.shop.storefronts = [];

  await ShopGenerator.generate(rng);

  if (hasCosmeticEntries(ShopGenerator.shop)) {
    return ShopGenerator.shop;
  }

  logger.error("Remote shop generation produced no cosmetic entries, falling back to local cosmetic data");

  const battlePassStorefronts = ShopGenerator.shop.storefronts.filter((storefront) =>
    isBattlePassStorefront(storefront.name),
  );

  const fallbackShop = await generateLocalShop(rng);

  ShopGenerator.shop.refreshIntervalHrs = fallbackShop.refreshIntervalHrs;
  ShopGenerator.shop.dailyPurchaseHrs = fallbackShop.dailyPurchaseHrs;
  ShopGenerator.shop.expiration = fallbackShop.expiration;
  ShopGenerator.shop.storefronts = [...fallbackShop.storefronts, ...battlePassStorefronts];

  return ShopGenerator.shop;
}
