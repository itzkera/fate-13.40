import fetch from "node-fetch";
import path from "node:path";
import { v4 as uuid } from "uuid";
import type { JSONResponse, CosmeticSet } from "./interfaces/FortniteAPI";
import { config, displayAssetsService, logger } from "../..";
import type {
  BattlePassEntry,
  BattlePassStorefront,
  Entries,
  Set,
  Shop,
  Storefronts,
} from "./interfaces/Declarations";
import { ShopHelper } from "./helpers/shophelper";
import {
  createBattlePassEntryTemplate,
  createItemEntryTemplate,
} from "./helpers/template";
import { setDisplayAsset } from "./helpers/displayAssets";
import { getPrice } from "./helpers/itemprices";
import { matchRegex } from "./functions/regex";
import { expiration } from "../../utilities/timestamp";


export namespace ShopGenerator {
  export function createShop(): Shop {
    return {
      refreshIntervalHrs: 24,
      dailyPurchaseHrs: 24,
      expiration: expiration(),
      storefronts: [],
    };
  }

  export const items: Record<string, JSONResponse> = {};
  export const sets: Record<string, Set> = {};
  export const shop = createShop();

  export async function generate(rng: () => number = Math.random) {
    shop.expiration = expiration();

    for (const key of Object.keys(items)) delete items[key];
    for (const key of Object.keys(sets)) delete sets[key];

    try {
      const [fortniteApiRequest, displayAssets] = await Promise.all([
        fetch("https://fortnite-api.com/v2/cosmetics/br").then((res) => res.json()) as any,
        displayAssetsService.getAssets(),
      ]);

      const response = fortniteApiRequest.data as JSONResponse[];

      response.forEach((json) => {
        if (
          !json.introduction ||
          json.introduction.backendValue > config.currentSeason ||
          json.introduction.backendValue === 0 ||
          !json.set ||
          !json.shopHistory ||
          json.shopHistory.length === 0
        )
          return;

        const itemType = json.type && typeof json.type === "object" ? json.type.backendValue : null;
        if (!itemType) return;

        if (!sets[json.set.backendValue]) {
          sets[json.set.backendValue] = {
            value: json.set.value,
            text: json.set.text,
            definition: [],
          };
        }

        sets[json.set.backendValue].definition.push(json);
        items[json.id] = json;
      });

      if (config.currentSeason >= 3) {
        for (const asset of Object.values(displayAssets)) {
          const assetParts = asset.value.split("_").slice(1);
          const itemKey = assetParts.join("_");
          let item: JSONResponse | undefined = items[itemKey];

          if (!item && assetParts[0].includes("CID")) {
            const match = matchRegex(itemKey);

            if (match) {
              item = Object.values(items).find((item) =>
                item.type.backendValue.includes("AthenaCharacter"),
              );
            }
          }

          if (item) {
            item.NewDisplayAssetPath = asset.value;
          }
        }
      }

      Object.values(items)
        .filter(
          (item) => item.type.backendValue.includes("AthenaBackpack") && item.itemPreviewHeroPath,
        )
        .forEach((item) => {
          const cosmeticId = item.itemPreviewHeroPath.split("/").at(-1);
          if (!cosmeticId) return;
          const cosmetic = items[cosmeticId];
          if (cosmetic) {
            cosmetic.backpack = item;
          }
        });

      const isNewStructure = config.currentSeason >= 26;

      if (isNewStructure) {
        const [weekly, battlepass] = [
          ShopHelper.createStorefront("BRWeeklyStorefront"),
          ShopHelper.createBattlePassStorefront(shop, `BRSeason${config.currentSeason}`),
        ];

        await Promise.allSettled([loadBattlePassData(battlepass)]);

        fillWeeklyStorefrontNew(weekly, rng);

        [weekly, battlepass].forEach((section) => ShopHelper.push(shop, section as any));
      } else {
        const [daily, weekly, battlepass] = [
          ShopHelper.createStorefront("BRDailyStorefront"),
          ShopHelper.createStorefront("BRWeeklyStorefront"),
          ShopHelper.createBattlePassStorefront(shop, `BRSeason${config.currentSeason}`),
        ];

        await Promise.allSettled([loadBattlePassData(battlepass)]);

        fillDailyStorefront(daily, rng);
        fillWeeklyStorefront(weekly, rng);

        [daily, weekly, battlepass].forEach((section) => ShopHelper.push(shop, section as any));
      }

    } catch (error) {
      logger.error(`Failed to generate shop: ${error}`);
    }
  }

  export async function generateBattlePassOnly() {
    shop.expiration = expiration();

    const battlepass = ShopHelper.createBattlePassStorefront(
      shop,
      `BRSeason${config.currentSeason}`,
    );
    await loadBattlePassData(battlepass);
    ShopHelper.push(shop, battlepass as any);
  }

  async function loadBattlePassData(battlepass: BattlePassStorefront) {
    try {
      const BRSeasonJSON = await Bun.file(
        path.join(
          __dirname,
          "..",
          "..",
          "memory",
          "storefront",
          `BRSeason${config.currentSeason}.json`,
        ),
      ).json();

      BRSeasonJSON.catalogEntries.forEach((entryData: BattlePassEntry) =>
        battlepass.catalogEntries.push(entryData),
      );
    } catch (error) {
      logger.error(`Failed to load battlepass data: ${error}`);
    }
  }

  function fillDailyStorefront(daily: Storefronts, rng: () => number) {
    const addedItemIds = new Set<string>();

    function pickByType(type: string): JSONResponse | null {
      const candidates = Object.values(items).filter(
        (item) => item.type.backendValue === type && !addedItemIds.has(item.id),
      );
      if (candidates.length === 0) return null;
      const picked = candidates[Math.floor(rng() * candidates.length)];
      addedItemIds.add(picked.id);
      return picked;
    }

    const slots: Array<{ type: string; count: number }> = [
      { type: "AthenaCharacter", count: 1 },
      { type: "AthenaDance", count: 2 },
      { type: "AthenaPickaxe", count: 1 },
      { type: "AthenaGlider", count: 1 },
      { type: "AthenaBackpack", count: 1 },
    ];

    for (const slot of slots) {
      for (let i = 0; i < slot.count; i++) {
        const item = pickByType(slot.type);
        if (!item) continue;
        const entry = createItemEntry(item, "Daily");
        if (entry) daily.catalogEntries.push(entry);
      }
    }
  }

  function fillWeeklyStorefront(weekly: Storefronts, rng: () => number) {
    const addedItemIds = new Set<string>();

    const candidates = Object.values(items).filter(
      (item) => item.type.backendValue === "AthenaCharacter",
    );

    for (let i = 0; i < 2; i++) {
      const available = candidates.filter((item) => !addedItemIds.has(item.id));
      if (available.length === 0) break;
      const item = available[Math.floor(rng() * available.length)];
      addedItemIds.add(item.id);
      const entry = createItemEntry(item, "Featured");
      if (entry) weekly.catalogEntries.push(entry);
    }
  }

  function fillWeeklyStorefrontNew(weekly: Storefronts, rng: () => number) {
    const minimumSets = 5;
    const usedSetIds = new Set<string>();
    const setKeys = Object.keys(sets);

    if (setKeys.length === 0) return;

    let currentSectionNumber = 1;
    let addedSetsCount = 0;

    while (addedSetsCount < minimumSets && usedSetIds.size < setKeys.length) {
      const availableKeys = setKeys.filter((key) => !usedSetIds.has(key));

      if (availableKeys.length === 0) break;

      const randomKey = availableKeys[Math.floor(rng() * availableKeys.length)];
      const randomSet = sets[randomKey];

      usedSetIds.add(randomKey);

      const sectionId = currentSectionNumber === 1 ? "Featured" : `Featured${currentSectionNumber}`;

      for (const item of randomSet.definition) {
        const isNewStructure = config.currentSeason >= 26;

        let entry: Entries | undefined;
        if (isNewStructure) {
          entry = createItemEntry(item, item.set.backendValue);
        } else {
          entry = createItemEntry(item, sectionId);
        }

        if (!entry) continue;
        weekly.catalogEntries.push(entry);
      }

      addedSetsCount++;
      currentSectionNumber++;
    }
  }

  function createItemEntry(item: JSONResponse, sectionId: string) {
    const isNewStructure = config.currentSeason >= 26;
    const isFeaturedSection = sectionId.startsWith("Featured");

    const entry = createItemEntryTemplate();

    entry.offerId = `v2:/${uuid()}`;
    entry.offerType = "StaticPrice";

    if (isNewStructure) {
      if (item.NewDisplayAssetPath) {
        entry.NewDisplayAssetPath = item.NewDisplayAssetPath;
        entry.metaInfo.push({
          key: "NewDisplayAssetPath",
          value: item.NewDisplayAssetPath,
        });
        entry.meta.NewDisplayAssetPath = item.NewDisplayAssetPath;
      } else {
        entry.NewDisplayAssetPath = "";
      }
    } else {
      if (!item.displayAssetPath && config.currentSeason >= 3)
        item.displayAssetPath = setDisplayAsset(`DA_Daily_${item.id}`);

      if (config.currentSeason >= 3) {
        if (!item.NewDisplayAssetPath) item.NewDisplayAssetPath = "";
        entry.NewDisplayAssetPath = item.NewDisplayAssetPath;
      } else {
        entry.NewDisplayAssetPath = "";
      }

      if (config.currentSeason >= 3 && item.displayAssetPath) {
        entry.displayAssetPath = item.displayAssetPath.includes("DA_Daily")
          ? item.displayAssetPath
          : setDisplayAsset(`DA_Daily_${item.id}`);

        entry.metaInfo.push({ key: "DisplayAssetPath", value: entry.displayAssetPath });
      }

      if (config.currentSeason >= 3) {
        entry.metaInfo.push({
          key: "NewDisplayAssetPath",
          value: entry.NewDisplayAssetPath,
        });
        entry.meta.NewDisplayAssetPath = entry.NewDisplayAssetPath;
      }

      entry.meta.displayAssetPath = entry.displayAssetPath;
    }

    if (isNewStructure) {
      entry.metaInfo = Object.entries(entry.meta).map(([key, value]) => ({
        key,
        value: String(value),
      }));
    } else {
      entry.metaInfo.push({
        key: "TileSize",
        value: sectionId === "Daily" ? "Small" : "Normal",
      });
      entry.metaInfo.push({ key: "SectionId", value: sectionId });
    }

    if (isNewStructure) {
      entry.meta.NewDisplayAssetPath = item.NewDisplayAssetPath || "";
      entry.meta.SectionId = sectionId;
      entry.meta.LayoutId = `${sectionId}.1`;
      entry.meta.TileSize = "Normal";
      entry.meta.AnalyticOfferGroupId = `${sectionId}-${Date.now()}`.slice(0, 30);
    } else {
      entry.meta.SectionId = sectionId;
      entry.meta.TileSize = sectionId === "Daily" ? "Small" : "Normal";
    }

    entry.requirements.push({
      requirementType: "DenyOnItemOwnership",
      requiredId: `${item.type.backendValue}:${item.id}`,
      minQuantity: 1,
    });

    entry.refundable = true;
    entry.giftInfo.bIsEnabled = true;
    entry.giftInfo.forcedGiftBoxTemplateId = "";
    entry.giftInfo.purchaseRequirements = entry.requirements;
    entry.giftInfo.giftRecordIds = [];

    if (isFeaturedSection && item.set) {
      entry.categories.push(item.set.backendValue);
    }

    const price = getPrice(item);
    if (!price) return;

    entry.prices.push({
      currencySubType: isNewStructure ? "" : "Currency",
      currencyType: "MtxCurrency",
      dynamicRegularPrice: isNewStructure ? price : -1,
      saleExpiration: "9999-12-31T23:59:59.999Z",
      basePrice: price,
      regularPrice: price,
      finalPrice: price,
    });

    entry.devName = `[VIRTUAL] 1x ${item.type.backendValue}:${item.id} for ${price} MtxCurrency`;

    entry.itemGrants.push({
      templateId: `${item.type.backendValue}:${item.id}`,
      quantity: 1,
    });

    if (item.backpack) {
      entry.itemGrants.push({
        templateId: `${item.backpack.type.backendValue}:${item.backpack.id}`,
        quantity: 1,
      });

      entry.requirements.push({
        requirementType: "DenyOnItemOwnership",
        requiredId: `${item.backpack.type.backendValue}:${item.backpack.id}`,
        minQuantity: 1,
      });
    }

    return entry;
  }
}
