import { friendsService } from "../../..";
import { Clients } from "../state";
import type { XmppSession } from "../state";
import xmlbuilder from "xmlbuilder";

export default async function GetPresenceFromFriends(session: XmppSession): Promise<void> {
  const friends = await friendsService.findFriendByAccountId(session.accountId);
  if (!friends) return;

  friends.accepted.forEach((friend) => {
    const clientData = Clients.find((i) => i.accountId === friend.accountId);
    if (!clientData) return;

    let xml = xmlbuilder
      .create("presence")
      .attribute("to", session.jid)
      .attribute("xmlns", "jabber:client")
      .attribute("from", clientData.jid)
      .attribute("type", "available");

    if (clientData.lastPresenceUpdate.away)
      xml = xml
        .element("show", "away")
        .up()
        .element("status", clientData.lastPresenceUpdate.status)
        .up();
    else xml = xml.element("status", clientData.lastPresenceUpdate.status).up();

    session.ws.send(xml.toString());
  });
}
