import xmlbuilder from "xmlbuilder";
import { Clients } from "../state";

export default function GetPresenceFromUser(
  fromId: string,
  toId: string,
  offline: boolean,
): void {
  const senderData = Clients.find((i) => i.accountId === fromId);
  const clientData = Clients.find((i) => i.accountId === toId);

  if (!senderData || !clientData) return;

  let xml = xmlbuilder
    .create("presence")
    .attribute("to", clientData.jid)
    .attribute("xmlns", "jabber:client")
    .attribute("from", senderData.jid)
    .attribute("type", offline ? "unavailable" : "available");

  if (senderData.lastPresenceUpdate.away)
    xml = xml
      .element("show", "away")
      .up()
      .element("status", senderData.lastPresenceUpdate.status)
      .up();
  else xml = xml.element("status", senderData.lastPresenceUpdate.status).up();

  clientData.client.send(xml.toString());
}
