import type WebSocket from "ws";
import xmlbuilder from "xmlbuilder";
import { v4 as uuid } from "uuid";
import { logger } from "../../..";
import { Clients, MUCs } from "../state";
import { isObject } from "../utils";
import UpdateClientPresence from "./UpdateClientPresence";

export default function RemoveClient(ws: WebSocket, joinedMUCs: string[]): void {
  const clientIndex = Clients.findIndex((i) => i.client === ws);
  if (clientIndex === -1) return;

  const client = Clients[clientIndex];
  const clientStatus = JSON.parse(client.lastPresenceUpdate.status);

  void UpdateClientPresence(ws, "{}", false, true);

  Clients.splice(clientIndex, 1);

  for (const roomName of joinedMUCs) {
    if (MUCs[roomName]) {
      const memberIndex = MUCs[roomName].members.findIndex(
        (i) => i.accountId === client.accountId,
      );
      if (memberIndex !== -1) MUCs[roomName].members.splice(memberIndex, 1);
    }
  }

  let partyId = "";

  try {
    if (clientStatus.Properties && isObject(clientStatus.Properties)) {
      for (const key in clientStatus.Properties) {
        if (key.toLowerCase().startsWith("party.joininfo")) {
          if (isObject(clientStatus.Properties[key]))
            partyId = clientStatus.Properties[key].partyId;
        }
      }
    }
  } catch {}

  if (partyId && typeof partyId === "string") {
    Clients.forEach((clientData) => {
      if (client.accountId === clientData.accountId) return;

      clientData.client.send(
        xmlbuilder
          .create("message")
          .attribute("id", uuid().replace(/-/gi, "").toUpperCase())
          .attribute("from", client.jid)
          .attribute("xmlns", "jabber:client")
          .attribute("to", clientData.jid)
          .element(
            "body",
            JSON.stringify({
              type: "com.epicgames.party.memberexited",
              payload: {
                partyId,
                memberId: client.accountId,
                wasKicked: false,
              },
              timestamp: new Date().toISOString(),
            }),
          )
          .up()
          .toString(),
      );
    });
  }

  logger.info(`An xmpp client with the displayName ${client.displayName} has logged out.`);
}
