import xmlbuilder from "xmlbuilder";
import { Clients } from "../state";

export default function SendMessageToClient(senderJid: string, msg: any, body: string): void {
  const receiver = Clients.find(
    (i) => i.jid.split("/")[0] === msg.root.attributes.to || i.jid === msg.root.attributes.to,
  );
  if (!receiver) return;

  receiver.client.send(
    xmlbuilder
      .create("message")
      .attribute("from", senderJid)
      .attribute("id", msg.root.attributes.id)
      .attribute("to", receiver.jid)
      .attribute("xmlns", "jabber:client")
      .element("body", `${body}`)
      .up()
      .toString(),
  );
}
