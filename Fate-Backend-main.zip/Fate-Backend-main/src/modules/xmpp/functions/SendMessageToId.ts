import xmlbuilder from "xmlbuilder";
import { Clients, xmppDomain } from "../state";

export function sendXmppMessageToId(accountId: string, body: object | string): void {
  const payload = typeof body === "object" ? JSON.stringify(body) : body;

  const receiver = Clients.find((i) => i.accountId === accountId);
  if (!receiver) return;

  receiver.client.send(
    xmlbuilder
      .create("message")
      .attribute("from", `xmpp-admin@${xmppDomain}`)
      .attribute("to", receiver.jid)
      .attribute("xmlns", "jabber:client")
      .element("body", `${payload}`)
      .up()
      .toString(),
  );
}

export function sendXmppMessageToAll(body: object | string): void {
  const payload = typeof body === "object" ? JSON.stringify(body) : body;

  Clients.forEach((clientData) => {
    clientData.client.send(
      xmlbuilder
        .create("message")
        .attribute("from", `xmpp-admin@${xmppDomain}`)
        .attribute("xmlns", "jabber:client")
        .attribute("to", clientData.jid)
        .element("body", `${payload}`)
        .up()
        .toString(),
    );
  });
}
