import type WebSocket from "ws";
import xmlbuilder from "xmlbuilder";
import { friendsService } from "../../..";
import { Clients } from "../state";

export default async function UpdateClientPresence(
  ws: WebSocket,
  body: string,
  away: boolean,
  offline: boolean,
): Promise<void> {
  const senderIndex = Clients.findIndex((i) => i.client === ws);
  if (senderIndex === -1) return;

  const senderData = Clients[senderIndex];

  Clients[senderIndex].lastPresenceUpdate.away = away;
  Clients[senderIndex].lastPresenceUpdate.status = body;

  const friends = await friendsService.findFriendByAccountId(senderData.accountId);
  if (!friends) return;

  friends.accepted.forEach((friend) => {
    const clientData = Clients.find((i) => i.accountId === friend.accountId);
    if (!clientData) return;

    let xml = xmlbuilder
      .create("presence")
      .attribute("to", clientData.jid)
      .attribute("xmlns", "jabber:client")
      .attribute("from", senderData.jid)
      .attribute("type", offline ? "unavailable" : "available");

    if (away) xml = xml.element("show", "away").up().element("status", body).up();
    else xml = xml.element("status", body).up();

    clientData.client.send(xml.toString());
  });
}
