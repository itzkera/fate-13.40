import type WebSocket from "ws";
import XMLParser from "xml-parser";
import { Clients } from "./state";
import type { XmppSession } from "./state";
import { closeStream } from "./utils";
import Open from "./roots/Open";
import Auth from "./roots/Auth";
import Iq from "./roots/Iq";
import Message from "./roots/Message";
import Presence from "./roots/Presence";
import RemoveClient from "./functions/RemoveClient";

export function handleXmppConnection(ws: WebSocket): void {
  ws.on("error", () => {});

  const session: XmppSession = {
    ws,
    joinedMUCs: [],
    accountId: "",
    displayName: "",
    token: "",
    jid: "",
    resource: "",
    ID: "",
    authenticated: false,
    clientExists: false,
    connectionClosed: false,
  };

  ws.on("message", async (data) => {
    const message = Buffer.isBuffer(data)
      ? data.toString()
      : Array.isArray(data)
        ? Buffer.concat(data).toString()
        : Buffer.from(data).toString();

    const msg: any = XMLParser(message);
    if (!msg || !msg.root || !msg.root.name) return closeStream(ws);

    switch (msg.root.name) {
      case "open":
        Open(session);
        break;

      case "auth":
        await Auth(session, msg);
        break;

      case "iq":
        await Iq(session, msg);
        break;

      case "message":
        Message(session, msg);
        break;

      case "presence":
        await Presence(session, msg);
        break;
    }

    if (!session.clientExists && !session.connectionClosed) {
      if (
        session.accountId &&
        session.displayName &&
        session.token &&
        session.jid &&
        session.ID &&
        session.resource &&
        session.authenticated
      ) {
        Clients.push({
          client: ws,
          accountId: session.accountId,
          displayName: session.displayName,
          token: session.token,
          jid: session.jid,
          resource: session.resource,
          lastPresenceUpdate: { away: false, status: "{}" },
        });

        session.clientExists = true;
      }
    }
  });

  ws.on("close", () => {
    session.connectionClosed = true;
    session.clientExists = false;
    RemoveClient(ws, session.joinedMUCs);
  });
}
