import xmlbuilder from "xmlbuilder";
import { logger, userService, tokensService } from "../../..";
import { Clients } from "../state";
import type { XmppSession } from "../state";
import { closeStream, decodeBase64 } from "../utils";

const SASL_SEPARATOR = String.fromCharCode(0);

export default async function Auth(session: XmppSession, msg: any): Promise<void> {
  if (!session.ID) return;
  if (session.accountId) return;
  if (!msg.root.content) return closeStream(session.ws);
  if (!decodeBase64(msg.root.content).includes(SASL_SEPARATOR)) return closeStream(session.ws);

  const decoded = decodeBase64(msg.root.content).split(SASL_SEPARATOR);
  if (decoded.length !== 3) return closeStream(session.ws);

  const rawToken = decoded[2].replace("eg1~", "");
  const tokenData = await tokensService.getToken(rawToken);
  if (!tokenData || tokenData.accountId !== decoded[1]) return closeStream(session.ws);

  if (Clients.find((i) => i.accountId === tokenData.accountId)) return closeStream(session.ws);

  const user = await userService.findUserByAccountId(tokenData.accountId);
  if (!user || user.banned) return closeStream(session.ws);

  session.accountId = user.accountId;
  session.displayName = user.username;
  session.token = tokenData.token;

  if (session.accountId && session.displayName && session.token) {
    session.authenticated = true;
    logger.info(`An xmpp client with the displayName ${session.displayName} has logged in.`);

    session.ws.send(
      xmlbuilder
        .create("success")
        .attribute("xmlns", "urn:ietf:params:xml:ns:xmpp-sasl")
        .toString(),
    );
  } else return closeStream(session.ws);
}
