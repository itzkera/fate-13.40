import xmlbuilder from "xmlbuilder";
import { Clients, xmppDomain } from "../state";
import type { XmppSession } from "../state";
import { closeStream } from "../utils";
import GetPresenceFromFriends from "../functions/GetPresenceFromFriends";

export default async function Iq(session: XmppSession, msg: any): Promise<void> {
  if (!session.ID) return;

  switch (msg.root.attributes.id) {
    case "_xmpp_bind1": {
      if (session.resource || !session.accountId) return;

      const bind = msg.root.children.find((i: any) => i.name === "bind");
      if (!bind) return;

      if (Clients.find((i) => i.accountId === session.accountId))
        return closeStream(session.ws);

      const findResource = bind.children.find((i: any) => i.name === "resource");
      if (!findResource || !findResource.content) return;

      session.resource = findResource.content;
      session.jid = `${session.accountId}@${xmppDomain}/${session.resource}`;

      session.ws.send(
        xmlbuilder
          .create("iq")
          .attribute("to", session.jid)
          .attribute("id", "_xmpp_bind1")
          .attribute("xmlns", "jabber:client")
          .attribute("type", "result")
          .element("bind")
          .attribute("xmlns", "urn:ietf:params:xml:ns:xmpp-bind")
          .element("jid", session.jid)
          .up()
          .up()
          .toString(),
      );
      break;
    }

    case "_xmpp_session1":
      if (!session.clientExists) return closeStream(session.ws);

      session.ws.send(
        xmlbuilder
          .create("iq")
          .attribute("to", session.jid)
          .attribute("from", xmppDomain)
          .attribute("id", "_xmpp_session1")
          .attribute("xmlns", "jabber:client")
          .attribute("type", "result")
          .toString(),
      );

      await GetPresenceFromFriends(session);
      break;

    default:
      if (!session.clientExists) return closeStream(session.ws);

      session.ws.send(
        xmlbuilder
          .create("iq")
          .attribute("to", session.jid)
          .attribute("from", xmppDomain)
          .attribute("id", msg.root.attributes.id)
          .attribute("xmlns", "jabber:client")
          .attribute("type", "result")
          .toString(),
      );
  }
}
