import xmlbuilder from "xmlbuilder";
import { Clients, MUCs } from "../state";
import type { XmppSession } from "../state";
import { closeStream, getMUCmember, isJSON } from "../utils";
import SendMessageToClient from "../functions/SendMessageToClient";

export default function Message(session: XmppSession, msg: any): void {
  if (!session.clientExists) return closeStream(session.ws);

  const findBody = msg.root.children.find((i: any) => i.name === "body");
  if (!findBody || !findBody.content) return;

  const body = findBody.content;

  switch (msg.root.attributes.type) {
    case "chat": {
      if (!msg.root.attributes.to) return;
      if (body.length >= 300) return;

      const receiver = Clients.find(
        (i) => i.jid.split("/")[0] === msg.root.attributes.to,
      );
      if (!receiver) return;
      if (receiver.accountId === session.accountId) return;

      receiver.client.send(
        xmlbuilder
          .create("message")
          .attribute("to", receiver.jid)
          .attribute("from", session.jid)
          .attribute("xmlns", "jabber:client")
          .attribute("type", "chat")
          .element("body", body)
          .up()
          .toString(),
      );
      return;
    }

    case "groupchat": {
      if (!msg.root.attributes.to) return;
      if (body.length >= 300) return;

      const roomName = msg.root.attributes.to.split("@")[0];
      const muc = MUCs[roomName];
      if (!muc) return;
      if (!muc.members.find((i) => i.accountId === session.accountId)) return;

      muc.members.forEach((member) => {
        const clientData = Clients.find((i) => i.accountId === member.accountId);
        if (!clientData) return;

        clientData.client.send(
          xmlbuilder
            .create("message")
            .attribute("to", clientData.jid)
            .attribute(
              "from",
              getMUCmember(roomName, session.displayName, session.accountId, session.resource),
            )
            .attribute("xmlns", "jabber:client")
            .attribute("type", "groupchat")
            .element("body", body)
            .up()
            .toString(),
        );
      });
      return;
    }
  }

  if (isJSON(body)) {
    const bodyJSON = JSON.parse(body);

    if (Array.isArray(bodyJSON)) return;
    if (typeof bodyJSON.type !== "string") return;
    if (!msg.root.attributes.to) return;
    if (!msg.root.attributes.id) return;

    SendMessageToClient(session.jid, msg, body);
  }
}
