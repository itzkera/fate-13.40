import xmlbuilder from "xmlbuilder";
import { v4 as uuid } from "uuid";
import { xmppDomain } from "../state";
import type { XmppSession } from "../state";

export default function Open(session: XmppSession): void {
  if (!session.ID) session.ID = uuid();

  session.ws.send(
    xmlbuilder
      .create("open")
      .attribute("xmlns", "urn:ietf:params:xml:ns:xmpp-framing")
      .attribute("from", xmppDomain)
      .attribute("id", session.ID)
      .attribute("version", "1.0")
      .attribute("xml:lang", "en")
      .toString(),
  );

  if (session.authenticated) {
    session.ws.send(
      xmlbuilder
        .create("stream:features")
        .attribute("xmlns:stream", "http://etherx.jabber.org/streams")
        .element("ver")
        .attribute("xmlns", "urn:xmpp:features:rosterver")
        .up()
        .element("starttls")
        .attribute("xmlns", "urn:ietf:params:xml:ns:xmpp-tls")
        .up()
        .element("bind")
        .attribute("xmlns", "urn:ietf:params:xml:ns:xmpp-bind")
        .up()
        .element("compression")
        .attribute("xmlns", "http://jabber.org/features/compress")
        .element("method", "zlib")
        .up()
        .up()
        .element("session")
        .attribute("xmlns", "urn:ietf:params:xml:ns:xmpp-session")
        .up()
        .toString(),
    );
  } else {
    session.ws.send(
      xmlbuilder
        .create("stream:features")
        .attribute("xmlns:stream", "http://etherx.jabber.org/streams")
        .element("mechanisms")
        .attribute("xmlns", "urn:ietf:params:xml:ns:xmpp-sasl")
        .element("mechanism", "PLAIN")
        .up()
        .up()
        .element("ver")
        .attribute("xmlns", "urn:xmpp:features:rosterver")
        .up()
        .element("starttls")
        .attribute("xmlns", "urn:ietf:params:xml:ns:xmpp-tls")
        .up()
        .element("compression")
        .attribute("xmlns", "http://jabber.org/features/compress")
        .element("method", "zlib")
        .up()
        .up()
        .element("auth")
        .attribute("xmlns", "http://jabber.org/features/iq-auth")
        .up()
        .toString(),
    );
  }
}
