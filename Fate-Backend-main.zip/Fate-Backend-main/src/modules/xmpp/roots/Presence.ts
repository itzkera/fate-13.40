import xmlbuilder from "xmlbuilder";
import { Clients, MUCs, xmppDomain } from "../state";
import type { XmppSession } from "../state";
import { closeStream, getMUCmember, isJSON } from "../utils";
import UpdateClientPresence from "../functions/UpdateClientPresence";
import GetPresenceFromUser from "../functions/GetPresenceFromUser";

export default async function Presence(session: XmppSession, msg: any): Promise<void> {
  if (!session.clientExists) return closeStream(session.ws);

  const { accountId, displayName, resource, jid } = session;

  if (msg.root.attributes.type === "unavailable") {
    if (!msg.root.attributes.to) return;

    if (
      msg.root.attributes.to.endsWith(`@muc.${xmppDomain}`) ||
      msg.root.attributes.to.split("/")[0].endsWith(`@muc.${xmppDomain}`)
    ) {
      if (!msg.root.attributes.to.toLowerCase().startsWith("party-")) return;

      const roomName = msg.root.attributes.to.split("@")[0];
      if (!MUCs[roomName]) return;

      const memberIndex = MUCs[roomName].members.findIndex(
        (i) => i.accountId === accountId,
      );
      if (memberIndex !== -1) {
        MUCs[roomName].members.splice(memberIndex, 1);
        session.joinedMUCs.splice(session.joinedMUCs.indexOf(roomName), 1);
      }

      session.ws.send(
        xmlbuilder
          .create("presence")
          .attribute("to", jid)
          .attribute("from", getMUCmember(roomName, displayName, accountId, resource))
          .attribute("xmlns", "jabber:client")
          .attribute("type", "unavailable")
          .element("x")
          .attribute("xmlns", "http://jabber.org/protocol/muc#user")
          .element("item")
          .attribute(
            "nick",
            getMUCmember(roomName, displayName, accountId, resource).replace(
              `${roomName}@muc.${xmppDomain}/`,
              "",
            ),
          )
          .attribute("jid", jid)
          .attribute("role", "none")
          .up()
          .element("status")
          .attribute("code", "110")
          .up()
          .element("status")
          .attribute("code", "100")
          .up()
          .element("status")
          .attribute("code", "170")
          .up()
          .up()
          .toString(),
      );
      return;
    }
  } else if (
    msg.root.children.find((i: any) => i.name === "muc:x") ||
    msg.root.children.find((i: any) => i.name === "x")
  ) {
    if (!msg.root.attributes.to) return;

    const roomName = msg.root.attributes.to.split("@")[0];

    if (!MUCs[roomName]) MUCs[roomName] = { members: [] };
    if (MUCs[roomName].members.find((i) => i.accountId === accountId)) return;

    MUCs[roomName].members.push({ accountId });
    session.joinedMUCs.push(roomName);

    session.ws.send(
      xmlbuilder
        .create("presence")
        .attribute("to", jid)
        .attribute("from", getMUCmember(roomName, displayName, accountId, resource))
        .attribute("xmlns", "jabber:client")
        .element("x")
        .attribute("xmlns", "http://jabber.org/protocol/muc#user")
        .element("item")
        .attribute(
          "nick",
          getMUCmember(roomName, displayName, accountId, resource).replace(
            `${roomName}@muc.${xmppDomain}/`,
            "",
          ),
        )
        .attribute("jid", jid)
        .attribute("role", "participant")
        .attribute("affiliation", "none")
        .up()
        .element("status")
        .attribute("code", "110")
        .up()
        .element("status")
        .attribute("code", "100")
        .up()
        .element("status")
        .attribute("code", "170")
        .up()
        .element("status")
        .attribute("code", "201")
        .up()
        .up()
        .toString(),
    );

    MUCs[roomName].members.forEach((member) => {
      const clientData = Clients.find((i) => i.accountId === member.accountId);
      if (!clientData) return;

      session.ws.send(
        xmlbuilder
          .create("presence")
          .attribute(
            "from",
            getMUCmember(
              roomName,
              clientData.displayName,
              clientData.accountId,
              clientData.resource,
            ),
          )
          .attribute("to", jid)
          .attribute("xmlns", "jabber:client")
          .element("x")
          .attribute("xmlns", "http://jabber.org/protocol/muc#user")
          .element("item")
          .attribute(
            "nick",
            getMUCmember(
              roomName,
              clientData.displayName,
              clientData.accountId,
              clientData.resource,
            ).replace(`${roomName}@muc.${xmppDomain}/`, ""),
          )
          .attribute("jid", clientData.jid)
          .attribute("role", "participant")
          .attribute("affiliation", "none")
          .up()
          .up()
          .toString(),
      );

      if (accountId === clientData.accountId) return;

      clientData.client.send(
        xmlbuilder
          .create("presence")
          .attribute("from", getMUCmember(roomName, displayName, accountId, resource))
          .attribute("to", clientData.jid)
          .attribute("xmlns", "jabber:client")
          .element("x")
          .attribute("xmlns", "http://jabber.org/protocol/muc#user")
          .element("item")
          .attribute(
            "nick",
            getMUCmember(roomName, displayName, accountId, resource).replace(
              `${roomName}@muc.${xmppDomain}/`,
              "",
            ),
          )
          .attribute("jid", jid)
          .attribute("role", "participant")
          .attribute("affiliation", "none")
          .up()
          .up()
          .toString(),
      );
    });
    return;
  }

  const findStatus = msg.root.children.find((i: any) => i.name === "status");
  if (!findStatus || !findStatus.content) return;
  if (!isJSON(findStatus.content)) return;
  if (Array.isArray(JSON.parse(findStatus.content))) return;

  const status = findStatus.content;
  const away = msg.root.children.some((i: any) => i.name === "show");

  await UpdateClientPresence(session.ws, status, away, false);
  GetPresenceFromUser(accountId, accountId, false);
}
