import type WebSocket from "ws";

export const xmppDomain = "prod.ol.epicgames.com";

export interface XmppClient {
  client: WebSocket;
  accountId: string;
  displayName: string;
  token: string;
  jid: string;
  resource: string;
  lastPresenceUpdate: { away: boolean; status: string };
}

export interface MUCMember {
  accountId: string;
}

export interface MUC {
  members: MUCMember[];
}

export interface XmppSession {
  ws: WebSocket;
  joinedMUCs: string[];
  accountId: string;
  displayName: string;
  token: string;
  jid: string;
  resource: string;
  ID: string;
  authenticated: boolean;
  clientExists: boolean;
  connectionClosed: boolean;
}

export const Clients: XmppClient[] = [];
export const MUCs: Record<string, MUC> = {};
