import type WebSocket from "ws";
import xmlbuilder from "xmlbuilder";
import { xmppDomain } from "./state";

export function decodeBase64(value: string): string {
  return Buffer.from(value, "base64").toString("utf-8");
}

export function closeStream(ws: WebSocket): void {
  ws.send(
    xmlbuilder.create("close").attribute("xmlns", "urn:ietf:params:xml:ns:xmpp-framing").toString(),
  );
  ws.close();
}

export function isObject(value: unknown): boolean {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function isJSON(str: string): boolean {
  try {
    JSON.parse(str);
  } catch {
    return false;
  }
  return true;
}

export function getMUCmember(
  roomName: string,
  displayName: string,
  accountId: string,
  resource: string,
): string {
  return `${roomName}@muc.${xmppDomain}/${encodeURI(displayName)}:${accountId}:${resource}`;
}
