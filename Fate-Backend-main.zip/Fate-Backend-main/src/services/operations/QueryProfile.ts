import type { Context } from "hono";
import { userService, accountService, logger, profilesService, questsService, config } from "../..";
import errors from "../../utilities/errors";
import type { ProfileId } from "../../utilities/responses";
import ProfileHelper from "../../utilities/ProfileHelper";
import MCPResponses from "../../utilities/responses";
import uaparser from "../../utilities/uaparser";
import { LRUCache } from "lru-cache";
import type { IProfile, ItemValue } from "../../../types/profilesdefs";
import { type QuestDictionary, type QuestItem } from "../../../types/questdefs";
import { v4 as uuid } from "uuid";
import PlatformManager from "../../utilities/managers/PlatformManager";
import { handleProfileSelection } from "../../utilities/profile_cache";

export default async function (c: Context) {
  const { url } = c.req;
  const accountId = c.req.param("accountId");
  const rvn = c.req.query("rvn");
  const profileId = c.req.query("profileId") as ProfileId;
  const useragent = c.req.header("User-Agent");

  const timestamp = new Date().toISOString();
  if (!useragent)
    return c.json(errors.createError(400, url, "Missing 'User-Agent'.", timestamp), 400);

  const uahelper = uaparser(useragent);
  if (!uahelper)
    return c.json(errors.createError(400, url, "Invalid 'User-Agent'.", timestamp), 400);

  if (!accountId || !rvn || !profileId)
    return c.json(errors.createError(400, url, "Missing parameters.", timestamp), 400);

  try {
    const user = await userService.findUserByAccountId(accountId);

    if (!user) return c.json(errors.createError(404, url, "User not found.", timestamp), 404);

    const profile = await handleProfileSelection(profileId, user.accountId);
    if (!profile)
      return c.json(
        errors.createError(404, url, `Profile '${profileId}' not found.`, timestamp),
        404,
      );

    console.log(profileId);

    if (profileId === "collections") {
      return c.json(
        MCPResponses.generate(
          {
            _id: "",
            createdAt: "",
            updatedAt: "",
            rvn: 0,
            wipeNumber: 1,
            accountId: "",
            profileId: "collections",
            version: "no_version",
            items: {},
            stats: {
              attributes: {
                inventory_limit_bonus: 0,
              },
            },
            commandRevision: 0,
          },
          [{ changeType: "fullProfileUpdate", profile }],
          profileId,
        ),
      );
    }

    const {
      stats: { attributes },
    } = profile;
    let past_seasons = attributes.past_seasons || [];
    let campaign_stats = attributes.campaign_stats || [];

    if (profileId === "athena") {
      attributes.season_num = uahelper.season;

      const currentSeasonIndex = past_seasons.findIndex(
        (season) => season.seasonNumber === uahelper.season,
      );
      if (currentSeasonIndex !== -1) {
        const currentSeason = past_seasons[currentSeasonIndex];

        const allQuests = await questsService.findAllQuestsByAccountIdAndProfile(
          user.accountId,
          "athena",
        );

        for (const quest of allQuests) {
          if (quest.season !== config.currentSeason && !quest.isDaily) {
            await questsService.deleteQuestByTemplateId(
              user.accountId,
              uahelper.season,
              quest.templateId,
            );
          }
        }

        Object.assign(attributes, {
          ...currentSeason,
          book_purchased: currentSeason.purchasedVIP,
          book_level: currentSeason.bookLevel,
          book_xp: currentSeason.bookXp,
          level: currentSeason.seasonLevel,
          xp: currentSeason.seasonXp,
          season: {
            numWins: currentSeason.numWins,
            numLowBracket: currentSeason.numLowBracket,
            numHighBracket: currentSeason.numHighBracket,
          },
        });

        profile.items = {
          ...(
            await questsService.findAllQuestsByAccountIdAndProfile(user.accountId, "athena")
          ).reduce<QuestDictionary>(
            (acc, item) => ({
              ...acc,
              [item.templateId]: {
                attributes: item.entity,
                templateId: item.templateId,
                quantity: 1,
              },
            }),
            {},
          ),
          ...profile.items,
        };
      } else {
        past_seasons.push({
          seasonNumber: uahelper.season,
          numWins: 0,
          numHighBracket: 0,
          numLowBracket: 0,
          seasonXp: attributes.xp ?? 0,
          seasonLevel: attributes.level ?? 1,
          bookXp: attributes.book_xp ?? 0,
          bookLevel: attributes.book_level ?? 1,
          purchasedVIP: attributes.book_purchased ?? false,
          numRoyalRoyales: 0,
          survivorTier: 0,
          survivorPrestige: 0,
        });

        attributes.xp ??= 0;
        attributes.level ??= 1;
        attributes.book_purchased ??= false;
        attributes.book_level ??= 1;
        attributes.book_xp ??= 0;
      }

      attributes.past_seasons = past_seasons;
      await profilesService.update(user.accountId, "athena", profile);
    }

    if (profileId === "common_core") {
      attributes.permissions = attributes.permissions || [];
      const clientPlatform = PlatformManager.getClientPlatformByUserAgent(c);

      const platform = PlatformManager.getPlatform(clientPlatform as string);

      profile.stats.attributes.current_mtx_platform = platform;
      profile.items["Currency:MtxPurchased"].attributes.platform = platform;

      await profilesService.update(user.accountId, "common_core", profile);
    }

    if (profileId === "campaign" && parseInt(rvn) !== -1) {
      Object.assign(profile, {
        updatedAt: timestamp,
        rvn: profile.rvn + 1,
        commandRevision: profile.commandRevision + 1,
      });

      attributes.season_num = uahelper.season;

      const currentSeasonIndex = campaign_stats.findIndex(
        (season) => season.season === uahelper.season,
      );

      if (currentSeasonIndex !== -1) {
        const currentSeason = campaign_stats[currentSeasonIndex];

        const allQuests = await questsService.findAllQuestsByAccountIdAndProfile(
          user.accountId,
          "campaign",
        );

        for (const quest of allQuests.filter((quest) => quest.season !== config.currentSeason)) {
          await questsService.deleteQuestByTemplateId(
            user.accountId,
            uahelper.season,
            quest.templateId,
          );

          logger.info(`Deleted quest: ${quest.templateId}`);
        }

        Object.assign(attributes, currentSeason);

        const newQuestId = uuid();

        const existingQuests = profile.items || {};

        const questDictionary = (
          await questsService.findAllQuestsByAccountIdAndProfile(user.accountId, "campaign")
        ).reduce<QuestDictionary>((acc, item) => {
          const templateId = item.templateId;

          if (existingQuests[templateId]) {
            existingQuests[templateId].attributes = {
              ...existingQuests[templateId].attributes,
              ...item.entity,
            };
          } else {
            acc[templateId] = {
              itemId: templateId,
              attributes: item.entity,
              templateId: item.templateId,
              quantity: 1,
            };
          }

          return acc;
        }, existingQuests);

        await profilesService.update(user.accountId, "campaign", profile);
      } else {
        campaign_stats.push({
          season: uahelper.season,
        });
      }

      attributes.campaign_stats = campaign_stats;

      await profilesService.update(user.accountId, "campaign", profile);
    }

    return c.json(
      MCPResponses.generate(profile, [{ changeType: "fullProfileUpdate", profile }], profileId),
    );
  } catch (error) {
    logger.error(`Error in QueryProfile: ${error}`);
    return c.json(errors.createError(500, url, "Internal server error.", timestamp), 500);
  }
}
