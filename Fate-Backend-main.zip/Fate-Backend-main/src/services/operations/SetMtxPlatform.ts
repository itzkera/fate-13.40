import type { Context } from "hono";
import type { ProfileId } from "../../utilities/responses";
import errors from "../../utilities/errors";
import { accountService, profilesService, userService } from "../..";
import ProfileHelper from "../../utilities/ProfileHelper";
import MCPResponses from "../../utilities/responses";
import { Account } from "../../tables/account";
import { Profiles } from "../../tables/profiles";
import { handleProfileSelection } from "../../utilities/profile_cache";

export default async function (c: Context) {
  const accountId = c.req.param("accountId");
  const rvn = c.req.query("rvn");
  const profileId = c.req.query("profileId") as ProfileId;

  const timestamp = new Date().toISOString();

  if (!accountId || !rvn || !profileId) {
    return c.json(errors.createError(400, c.req.url, "Missing query parameters.", timestamp), 400);
  }

  const user = await userService.findUserByAccountId(accountId);

  if (!user) {
    return c.json(errors.createError(404, c.req.url, "Failed to find user.", timestamp), 404);
  }

  const profile = await handleProfileSelection(profileId, user.accountId);

  if (!profile && profileId !== "athena" && profileId !== "common_core")
    return c.json(
      errors.createError(404, c.req.url, `Profile ${profileId} was not found.`, timestamp),
      404,
    );

  if (!profile)
    return c.json(
      errors.createError(404, c.req.url, `Profile '${profileId}' not found.`, timestamp),
      404,
    );

  let body;
  try {
    body = await c.req.json();
  } catch (error) {
    return c.json({ error: "Body isn't valid JSON" }, 400);
  }

  const { newPlatform } = body;

  if (!newPlatform)
    return c.json(
      errors.createError(400, c.req.url, `The parameter 'newPlatform' is missing.`, timestamp),
      400,
    );

  for (const item in profile.items) {
    profile.items[item].attributes.platform = newPlatform;
    profile.stats.attributes.current_mtx_platform = newPlatform;
  }

  profile.rvn += 1;
  profile.commandRevision += 1;
  profile.updatedAt = new Date().toISOString();

  await profilesService.update(user.accountId, "common_core", profile);

  return c.json(
    MCPResponses.generate(
      profile,
      [{ changeType: "statModified", name: "current_mtx_platform", value: newPlatform }],
      profileId,
    ),
  );
}
