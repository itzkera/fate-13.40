import { app, deviceAuthService, userService } from "../..";
import { Validation } from "../../modules/middleware/validation";
import errors from "../../utilities/errors";
import crypto from "node:crypto";
import { v4 as uuid } from "uuid";

export default function () {
  app.post("/fortnite/api/game/v2/tryPlayOnPlatform/account/:accountId", async (c) => {
    c.header("Content-Type", "text/plain");
    return c.text("true");
  });

  app.get("/account/api/public/account/:accountId/externalAuths", async (c) => {
    return c.json([]);
  });

  app.get("/fortnite/api/game/v2/enabled_features", async (c) => {
    return c.json([]);
  });

  app.get("/account/api/public/account/:accountId", Validation.verifyToken, async (c) => {
    const accountId = c.req.param("accountId");
    const user = await userService.findUserByAccountId(accountId);
    const timestamp = new Date().toISOString();

    if (!user)
      return c.json(errors.createError(404, c.req.url, "Failed to find user.", timestamp), 404);

    if (user.banned)
      return c.json(errors.createError(403, c.req.url, "This user is banned.", timestamp), 403);

    return c.json({
      id: accountId,
      displayName: user.username,
      name: user.username,
      email: `${user.username}@********`,
      failedLoginAttempts: 0,
      lastLogin: new Date().toISOString(),
      numberOfDisplayNameChanges: 0,
      ageGroup: "UNKNOWN",
      headless: false,
      country: "NAE",
      lastName: "",
      preferredLanguage: "en",
      canUpdateDisplayName: false,
      tfaEnabled: false,
      emailVerified: true,
      minorVerified: false,
      minorExpected: false,
      minorStatus: "NOT_MINOR",
      cabinedMode: false,
      hasHashedEmail: false,
    });
  });

  app.get("/account/api/public/account", Validation.verifyToken, async (c) => {
    const accountIdQuery = c.req.query("accountId");
    const timestamp = new Date().toISOString();

    if (!accountIdQuery)
      return c.json(
        errors.createError(400, c.req.url, "Parameter 'accountId' is missing.", timestamp),
        400,
      );

    const response: any[] = [];

    if (accountIdQuery!.includes(",")) {
      const accountIds: string[] = accountIdQuery.split(",");

      for (const accountId of accountIds) {
        const user = await userService.findUserByAccountId(accountId);

        if (!user)
          return c.json(errors.createError(404, c.req.url, "Failed to find user.", timestamp), 404);

        response.push({
          id: user.accountId,
          displayName: user.username,
          externalAuth: {},
        });
      }
    } else {
      const user =
        (await userService.findUserByAccountId(accountIdQuery)) ??
        (await userService.findUserByEmail(accountIdQuery + "@epicgames.dev"));

      if (!user)
        return c.json(errors.createError(404, c.req.url, "Failed to find user.", timestamp), 404);

      response.push({
        id: user.accountId,
        links: {},
        displayName: user.username,
        cabinedMode: false,
        externalAuth: {},
      });
    }

    return c.json(response);
  });

  app.post(
    "/account/api/public/account/:accountId/deviceAuth",
    Validation.verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");
      const timestamp = new Date().toISOString();

      const user = await userService.findUserByAccountId(accountId);
      if (!user)
        return c.json(errors.createError(404, c.req.url, "Failed to find user.", timestamp), 404);

      const deviceId = uuid().replace(/-/g, "");
      const secret = crypto.randomBytes(16).toString("hex").toUpperCase();
      const ipAddress = c.req.header("x-forwarded-for") ?? "127.0.0.1";
      const userAgent = c.req.header("user-agent") ?? "";
      const dateTime = timestamp;

      const created = { location: "Unknown", ipAddress, dateTime };

      const auth = await deviceAuthService.create({
        deviceId,
        accountId,
        secret,
        userAgent,
        created,
        lastAccess: null,
      });

      if (!auth)
        return c.json(
          errors.createError(500, c.req.url, "Failed to create device auth.", timestamp),
          500,
        );

      return c.json({
        deviceId: auth.deviceId,
        accountId: auth.accountId,
        secret: auth.secret,
        userAgent: auth.userAgent,
        created: auth.created,
      });
    },
  );

  app.delete(
    "/account/api/public/account/:accountId/deviceAuth/:deviceId",
    Validation.verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");
      const deviceId = c.req.param("deviceId");
      const timestamp = new Date().toISOString();

      const user = await userService.findUserByAccountId(accountId);
      if (!user)
        return c.json(errors.createError(404, c.req.url, "Failed to find user.", timestamp), 404);

      const deleted = await deviceAuthService.deleteByDeviceId(deviceId, accountId);
      if (!deleted)
        return c.json(
          errors.createError(404, c.req.url, "Device auth not found.", timestamp),
          404,
        );

      return c.body(null, 204);
    },
  );

  app.get(
    "/account/api/public/account/:accountId/deviceAuth/:deviceId",
    Validation.verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");
      const deviceId = c.req.param("deviceId");
      const timestamp = new Date().toISOString();

      const user = await userService.findUserByAccountId(accountId);
      if (!user)
        return c.json(errors.createError(404, c.req.url, "Failed to find user.", timestamp), 404);

      const auth = await deviceAuthService.findByDeviceId(deviceId);
      if (!auth || auth.accountId !== accountId)
        return c.json(
          errors.createError(404, c.req.url, "Device auth not found.", timestamp),
          404,
        );

      const response: Record<string, unknown> = {
        deviceId: auth.deviceId,
        accountId: auth.accountId,
        userAgent: auth.userAgent,
        created: auth.created,
      };
      if (auth.lastAccess) response.lastAccess = auth.lastAccess;

      return c.json(response);
    },
  );

  app.get(
    "/account/api/public/account/:accountId/deviceAuth",
    Validation.verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");
      const timestamp = new Date().toISOString();

      const user = await userService.findUserByAccountId(accountId);
      if (!user)
        return c.json(errors.createError(404, c.req.url, "Failed to find user.", timestamp), 404);

      const auths = await deviceAuthService.findAllByAccountId(accountId);

      return c.json(
        auths.map((auth) => {
          const entry: Record<string, unknown> = {
            deviceId: auth.deviceId,
            accountId: auth.accountId,
            userAgent: auth.userAgent,
            created: auth.created,
          };
          if (auth.lastAccess) entry.lastAccess = auth.lastAccess;
          return entry;
        }),
      );
    },
  );

  app.get(
    "/account/api/public/account/displayName/:username",
    Validation.verifyToken,
    async (c) => {
      const username = c.req.param("username");
      const timestamp = new Date().toISOString();

      const user = await userService.findUserByUsername(username);

      if (!user)
        return c.json(errors.createError(404, c.req.url, "Failed to find user.", timestamp), 404);

      return c.json({
        id: user.accountId,
        displayName: user.username,
        externalAuths: {},
      });
    },
  );
}
