import {
  accountService,
  app,
  banService,
  config,
  contentPageService,
  friendsService,
  itemStorageService,
  profilesService,
  receiptsService,
  seasonStatsService,
  sessionsService,
  tokensService,
  userService,
} from "../..";
import {
  listExchangeCodes,
  revokeExchangeCode,
} from "../../utilities/launcher/exchangecodes";

import type { Context } from "hono";
import ProfileHelper from "../../utilities/ProfileHelper";
import jwt from "jsonwebtoken";
import path from "node:path";
import { serverState } from "../../utilities/state";
import { v4 as uuid } from "uuid";

const ADMIN_KEY = config.admin_key;
const JWT_SECRET = config.jwt_secret;

async function requireAuth(c: Context): Promise<string | null> {
  const key = c.req.header("x-admin-key");
  if (key && ADMIN_KEY && key === ADMIN_KEY) return "api-key";

  const auth = c.req.header("Authorization");
  if (auth?.startsWith("Bearer ")) {
    try {
      const payload = jwt.verify(auth.slice(7), JWT_SECRET) as any;
      return payload.username ?? "admin";
    } catch {
      return null;
    }
  }
  return null;
}

function audit(
  admin: string,
  action: string,
  target?: string,
  details?: Record<string, any>,
) {
  serverState.auditLog.unshift({
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    admin,
    action,
    target,
    details,
  });
  if (serverState.auditLog.length > 1000) serverState.auditLog.length = 1000;
}

function randomUsername(): string {
  return `dev_${crypto.randomUUID().replace(/-/g, "").slice(0, 12)}`;
}

export default function () {
  app.post("/admin/auth/login", async (c) => {
    const body = (await c.req.json().catch(() => null)) as any;
    const key = body?.key ?? "";
    const username =
      typeof body?.username === "string" ? body.username : "admin";

    if (!ADMIN_KEY || key !== ADMIN_KEY) {
      return c.json({ error: "invalid credentials" }, 401);
    }

    const token = jwt.sign({ sub: "admin", username }, JWT_SECRET, {
      expiresIn: "24h",
    });
    audit(username, "login");
    return c.json({ token, username });
  });

  app.get("/admin/api/stats", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const [totalUsers, bannedUsers] = await Promise.all([
      (userService as any).userRepository.count(),
      (userService as any).userRepository.count({ where: { banned: true } }),
    ]);
    const activeSessions = (await sessionsService.findAll()).length;
    const { listExchangeCodes: listCodes } =
      await import("../../utilities/launcher/exchangecodes");
    return c.json({
      totalUsers,
      bannedUsers,
      activeSessions,
      activeExchangeCodes: listCodes().length,
    });
  });

  app.get("/admin/api/status", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    return c.json({
      status: serverState.status,
      matchmakingEnabled: serverState.matchmakingEnabled,
      autorotateEnabled: serverState.autorotateEnabled,
      discordOAuthEnabled: serverState.discordOAuthEnabled,
    });
  });

  app.post("/admin/api/settings", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const body = (await c.req.json()) as any;
    if (typeof body.discordOAuthEnabled === "boolean") {
      serverState.discordOAuthEnabled = body.discordOAuthEnabled;
      audit(admin, "settings_update", undefined, {
        discordOAuthEnabled: body.discordOAuthEnabled,
      });
    }
    return c.json({
      status: serverState.status,
      matchmakingEnabled: serverState.matchmakingEnabled,
      autorotateEnabled: serverState.autorotateEnabled,
      discordOAuthEnabled: serverState.discordOAuthEnabled,
    });
  });

  app.post("/admin/api/status", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const body = (await c.req.json()) as any;
    if (body.status === "UP" || body.status === "DOWN") {
      serverState.status = body.status;
      audit(admin, "maintenance_toggle", undefined, { status: body.status });
    }
    return c.json({ status: serverState.status });
  });

  app.get("/admin/api/matchmaking", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    return c.json({ enabled: serverState.matchmakingEnabled });
  });

  app.post("/admin/api/matchmaking", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const body = (await c.req.json()) as any;
    serverState.matchmakingEnabled = body.enabled !== false;
    audit(admin, "matchmaking_toggle", undefined, {
      enabled: serverState.matchmakingEnabled,
    });
    return c.json({ enabled: serverState.matchmakingEnabled });
  });

  app.get("/admin/api/hotfixes", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    return c.json(serverState.hotfixes);
  });

  app.post("/admin/api/hotfixes", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const body = (await c.req.json()) as any;
    const entry = {
      id: crypto.randomUUID(),
      name: body.name ?? "Unnamed Hotfix",
      content: body.content ?? "",
      createdAt: new Date().toISOString(),
    };
    serverState.hotfixes.push(entry);
    await itemStorageService.addItems([
      { data: serverState.hotfixes, type: "hotfixes" },
    ]);
    audit(admin, "hotfix_create", entry.id, { name: entry.name });
    return c.json(entry, 201);
  });

  app.put("/admin/api/hotfixes/:id", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const id = c.req.param("id");
    const body = (await c.req.json()) as any;
    const idx = serverState.hotfixes.findIndex((h) => h.id === id);
    if (idx === -1) return c.json({ error: "not found" }, 404);
    if (body.name !== undefined) serverState.hotfixes[idx].name = body.name;
    if (body.content !== undefined)
      serverState.hotfixes[idx].content = body.content;
    await itemStorageService.addItems([
      { data: serverState.hotfixes, type: "hotfixes" },
    ]);
    audit(admin, "hotfix_update", id);
    return c.json(serverState.hotfixes[idx]);
  });

  app.delete("/admin/api/hotfixes/:id", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const id = c.req.param("id");
    const before = serverState.hotfixes.length;
    serverState.hotfixes = serverState.hotfixes.filter((h) => h.id !== id);
    if (serverState.hotfixes.length === before)
      return c.json({ error: "not found" }, 404);
    await itemStorageService.addItems([
      { data: serverState.hotfixes, type: "hotfixes" },
    ]);
    audit(admin, "hotfix_delete", id);
    return c.json({ success: true });
  });

  app.get("/admin/api/contentpages", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const [brNews, playlists, tournaments, background] = await Promise.all([
      contentPageService.getBattleRoyaleNews(),
      contentPageService.getPlaylistInfo(),
      contentPageService.getTournamentInfo(),
      contentPageService.getDynamicBackground(),
    ]);
    return c.json({ brNews, playlists, tournaments, background });
  });

  app.put("/admin/api/contentpages/br-news/:id", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const id = c.req.param("id");
    const body = (await c.req.json()) as any;
    const updated = await contentPageService.updateBattleRoyaleNews(id, body);
    audit(admin, "contentpage_br_news_update", id);
    return c.json(updated);
  });

  app.post("/admin/api/contentpages/br-news", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const body = (await c.req.json()) as any;
    const created = await contentPageService.createBattleRoyaleNews(body);
    audit(admin, "contentpage_br_news_create");
    return c.json(created, 201);
  });

  app.delete("/admin/api/contentpages/br-news/:id", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const id = c.req.param("id");
    await contentPageService.deleteBattleRoyaleNews(id);
    audit(admin, "contentpage_br_news_delete", id);
    return c.json({ success: true });
  });

  app.put("/admin/api/contentpages/background/:id", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const id = c.req.param("id");
    const body = (await c.req.json()) as any;
    const updated = await contentPageService.updateDynamicBackground(id, body);
    audit(admin, "contentpage_background_update", id);
    return c.json(updated);
  });

  app.get("/admin/api/tournaments", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const data = await contentPageService.getTournamentInfo();
    return c.json(data ?? {});
  });

  app.post("/admin/api/tournaments", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const body = (await c.req.json()) as any;
    const created = await contentPageService.createTournamentInfo(body);
    audit(admin, "tournament_create");
    return c.json(created, 201);
  });

  app.put("/admin/api/tournaments/:id", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const id = c.req.param("id");
    const body = (await c.req.json()) as any;
    const updated = await contentPageService.updateTournamentInfo(id, body);
    audit(admin, "tournament_update", id);
    return c.json(updated);
  });

  app.delete("/admin/api/tournaments/:id", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const id = c.req.param("id");
    await contentPageService.deleteTournamentInfo(id);
    audit(admin, "tournament_delete", id);
    return c.json({ success: true });
  });

  app.get("/admin/api/players", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const q = c.req.query("q");
    const page = Math.max(1, parseInt(c.req.query("page") ?? "1"));
    const limit = Math.min(
      100,
      Math.max(1, parseInt(c.req.query("limit") ?? "50")),
    );

    if (q) {
      const [byUsername, byEmail] = await Promise.all([
        userService.findUserByUsername(q).catch(() => null),
        userService.findUserByEmail(q).catch(() => null),
      ]);
      const seen = new Set<string>();
      const results = [byUsername, byEmail].filter(
        (u): u is NonNullable<typeof u> => {
          if (!u || seen.has(u.accountId)) return false;
          seen.add(u.accountId);
          return true;
        },
      );
      return c.json(
        results.map((u) => ({
          accountId: u.accountId,
          username: u.username,
          email: u.email,
          banned: u.banned,
          has_all_items: u.has_all_items,
          lastLogin: u.lastLogin,
        })),
      );
    }

    const users = await (userService as any).userRepository.find({
      skip: (page - 1) * limit,
      take: limit,
      order: { username: "ASC" },
    });

    return c.json(
      users.map((u: any) => ({
        accountId: u.accountId,
        username: u.username,
        email: u.email,
        banned: u.banned,
        has_all_items: u.has_all_items,
        lastLogin: u.lastLogin,
      })),
    );
  });

  app.get("/admin/api/player/:accountId", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const accountId = c.req.param("accountId");
    const [user, account] = await Promise.all([
      userService.findUserByAccountId(accountId),
      accountService.findUserByAccountId(accountId),
    ]);
    if (!user) return c.json({ error: "not found" }, 404);

    const [athena, common_core] = await Promise.all([
      ProfileHelper.getProfile(accountId, "athena"),
      ProfileHelper.getProfile(accountId, "common_core"),
    ]);

    const level = (athena?.stats?.attributes as any)?.level ?? 0;

    const vbucks = Object.values(common_core?.items ?? {}).reduce(
      (sum, item) => {
        if ((item as any).templateId?.startsWith("Currency:Mtx")) {
          return sum + ((item as any).quantity ?? 0);
        }
        return sum;
      },
      0,
    );

    const lockerCount = Object.values(athena?.items ?? {}).filter((item) => {
      const t = (item as any).templateId ?? "";
      return (
        t.startsWith("AthenaCharacter:") ||
        t.startsWith("AthenaBackpack:") ||
        t.startsWith("AthenaPickaxe:") ||
        t.startsWith("AthenaGlider:") ||
        t.startsWith("AthenaDance:")
      );
    }).length;

    return c.json({
      accountId: user.accountId,
      username: user.username,
      email: user.email,
      discordId: user.discordId,
      banned: user.banned,
      has_all_items: user.has_all_items,
      roles: user.roles,
      lastLogin: user.lastLogin,
      arenaHype: account?.arenaHype ?? 0,
      level,
      vbucks,
      lockerCount,
    });
  });

  app.get("/admin/api/player/:accountId/locker", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const accountId = c.req.param("accountId");
    const user = await userService.findUserByAccountId(accountId);
    if (!user) return c.json({ error: "not found" }, 404);

    const athena = await ProfileHelper.getProfile(accountId, "athena");
    const locker: Record<string, string[]> = {
      skins: [],
      backblings: [],
      pickaxes: [],
      gliders: [],
      emotes: [],
      wraps: [],
      other: [],
    };

    for (const item of Object.values(athena?.items ?? {})) {
      const t = (item as any).templateId ?? "";
      if (t.startsWith("AthenaCharacter:")) locker.skins.push(t);
      else if (t.startsWith("AthenaBackpack:")) locker.backblings.push(t);
      else if (t.startsWith("AthenaPickaxe:")) locker.pickaxes.push(t);
      else if (t.startsWith("AthenaGlider:")) locker.gliders.push(t);
      else if (t.startsWith("AthenaDance:")) locker.emotes.push(t);
      else if (t.startsWith("AthenaItemWrap:")) locker.wraps.push(t);
      else if (t.startsWith("Athena")) locker.other.push(t);
    }

    return c.json({
      ...locker,
      totals: Object.fromEntries(
        Object.entries(locker).map(([k, v]) => [k, v.length]),
      ),
    });
  });

  app.get("/admin/api/player/:accountId/alts", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const accountId = c.req.param("accountId");
    const user = await userService.findUserByAccountId(accountId);
    if (!user) return c.json({ error: "not found" }, 404);

    const alts = await (userService as any).userRepository.find({
      where: { discordId: user.discordId },
    });

    return c.json(
      alts
        .filter((u: any) => u.accountId !== accountId)
        .map((u: any) => ({
          accountId: u.accountId,
          username: u.username,
          email: u.email,
          banned: u.banned,
          lastLogin: u.lastLogin,
        })),
    );
  });

  app.post("/admin/api/player/:accountId/ban", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const accountId = c.req.param("accountId");
    const body = (await c.req.json().catch(() => ({}))) as any;
    const user = await userService.findUserByAccountId(accountId);
    if (!user) return c.json({ error: "not found" }, 404);

    await banService.createOrUpdate({
      accountId,
      reason: body.reason ?? "banned by admin",
    });
    await userService.updateUser(accountId, { banned: true });
    await tokensService.deleteByType(accountId, "AccessToken");
    await tokensService.deleteByType(accountId, "RefreshToken");

    audit(admin, "ban", accountId, {
      username: user.username,
      reason: body.reason,
    });
    return c.json({ success: true });
  });

  app.post("/admin/api/player/:accountId/unban", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const accountId = c.req.param("accountId");
    const user = await userService.findUserByAccountId(accountId);
    if (!user) return c.json({ error: "not found" }, 404);

    await banService.deleteByAccountId(accountId);
    await userService.updateUser(accountId, { banned: false });

    audit(admin, "unban", accountId, { username: user.username });
    return c.json({ success: true });
  });

  app.post("/admin/api/player/:accountId/full-locker", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const accountId = c.req.param("accountId");
    const user = await userService.findUserByAccountId(accountId);
    if (!user) return c.json({ error: "not found" }, 404);

    const allItems: Record<string, any> = require(
      path.join(__dirname, "..", "..", "memory", "all.json"),
    );

    const athena = await ProfileHelper.getProfile(accountId, "athena");
    if (!athena) return c.json({ error: "athena profile not found" }, 404);

    athena.items = { ...athena.items, ...allItems };
    athena.rvn++;
    athena.commandRevision++;
    athena.updatedAt = new Date().toISOString();
    await profilesService.update(accountId, "athena", athena);

    const common_core = await ProfileHelper.getProfile(
      accountId,
      "common_core",
    );
    if (common_core) {
      if (!common_core.items) common_core.items = {};
      const purchaseId = uuid();
      const lootList = Object.entries(allItems).map(([, item]) => ({
        itemType: item.templateId,
        itemGuid: item.templateId,
        quantity: 1,
      }));
      common_core.items[purchaseId] = {
        templateId: "GiftBox:GB_MakeGood",
        attributes: {
          fromAccountId: "",
          lootList,
          params: { userMessage: "Thanks for supporting Lexa!" },
          giftedOn: new Date().toISOString(),
        },
        quantity: 1,
      };
      common_core.rvn++;
      common_core.commandRevision++;
      common_core.updatedAt = new Date().toISOString();
      await profilesService.update(accountId, "common_core", common_core);
    }

    await userService.updateUser(accountId, { has_all_items: true });
    audit(admin, "full_locker_grant", accountId, { username: user.username });
    return c.json({ success: true });
  });

  app.post("/admin/api/player/:accountId/vbucks", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const accountId = c.req.param("accountId");
    const body = (await c.req.json()) as any;
    const amount = Number(body.vbucks);
    if (isNaN(amount) || amount < 0)
      return c.json({ error: "vbucks must be a non-negative number" }, 400);

    const user = await userService.findUserByAccountId(accountId);
    if (!user) return c.json({ error: "not found" }, 404);

    const common_core = await ProfileHelper.getProfile(
      accountId,
      "common_core",
    );
    if (!common_core) return c.json({ error: "profile not found" }, 404);
    if (!common_core.items) common_core.items = {};

    for (const [key, item] of Object.entries(
      common_core.items as Record<string, any>,
    )) {
      if (item.templateId?.startsWith("Currency:Mtx"))
        delete (common_core.items as any)[key];
    }
    if (amount > 0) {
      (common_core.items as any)[crypto.randomUUID()] = {
        templateId: "Currency:MtxPurchased",
        attributes: { platform: "Shared" },
        quantity: amount,
      };
    }
    common_core.rvn++;
    common_core.commandRevision++;
    common_core.updatedAt = new Date().toISOString();
    await profilesService.update(accountId, "common_core", common_core);

    audit(admin, "vbucks_set", accountId, {
      username: user.username,
      vbucks: amount,
    });
    return c.json({ success: true, vbucks: amount });
  });

  app.post("/admin/api/player/:accountId/level", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const accountId = c.req.param("accountId");
    const body = (await c.req.json()) as any;
    const level = Number(body.level);
    if (isNaN(level) || level < 1)
      return c.json({ error: "level must be >= 1" }, 400);

    const user = await userService.findUserByAccountId(accountId);
    if (!user) return c.json({ error: "not found" }, 404);

    const athena = await ProfileHelper.getProfile(accountId, "athena");
    if (!athena) return c.json({ error: "athena profile not found" }, 404);
    if (!athena.stats) athena.stats = { attributes: {} };
    (athena.stats.attributes as any).level = level;
    athena.rvn++;
    athena.commandRevision++;
    athena.updatedAt = new Date().toISOString();
    await profilesService.update(accountId, "athena", athena);

    audit(admin, "level_set", accountId, { username: user.username, level });
    return c.json({ success: true, level });
  });

  app.post("/admin/api/player/:accountId/hype", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const accountId = c.req.param("accountId");
    const body = (await c.req.json()) as any;
    const hype = Number(body.hype);
    if (isNaN(hype) || hype < 0)
      return c.json({ error: "hype must be a non-negative number" }, 400);

    const user = await userService.findUserByAccountId(accountId);
    if (!user) return c.json({ error: "not found" }, 404);

    await accountService.updateAccount(accountId, { arenaHype: hype });
    audit(admin, "hype_set", accountId, { username: user.username, hype });
    return c.json({ success: true, arenaHype: hype });
  });

  app.post("/admin/api/player/:accountId/kill-session", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const accountId = c.req.param("accountId");
    const user = await userService.findUserByAccountId(accountId);
    if (!user) return c.json({ error: "not found" }, 404);

    await tokensService.deleteByType(accountId, "AccessToken");
    await tokensService.deleteByType(accountId, "RefreshToken");

    audit(admin, "kill_session", accountId, { username: user.username });
    return c.json({ success: true });
  });

  app.delete("/admin/api/player/:accountId", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const accountId = c.req.param("accountId");
    const user = await userService.findUserByAccountId(accountId);
    if (!user) return c.json({ error: "not found" }, 404);

    await userService.delete(accountId);
    audit(admin, "player_delete", accountId, { username: user.username });
    return c.json({ success: true });
  });

  app.get("/admin/api/exchange-codes", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    return c.json(listExchangeCodes());
  });

  app.delete("/admin/api/exchange-codes/:code", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const code = c.req.param("code");
    const revoked = revokeExchangeCode(code);
    if (!revoked)
      return c.json({ error: "code not found or already expired" }, 404);
    audit(admin, "exchange_code_revoke", code);
    return c.json({ success: true });
  });

  app.get("/admin/api/game-sessions", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const sessions = await sessionsService.findAll();
    return c.json(sessions);
  });

  app.delete("/admin/api/game-sessions/:sessionId", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const sessionId = c.req.param("sessionId");
    try {
      await sessionsService.delete(sessionId);
      audit(admin, "game_session_kill", sessionId);
      return c.json({ success: true });
    } catch {
      return c.json({ error: "session not found" }, 404);
    }
  });

  app.get("/admin/api/shop/current", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const storefront = await itemStorageService.getItemByType("storefront");
    return c.json(storefront?.data ?? {});
  });

  app.post("/admin/api/shop/rotate", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const { generateShop } = await import("../../utilities/shopgenerator");
    await generateShop();
    audit(admin, "shop_rotate");
    return c.json({ success: true });
  });

  app.get("/admin/api/shop/autorotate", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    return c.json({ enabled: serverState.autorotateEnabled });
  });

  app.post("/admin/api/shop/autorotate", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const body = (await c.req.json()) as any;
    serverState.autorotateEnabled = body.enabled !== false;
    audit(admin, "autorotate_toggle", undefined, {
      enabled: serverState.autorotateEnabled,
    });
    return c.json({ enabled: serverState.autorotateEnabled });
  });

  app.get("/admin/api/shop/schedule", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    return c.json(serverState.scheduledRotations);
  });

  app.post("/admin/api/shop/schedule", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const body = (await c.req.json()) as any;

    if (!body.date || isNaN(Date.parse(body.date))) {
      return c.json({ error: "date must be a valid ISO date string" }, 400);
    }

    const entry = {
      id: crypto.randomUUID(),
      date: body.date,
      items: Array.isArray(body.items) ? body.items : [],
    };

    serverState.scheduledRotations.push(entry);

    await itemStorageService.addItems([
      {
        data: serverState.scheduledRotations,
        type: "scheduled_rotations",
      },
    ]);

    const delay = Date.parse(body.date) - Date.now();
    if (delay > 0) {
      const timeout = setTimeout(async () => {
        const { generateShop } = await import("../../utilities/shopgenerator");
        await generateShop();
        serverState.scheduledRotations = serverState.scheduledRotations.filter(
          (r) => r.id !== entry.id,
        );
        await itemStorageService.addItems([
          {
            data: serverState.scheduledRotations,
            type: "scheduled_rotations",
          },
        ]);
        serverState.scheduleTimeouts.delete(entry.id);
      }, delay);
      serverState.scheduleTimeouts.set(entry.id, timeout);
    }

    audit(admin, "shop_schedule", entry.id, { date: body.date });
    return c.json(entry, 201);
  });

  app.delete("/admin/api/shop/schedule/:id", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const id = c.req.param("id");
    const before = serverState.scheduledRotations.length;
    serverState.scheduledRotations = serverState.scheduledRotations.filter(
      (r) => r.id !== id,
    );
    if (serverState.scheduledRotations.length === before)
      return c.json({ error: "not found" }, 404);

    const timeout = serverState.scheduleTimeouts.get(id);
    if (timeout) {
      clearTimeout(timeout);
      serverState.scheduleTimeouts.delete(id);
    }

    await itemStorageService.addItems([
      {
        data: serverState.scheduledRotations,
        type: "scheduled_rotations",
      },
    ]);

    audit(admin, "shop_schedule_cancel", id);
    return c.json({ success: true });
  });

  app.get("/admin/api/news", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    return c.json(serverState.news);
  });

  app.post("/admin/api/news", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const body = (await c.req.json()) as any;
    const entry = {
      id: crypto.randomUUID(),
      title: body.title ?? "",
      body: body.body ?? "",
      image: body.image ?? "",
    };
    serverState.news.push(entry);
    audit(admin, "news_create", entry.id, { title: entry.title });
    return c.json(entry, 201);
  });

  app.put("/admin/api/news/:id", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const id = c.req.param("id");
    const body = (await c.req.json()) as any;
    const idx = serverState.news.findIndex((n) => n.id === id);
    if (idx === -1) return c.json({ error: "not found" }, 404);
    if (body.title !== undefined) serverState.news[idx].title = body.title;
    if (body.body !== undefined) serverState.news[idx].body = body.body;
    if (body.image !== undefined) serverState.news[idx].image = body.image;
    audit(admin, "news_update", id);
    return c.json(serverState.news[idx]);
  });

  app.delete("/admin/api/news/:id", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const id = c.req.param("id");
    const before = serverState.news.length;
    serverState.news = serverState.news.filter((n) => n.id !== id);
    if (serverState.news.length === before)
      return c.json({ error: "not found" }, 404);
    audit(admin, "news_delete", id);
    return c.json({ success: true });
  });

  app.get("/admin/api/events", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    return c.json(serverState.events);
  });

  app.post("/admin/api/events", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const body = (await c.req.json()) as any;
    const entry = {
      id: crypto.randomUUID(),
      title: body.title ?? "",
      body: body.body ?? "",
      image: body.image ?? "",
    };
    serverState.events.push(entry);
    audit(admin, "events_create", entry.id, { title: entry.title });
    return c.json(entry, 201);
  });

  app.put("/admin/api/events/:id", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const id = c.req.param("id");
    const idx = serverState.events.findIndex((e) => e.id === id);
    if (idx === -1) return c.json({ error: "not found" }, 404);
    const body = (await c.req.json()) as any;
    if (body.title !== undefined) serverState.events[idx].title = body.title;
    if (body.body !== undefined) serverState.events[idx].body = body.body;
    if (body.image !== undefined) serverState.events[idx].image = body.image;
    audit(admin, "events_update", id);
    return c.json(serverState.events[idx]);
  });

  app.delete("/admin/api/events/:id", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);
    const id = c.req.param("id");
    const before = serverState.events.length;
    serverState.events = serverState.events.filter((e) => e.id !== id);
    if (serverState.events.length === before)
      return c.json({ error: "not found" }, 404);
    audit(admin, "events_delete", id);
    return c.json({ success: true });
  });

  app.get("/admin/api/audit-logs", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const limit = Math.min(
      500,
      Math.max(1, parseInt(c.req.query("limit") ?? "100")),
    );
    const filterAction = c.req.query("action");
    const filterAdmin = c.req.query("admin");

    let logs = serverState.auditLog;
    if (filterAction) logs = logs.filter((e) => e.action === filterAction);
    if (filterAdmin) logs = logs.filter((e) => e.admin === filterAdmin);

    return c.json(logs.slice(0, limit));
  });

  app.post("/admin/api/register", async (c) => {
    const admin = await requireAuth(c);
    if (!admin) return c.json({ error: "unauthorized" }, 401);

    const body = (await c.req.json().catch(() => null)) as any;
    const email =
      typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
    const password = typeof body?.password === "string" ? body.password : "";

    if (!email || !password) {
      return c.json({ error: "email and password are required" }, 400);
    }

    const existing = await userService.findUserByEmail(email);
    if (existing) {
      return c.json(
        { error: "an account with this email already exists" },
        409,
      );
    }

    const accountId = uuid().replace(/-/g, "");
    const username = randomUsername();
    const discordId = String(
      Math.floor(100000000000000000 + Math.random() * 900000000000000000),
    );
    const hashedPassword = await Bun.password.hash(password);

    const newUser = await userService.create({
      email,
      username,
      password: hashedPassword,
      accountId,
      discordId,
      roles: ["Developer"],
      banned: false,
      has_all_items: false,
      lastLogin: "",
      ac: false,
    });

    if (!newUser) {
      return c.json({ error: "failed to create user" }, 500);
    }

    const [
      athena,
      profile0,
      common_core,
      campaign,
      metadata,
      theater0,
      collection_book_people0,
      collection_book_schematics0,
      outpost0,
      creative,
    ] = await Promise.all([
      ProfileHelper.createProfile(newUser, "athena"),
      ProfileHelper.createProfile(newUser, "profile0"),
      ProfileHelper.createProfile(newUser, "common_core"),
      ProfileHelper.createProfile(newUser, "campaign"),
      ProfileHelper.createProfile(newUser, "metadata"),
      ProfileHelper.createProfile(newUser, "theater0"),
      ProfileHelper.createProfile(newUser, "collection_book_people0"),
      ProfileHelper.createProfile(newUser, "collection_book_schematics0"),
      ProfileHelper.createProfile(newUser, "outpost0"),
      ProfileHelper.createProfile(newUser, "creative"),
    ]);

    await accountService.create({ accountId, discordId, arenaHype: 0 });

    await Promise.all([
      profilesService.createOrUpdate(accountId, "profile0", profile0),
      profilesService.createOrUpdate(accountId, "athena", athena),
      profilesService.createOrUpdate(accountId, "common_core", common_core),
      profilesService.createOrUpdate(accountId, "common_public", common_core),
      profilesService.createOrUpdate(accountId, "campaign", campaign),
      profilesService.createOrUpdate(accountId, "metadata", metadata),
      profilesService.createOrUpdate(accountId, "theater0", theater0),
      profilesService.createOrUpdate(accountId, "outpost0", outpost0),
      profilesService.createOrUpdate(accountId, "creative", creative),
      profilesService.createOrUpdate(
        accountId,
        "collection_book_people0",
        collection_book_people0,
      ),
      profilesService.createOrUpdate(
        accountId,
        "collection_book_schematics0",
        collection_book_schematics0,
      ),
      friendsService.create({ accountId }),
      receiptsService.create(accountId, []),
      accountService.createDefaultPermissions(accountId),
    ]);

    const statsTemplate = ProfileHelper.createStatsTemplate();
    await seasonStatsService.create({
      solos: statsTemplate.solos,
      duos: statsTemplate.duos,
      squads: statsTemplate.squads,
      ltm: statsTemplate.ltm,
      accountId,
    });

    audit(admin, "account_create", accountId, { email, username });
    return c.json({ accountId, email, password, username, discordId }, 201);
  });
}
