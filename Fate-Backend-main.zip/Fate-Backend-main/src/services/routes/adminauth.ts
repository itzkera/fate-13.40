import { app, config } from "../..";

import jwt from "jsonwebtoken";

const DISCORD_WHITELIST = config.admin_discord_ids;
const CLIENT_ID = config.discord_client_id;
const CLIENT_SECRET = config.discord_client_secret || config.client_secret;
const REDIRECT_URI = config.admin_redirect_uri;
const FRONTEND_URL = config.admin_frontend_url;

export default function () {
  app.get("/admin/auth/discord", (c) => {
    const url = new URL("https://discord.com/api/oauth2/authorize");
    url.searchParams.set("client_id", CLIENT_ID);
    url.searchParams.set("redirect_uri", REDIRECT_URI);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("scope", "identify");
    return c.redirect(url.toString());
  });

  app.get("/admin/auth/discord/callback", async (c) => {
    const redirect = (err: string) => c.redirect(`${FRONTEND_URL}/login?error=${err}`);

    const code = c.req.query("code");
    if (!code) return redirect("no_code");

    const tokenRes = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        grant_type: "authorization_code",
        code,
        redirect_uri: REDIRECT_URI,
      }),
    });

    if (!tokenRes.ok) return redirect("token_exchange");

    const tokenData = (await tokenRes.json()) as any;

    const userRes = await fetch("https://discord.com/api/users/@me", {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });

    if (!userRes.ok) return redirect("user_fetch");

    const discordUser = (await userRes.json()) as any;

    if (!DISCORD_WHITELIST.includes(discordUser.id)) {
      return redirect("unauthorized");
    }

    const secret = config.jwt_secret;
    const avatar = discordUser.avatar
      ? `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.webp?size=64`
      : null;

    const token = jwt.sign(
      { discordId: discordUser.id, username: discordUser.username, avatar },
      secret,
      { expiresIn: "24h" },
    );

    return c.redirect(`${FRONTEND_URL}/auth/callback?token=${token}`);
  });
}
