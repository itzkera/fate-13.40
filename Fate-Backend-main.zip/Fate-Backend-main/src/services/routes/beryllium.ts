import {
  app,
  tokensService,
  userService,
  logger,
  banService,
  hardwaresService,
  config,
} from "../..";
import errors from "../../utilities/errors";

export default function () {
  app.post("/beryllium/api/v1/auth", async (c) => {
    const timestamp = new Date().toISOString();

    const body = await c.req.json().catch(() => null);
    const token = body?.token as string | undefined;
    const hwid = body?.hwid as string | undefined;

    if (!token || !hwid)
      return c.json(errors.createError(400, c.req.url, "Missing token or hwid", timestamp), 400);

    logger.info(`beryllium auth attempt token=${token} hwid=${hwid}`);

    const validToken = await tokensService.getToken(token);
    if (!validToken)
      return c.json(errors.createError(401, c.req.url, "Invalid token", timestamp), 401);

    const user = await userService.findUserByAccountId(validToken.accountId);
    if (!user) return c.json(errors.createError(404, c.req.url, "User not found", timestamp), 404);

    const hardware = await hardwaresService.findByHwid(hwid);
    if (!hardware) {
      await hardwaresService.createOrUpdate({
        accountId: validToken.accountId,
        hwid,
        isBanned: false,
      });
    }

    const userBan = await banService.findByAccountId(user.accountId);
    if (!userBan)
      return c.json(errors.createError(404, c.req.url, "Ban record not found", timestamp), 404);

    if (userBan.isRecentlyUnbanned) {
      userBan.isRecentlyUnbanned = false;
      userBan.unbannedAt = new Date();
      user.banned = false;

      if (!user.ac) {
        user.ac = true;
        await userService.updateUser(user.accountId, { ac: true });
      }

      await banService.createOrUpdate(userBan as any);

      return c.json({ unban: true });
    }

    if (user.banned)
      return c.json(errors.createError(403, c.req.url, "This user is banned.", timestamp), 403);

    if (!user.ac) {
      user.ac = true;
      await userService.updateUser(user.accountId, { ac: true });
    }

    return c.json({ unban: false });
  });

  app.post("/beryllium/api/v1/ban", async (c) => {
    const timestamp = new Date().toISOString();
    const body = await c.req.json().catch(() => null);
    const token = body?.token as string | undefined;
    const message = body?.message as string | undefined;

    if (!token || !message)
      return c.json(errors.createError(400, c.req.url, "Missing token or message", timestamp), 400);

    const validToken = await tokensService.getToken(token);
    if (!validToken)
      return c.json(errors.createError(401, c.req.url, "Invalid token", timestamp), 401);

    const user = await userService.findUserByAccountId(validToken.accountId);
    if (!user) return c.json(errors.createError(404, c.req.url, "User not found", timestamp), 404);

    const hardware = await hardwaresService.getByAccountId(user.accountId);
    const userBan = await banService.findByAccountId(user.accountId);

    if (!hardware || !userBan)
      return c.json(
        errors.createError(404, c.req.url, "Hardware or ban record not found", timestamp),
        404,
      );

    logger.debug(`Beryllium socket message: ${message}`);

    if (message === "Detected traces!") {
      userBan.isShadowBanned = true;
      userBan.shadowBanReason = "Traces Detected";
      userBan.shadowBanStart = new Date();
      userBan.shadowBanEnd = new Date(Date.now() + 1000 * 60 * 60 * 24 * 30 * 6);

      await banService.createOrUpdate(userBan as any);
    } else {
      await hardwaresService.setBannedByAccount(user.accountId, true);
      await userService.updateUser(user.accountId, { banned: true });

      try {
        if (config.webhook_url) {
          await fetch(config.webhook_url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              embeds: [
                {
                  title: "Crystal AntiCheat",
                  color: 16711680,
                  fields: [
                    { name: "Username", value: user.username, inline: false },
                    {
                      name: "Discord User",
                      value: user.discordId ? `<@${user.discordId}>` : "Unknown",
                      inline: false,
                    },
                    { name: "Detection", value: message.split(":")[0] ?? "Unknown", inline: false },
                    {
                      name: "Reason",
                      value: message.includes(":")
                        ? message.split(":").slice(1).join(":").trim()
                        : "DLL Injection",
                      inline: false,
                    },
                  ],
                },
              ],
            }),
          });
        }
      } catch (e) {
        logger.error(`Failed to send discord embed: ${e}`);
      }
    }

    return c.json([]);
  });

  app.post("/beryllium/api/v1/detection", async (c) => {
    const timestamp = new Date().toISOString();
    const body = await c.req.json().catch(() => null);
    const token = body?.token as string | undefined;
    const message = body?.message as string | undefined;

    if (!token || !message)
      return c.json(errors.createError(400, c.req.url, "Missing token or message", timestamp), 400);

    const validToken = await tokensService.getToken(token);
    if (!validToken)
      return c.json(errors.createError(401, c.req.url, "Invalid token", timestamp), 401);

    const user = await userService.findUserByAccountId(validToken.accountId);
    if (!user) return c.json(errors.createError(404, c.req.url, "User not found", timestamp), 404);

    const hardware = await hardwaresService.getByAccountId(user.accountId);
    const userBan = await banService.findByAccountId(user.accountId);

    if (!hardware || !userBan)
      return c.json(
        errors.createError(404, c.req.url, "Hardware or ban record not found", timestamp),
        404,
      );

    logger.debug(`Beryllium detection: ${message}`);

    try {
      if (config.webhook_url) {
        await fetch(config.webhook_url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            embeds: [
              {
                title: "Crystal AntiCheat",
                color: 16711680,
                fields: [
                  { name: "Username", value: user.username, inline: false },
                  {
                    name: "Discord User",
                    value: user.discordId ? `<@${user.discordId}>` : "Unknown",
                    inline: false,
                  },
                  { name: "Detection", value: message.split(":")[0] ?? "Unknown", inline: false },
                  {
                    name: "Reason",
                    value: message.includes(":")
                      ? message.split(":").slice(1).join(":").trim()
                      : "DLL Injection",
                    inline: false,
                  },
                ],
              },
            ],
          }),
        });
      }
    } catch (e) {
      logger.error(`Failed to send discord embed: ${e}`);
    }

    return c.json([]);
  });

  app.post("/beryllium/api/v1/deauth", async (c) => {
    const timestamp = new Date().toISOString();
    const body = await c.req.json().catch(() => null);
    const token = body?.token as string | undefined;

    if (!token) return c.json(errors.createError(400, c.req.url, "Missing token", timestamp), 400);

    const validToken = await tokensService.getToken(token);
    if (!validToken)
      return c.json(errors.createError(401, c.req.url, "Invalid token", timestamp), 401);

    const user = await userService.findUserByAccountId(validToken.accountId);
    if (!user) return c.json(errors.createError(404, c.req.url, "User not found", timestamp), 404);

    if (user.ac !== false) {
      await userService.updateUser(user.accountId, { ac: false });
    }

    return c.json([]);
  });
}
