import { app, contentPageService, logger } from "../..";

import { ContentPageManager } from "../../utilities/managers/ContentPageManager";
import type { ContentPages } from "../../../types/contentpages";
import errors from "../../utilities/errors";
import { file } from "bun";
import path from "node:path";
import { randomUUID } from "node:crypto";
import uaparser from "../../utilities/uaparser";
import { v4 } from "uuid";

export default function () {
  app.get("/content/api/pages/fortnite-game", async (c) => {
  const userAgent = c.req.header("User-Agent");
  const timestamp = new Date().toISOString();

  if (!userAgent) {
    return c.json(
      errors.createError(400, c.req.url, "Header 'User-Agent' is missing.", timestamp),
      400,
    );
  }

  const uahelper = uaparser(userAgent);
  if (!uahelper) {
    return c.json(
      errors.createError(400, c.req.url, "Failed to parse User-Agent.", timestamp),
      400,
    );
  }

  const dbdynamicbackground = await contentPageService.getDynamicBackground();
  const dbplaylistinfo = await contentPageService.getPlaylistInfo();
  const dbbattleroyalenews = await contentPageService.getBattleRoyaleNews();

  if (!dbdynamicbackground) {
    await contentPageService.createDynamicBackground({
      backgrounds: {
        backgrounds: [],
        _type: "DynamicBackgroundList",
      },
      _title: "dynamicbackgrounds",
      _noIndex: false,
      _activeDate: new Date(),
      lastModified: new Date(),
      _locale: "en-US",
    });
  }

  if (!dbplaylistinfo) {
    await contentPageService.createPlaylistInfo({
      playlist_info: {
        _type: "FortPlaylistInfo",
        playlists: [
          {
            id: "Playlist_DefaultSolo",
            playlistName: "Playlist_DefaultSolo",
            hidden: false,
            displayName: "Solo",
            image: "https://i.imgur.com/MDU9t5P.png",
            _type: "FortPlaylistInfo",
          },
          {
            id: "Playlist_DefaultSquad",
            playlistName: "Playlist_DefaultSquad",
            hidden: false,
            displayName: "Squad",
            image: "",
            _type: "FortPlaylistInfo",
          },
          {
            id: "Playlist_DefaultDuo",
            playlistName: "Playlist_DefaultDuo",
            hidden: false,
            displayName: "Duo",
            image: "",
            _type: "FortPlaylistInfo",
          },
          {
            id: "Playlist_PlaygroundV2",
            playlistName: "Playlist_PlaygroundV2",
            hidden: false,
            displayName: "Playground",
            image: "",
            _type: "FortPlaylistInfo",
          },
          {
            id: "Playlist_Playground",
            playlistName: "Playlist_Playground",
            hidden: false,
            displayName: "Playground",
            image: "",
            _type: "FortPlaylistInfo",
          },
          {
            id: "Playlist_BattleLab",
            playlistName: "Playlist_BattleLab",
            hidden: false,
            displayName: "Battle Lab",
            image: "",
            _type: "FortPlaylistInfo",
          },
          {
            id: "Playlist_ShowdownAlt_Solo",
            playlistName: "Playlist_ShowdownAlt_Solo",
            hidden: false,
            displayName: "Lategame Arena",
            image: "https://i.imgur.com/7WEyKrG.png",
            _type: "FortPlaylistInfo",
          },
          {
            id: "Playlist_ShowdownAlt_Duos",
            playlistName: "Playlist_ShowdownAlt_Duos",
            hidden: true,
            displayName: "Arena",
            image: "https://us-tuna-sounds-images.voicemod.net/2ff14043-882a-4b26-9e21-7c524c8f4806-1713545391692.png",
            _type: "FortPlaylistInfo",
          },
        ],
      },
      lastModified: new Date(),
      _activeDate: new Date(),
      frontend_matchmaking_header_style: "None",
      _title: "playlistinformation",
      _noIndex: false,
      _locale: "en-US",
    });
  }

  if (!dbbattleroyalenews) {
    await contentPageService.createBattleRoyaleNews({
      news: {
        id: randomUUID().replace(/-/g, ""),
        platform_messages: [
          {
            id: randomUUID().replace(/-/g, ""),
            hidden: false,
            _type: "CommonUI Simple Message Platform",
            message: {
              image:
                "https://cdn2.unrealengine.com/Fortnite/fortnite-game/battleroyalenews/v11/v1101/11BR_EpicGamesAndroidLauncherAssets_MOTD-1024x512-18dd3ddb2b4297abde65e0d898244181f4581326.jpg",
              hidden: false,
              _type: "CommonUI Simple Message Base",
              subgame: "br",
              title: "Epic Games app",
              body: "The Fortnite Installer on Android is now the Epic Games app!\nUse it to download Fortnite on Android and check out all that's new in #FortniteChapter2",
              spotlight: false,
              id: randomUUID().replace(/-/g, ""),
            },
            platform: "android",
          },
        ],
        _type: "Battle Royale News",
        messages: [
          {
            id: randomUUID().replace(/-/g, ""),
            image:
              "https://cdn2.unrealengine.com/Fortnite/fortnite-game/battleroyalenews/v42/BR04_MOTD_Shield-1024x512-75eacc957ecc88e76693143b6256ba06159efb76.jpg",
            hidden: false,
            messagetype: "normal",
            _type: "CommonUI Simple Message Base",
            title: "Keep Your Account Secure",
            body: "Avoid scam sites offering free V-Bucks. Epic will never ask for your password. Enable Two-Factor Authentication to help stay secure!",
            spotlight: false,
          },
          {
            id: randomUUID().replace(/-/g, ""),
            image:
              "https://cdn2.unrealengine.com/Fortnite%2Fblog%2FSeason+6+Blog%2FBR06_Nintendo_HeroBanner-1920x1080-b9980da0c0cfb4a871f8a9cff403a3799a080a1f.jpg",
            hidden: false,
            messagetype: "normal",
            _type: "CommonUI Simple Message Base",
            title: "Season 6 Battle Pass Now Available!",
            body: "Unlock exclusive rewards, including Calamity and DJ Yonder skins, with the Season 6 Battle Pass.",
            spotlight: false,
          },
        ],
      },
      _title: "battleroyalnews",
      _noIndex: false,
      alwaysShow: false,
      style: "SpecialEvent",
      header: "",
      _activeDate: new Date(),
      lastModified: new Date(),
      _locale: "en-US",
    });
  }

  const fullResponse = await ContentPageManager.buildFullResponse();

  if (!fullResponse.dynamicbackgrounds)
    return c.json(
      errors.createError(500, c.req.url, "Failed to load dynamic backgrounds", timestamp),
    );

  fullResponse.dynamicbackgrounds.backgrounds.backgrounds.push(
    { stage: uahelper.background, _type: "DynamicBackground", key: "vault" },
    { stage: uahelper.background, _type: "DynamicBackground", key: "lobby" },
  );

  if (uahelper.season === 19) {
    fullResponse.dynamicbackgrounds.backgrounds.backgrounds.push({
      stage: "defaultnotris",
      _type: "DynamicBackground",
      key: "lobby",
      backgroundimage:
        "https://cdn2.unrealengine.com/nocturnal-storebg-cms-1921x1081-796115fa0fc9.png",
    });
  }

  if (uahelper.season === 26) {
    fullResponse.dynamicbackgrounds.backgrounds.backgrounds[0].stage = "season2630";
    fullResponse.dynamicbackgrounds.backgrounds.backgrounds[0].backgroundimage =
      "https://cdn2.unrealengine.com/s26-lobby-timemachine-final-2560x1440-a3ce0018e3fa.jpg";
  }

  const playlistImagesBySeason: {
    [key: number]: {
      solo: string;
      duo: string;
      squad: string;
      playground?: string;
      battlelab?: string;
      arenasolo?: string;
      arenaduo?: string;
    };
  } = {
    6: {
      solo: "https://cdn2.unrealengine.com/Fortnite/fortnite-game/playlisttiles/BR_LobbyTileArt_Solo-512x512-24446ea2a54612c5604ecf0e30475b4dec81c3bc.png",
      duo: "https://cdn2.unrealengine.com/Fortnite/fortnite-game/playlisttiles/BR_LobbyTileArt_Duo-512x512-5dea8dfae97bddcd4e204dd47bfb245d3f68fc7b.png",
      squad:
        "https://cdn2.unrealengine.com/Fortnite/fortnite-game/playlisttiles/BR_LobbyTileArt_Squad-512x512-5225ec6ca3265611957834c2c549754fe1778449.png",
      playground:
        "https://cdn2.unrealengine.com/Fortnite/fortnite-game/playlisttiles/BR_LTM-Tile_Playground-1024x512-53db8a4b5fb41251af279eaf923bc00ecbc17792.jpg",
      arenasolo: "https://i.imgur.com/7WEyKrG.png",
      arenaduo: "https://us-tuna-sounds-images.voicemod.net/2ff14043-882a-4b26-9e21-7c524c8f4806-1713545391692.png",
    },
    7: {
      solo: "https://i.ibb.co/23sNKqJ/66f8c6d28f8464-55630287-Processed.jpg",
      duo: "",
      squad: "",
    },
  };

  if (!fullResponse.playlistinformation)
    return c.json(
      errors.createError(500, c.req.url, "Failed to load playlist information", timestamp),
    );

  const playlistImages = playlistImagesBySeason[uahelper.season];

  if (playlistImages) {
    fullResponse.playlistinformation.playlist_info.playlists.forEach((playlist) => {
      if (playlist.playlistName === "Playlist_DefaultSolo") {
        playlist.image = playlistImages.solo;
      } else if (playlist.playlistName === "Playlist_DefaultDuo") {
        playlist.image = playlistImages.duo;
      } else if (playlist.playlistName === "Playlist_DefaultSquad") {
        playlist.image = playlistImages.squad;
      } else if (playlist.playlistName === "Playlist_PlaygroundV2") {
        if (playlistImages.playground) playlist.image = playlistImages.playground;
      } else if (playlist.playlistName === "Playlist_BattleLab") {
        if (playlistImages.battlelab) playlist.image = playlistImages.battlelab;
      } else if (playlist.playlistName === "Playlist_ShowdownAlt_Solo") {
        playlist.displayName = "Lategame Arena";
        if (playlistImages.arenasolo) playlist.image = playlistImages.arenasolo;
      } else if (playlist.playlistName === "Playlist_ShowdownAlt_Duos") {
        playlist.hidden = false;
        playlist.displayName = "Arena";
        if (playlistImages.arenaduo) playlist.image = playlistImages.arenaduo;
      } else if (playlist.playlistName === "Playlist_Playground") {
        if (playlistImages.playground) playlist.image = playlistImages.playground;
      }
    });
  }

  (fullResponse as any).emergencynotice = {
    news: {
      _type: "Battle Royale News",
      messages: [
        {
          hidden: false,
          _type: "CommonUI Simple Message Base",
          title: "Fate",
          body: "Welcome to Fate the best OG Season 13 Experience. Discord - discord.gg/fatefn",
          spotlight: true,
          image: "https://cdn.mos.cms.futurecdn.net/3SgPq8qXHKEZauX4fi9KnR.jpg",
        },
      ],
    },
    _title: "emergencynotice",
    _noIndex: false,
    _activeDate: new Date().toISOString(),
    lastModified: new Date().toISOString(),
    _locale: "en-US",
  };

  (fullResponse as any).battleroyalenewsv2 = {
    news: {
      motds: [
        {
          id: "news1",
          entryType: "Text",
          image: "https://cdn.mos.cms.futurecdn.net/3SgPq8qXHKEZauX4fi9KnR.jpg",
          tileImage: "https://cdn.mos.cms.futurecdn.net/3SgPq8qXHKEZauX4fi9KnR.jpg",
          hidden: false,
          title: "Welcome",
          body: "Thanks for playing!",
          sortingPriority: 0,
          spotlight: true,
        },
      ],
    },
    alwaysShow: true,
    _title: "battleroyalenewsv2",
    _noIndex: false,
    _locale: "en-US",
    _activeDate: new Date().toISOString(),
    lastModified: new Date().toISOString(),
  };

  return c.json(fullResponse);
});

  app.post("/api/v1/fortnite-br/surfaces/dmotd/target", async (c) => {
    return c.json({
      contentType: "collection",
      contentId: "motd-default-collection",
      tcId: v4(),
      contentItems: [
        {
          contentType: "content-item",
          contentId: v4(),
          tcId: v4(),
          contentFields: {},
          contentSchemaName: "MotdWebsiteNewsWithVideo",
        },
      ],
    });
  });
}
