import { accountService, app, hypeService, logger } from "../..";
import path from "node:path";
import uaparser from "../../utilities/uaparser";

async function getDivisionToken(season: number, hype: number): Promise<string> {
  let divisions = (await hypeService.getAll()).filter((entry) =>
    entry.name.startsWith(`Arena_S${season}_Division`),
  );

  if (divisions.length === 0) {
    await hypeService.create(season);
    divisions = (await hypeService.getAll()).filter((entry) =>
      entry.name.startsWith(`Arena_S${season}_Division`),
    );
  }

  const division = divisions.find(
    (entry) => hype >= entry.minimum_required_hype && hype <= Number(entry.maximum_required_hype),
  );

  return division?.name ?? `Arena_S${season}_Division1`;
}

export default function () {
  app.get("/fortnite/api/game/v2/events/tournamentandhistory/:accountId/:region/:platform", async (c) => {
    const accountId = c.req.param("accountId");
    const season = uaparser(c.req.header("User-Agent"))?.season || 8;

    try {
      const account = await accountService.findUserByAccountId(accountId);
      const hype = account?.arenaHype ?? 0;
      const token = await getDivisionToken(season, hype);

      return c.json({
        history: [],
        player: {
          accountId,
          gameId: "Fortnite",
          groupIdentity: {},
          pendingPayouts: [],
          pendingPenalties: {},
          persistentScores: {
            Hype: hype,
          },
          teams: {},
          tokens: [token],
        },
        tournamentAlertCount: 0,
        tournaments: [],
      });
    } catch (error) {
      logger.error(`Error fetching tournament history for ${accountId}: ${error}`);
      return c.json({ history: [], player: null, tournamentAlertCount: 0, tournaments: [] }, 500);
    }
  });

  app.get("/api/v1/events/Fortnite/download/leaderboards/:eventId/:eventWindowId/:accountId", async (c) => {
    return c.json({ entries: [], totalPages: 0 });
  });

  app.get("/api/v1/events/Fortnite/download/:accountId", async (c) => {
    const accountId = c.req.param("accountId");
    const season = uaparser(c.req.header("User-Agent"))?.season || 13;

    try {
      const account = await accountService.findUserByAccountId(accountId);
      const hype = account?.arenaHype ?? 0;
      const token = await getDivisionToken(season, hype);

      const memoryDir = path.join(__dirname, "..", "..", "memory", "events");
      const raw = await Bun.file(path.join(memoryDir, "events_13.json")).json();

      const teams = Object.fromEntries(
        Object.entries(raw.player.teams as Record<string, string[]>).map(([key, members]) => [
          key,
          members.map((v) => (v === "accountId" ? accountId : v)),
        ]),
      );

      return c.json({
        events: raw.events,
        player: {
          accountId,
          gameId: "Fortnite",
          groupIdentity: {},
          pendingPayouts: [],
          pendingPenalties: {},
          persistentScores: { Hype: hype },
          teams,
          tokens: [token],
        },
        templates: raw.templates,
      });
    } catch (error) {
      logger.error(`Error fetching arena events for ${accountId}: ${error}`);
      return c.json([], 500);
    }
  });
}
