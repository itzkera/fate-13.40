import { accountService, app, receiptsService, userService } from "../..";
import { Validation } from "../../modules/middleware/validation";
import path from "node:path";
import errors from "../../utilities/errors";

export default function () {
  app.get("/fortnite/api/game/v2/world/info", Validation.verifyToken, async (c) => {
    const content = await Bun.file(
      path.join(__dirname, "..", "..", "memory", "world", "worldinfo.json"),
    ).json();

    return c.json(content);
  });

  app.get("/fortnite/api/receipts/v1/account/:accountId/receipts", async (c) => {
    const accountId = c.req.param("accountId");
    const timestamp = new Date().toISOString();

    const user = await userService.findUserByAccountId(accountId);
    const account = await accountService.findUserByAccountId(accountId);
    const receipts = await receiptsService.findByAccountId(accountId);

    if (!user || !account || !receipts) {
      return c.json(
        errors.createError(404, c.req.url, "Failed to find user or account.", timestamp),
        404,
      );
    }

    return c.json(receipts.receipts);
  });

  app.get("/api/v2/interactions/aggregated/Fortnite/:accountId", async (c) => {
    return c.json([]);
  });
}
