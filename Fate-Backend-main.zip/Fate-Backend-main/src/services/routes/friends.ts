import { app, friendsService, userService } from "../..";
import { Validation } from "../../modules/middleware/validation";
import { Friends, type Friend } from "../../tables/friends";
import errors from "../../utilities/errors";
import { sendXmppMessageToId } from "../../modules/xmpp/functions/SendMessageToId";

interface FriendList {
  accountId: string;
  status: string;
  direction: string;
  createdAt: string;
  favorite: boolean;
}

export default function () {
  app.get("/fortnite/api/v1/:accountId/blocklist", async (c) => {
    const accountId = c.req.param("accountId");
    const timestamp = new Date().toISOString();

    if (!accountId)
      return c.json(
        errors.createError(400, c.req.url, "Missing parameter 'accountId'", timestamp),
        400,
      );

    const friends = await friendsService.findFriendByAccountId(accountId);

    if (!friends)
      return c.json(errors.createError(400, c.req.url, "Failed to find friends.", timestamp), 400);

    const list: Friend[] = [];

    for (const blocked of friends.blocked) {
      list.push({
        accountId: blocked.accountId,
        createdAt: new Date().toISOString(),
        alias: "",
      });
    }

    return c.json(list);
  });

  app.get("/fortnite/api/public/list/fortnite/:accountId/recentPlayers", async (c) => {
    return c.json([]);
  });

  app.get("/friends/api/public/list/fortnite/:accountId/recentPlayers", async (c) => {
    return c.json([]);
  });

  app.get("/fortnite/api/v1/:accountId/settings", async (c) => {
    return c.json({
      acceptInvites: "public",
    });
  });

  app.get("/friends/api/v1/:accountId/settings", async (c) => {
    return c.json({
      acceptInvites: "public",
    });
  });

  app.get("/friends/api/public/blocklist/:accountId", Validation.verifyToken, async (c) => {
    const accountId = c.req.param("accountId");
    const timestamp = new Date().toISOString();

    if (!accountId)
      return c.json(
        errors.createError(400, c.req.url, "Missing parameter 'accountId'", timestamp),
        400,
      );

    const friends = await friendsService.findFriendByAccountId(accountId);

    if (!friends)
      return c.json(errors.createError(400, c.req.url, "Failed to find friends.", timestamp), 400);

    return c.json({
      blockedUsers: friends.blocked.map((user) => user.accountId),
    });
  });

  app.get("/friends/api/public/friends/:accountId", Validation.verifyToken, async (c) => {
    const accountId = c.req.param("accountId");
    const timestamp = new Date().toISOString();

    if (!accountId)
      return c.json(
        errors.createError(400, c.req.url, "Missing parameter 'accountId'", timestamp),
        400,
      );

    const friends = await friendsService.findFriendByAccountId(accountId);

    if (!friends)
      return c.json(errors.createError(400, c.req.url, "Failed to find friends.", timestamp), 400);

    const list: FriendList[] = [];
    const acceptedFriends = friends.accepted;
    const incomingFriends = friends.incoming;
    const outgoingFriends = friends.outgoing;
    const blockedFriends = friends.blocked;

    for (const friend of acceptedFriends) {
      list.push({
        accountId: friend.accountId,
        status: "ACCEPTED",
        direction: "OUTBOUND",
        createdAt: new Date().toISOString(),
        favorite: false,
      });
    }

    for (const friend of incomingFriends) {
      list.push({
        accountId: friend.accountId,
        status: "PENDING",
        direction: "INBOUND",
        createdAt: friend.createdAt,
        favorite: false,
      });
    }

    for (const friend of outgoingFriends) {
      list.push({
        accountId: friend.accountId,
        status: "PENDING",
        direction: "OUTBOUND",
        createdAt: friend.createdAt,
        favorite: false,
      });
    }

    for (const friend of blockedFriends) {
      list.push({
        accountId: friend.accountId,
        status: "BLOCKED",
        direction: "INBOUND",
        createdAt: friend.createdAt,
        favorite: false,
      });
    }

    return c.json(list);
  });

  app.get("/friends/api/v1/:accountId/summary", Validation.verifyToken, async (c) => {
    const accountId = c.req.param("accountId");
    const timestamp = new Date().toISOString();

    if (!accountId)
      return c.json(
        errors.createError(400, c.req.url, "Missing parameter 'accountId'", timestamp),
        400,
      );

    const friends = await friendsService.findFriendByAccountId(accountId);

    if (!friends)
      return c.json(errors.createError(400, c.req.url, "Failed to find friends.", timestamp), 400);

    const content: {
      friends: any[];
      incoming: any[];
      outgoing: any[];
      suggested: any[];
      blocklist: any[];
      settings: { acceptInvites: string };
    } = {
      friends: [],
      incoming: [],
      outgoing: [],
      suggested: [],
      blocklist: [],
      settings: {
        acceptInvites: "public",
      },
    };

    const acceptedFriends = friends.accepted;
    const incomingFriends = friends.incoming;
    const outgoingFriends = friends.outgoing;
    const blockedFriends = friends.blocked;

    for (const friend of acceptedFriends) {
      content.friends.push({
        accountId: friend.accountId,
        groups: [],
        mutual: 0,
        alias: "",
        note: "",
        createdAt: friend.createdAt,
        favorite: false,
      });
    }

    for (const friend of incomingFriends) {
      content.incoming.push({
        accountId: friend.accountId,
        groups: [],
        mutual: 0,
        alias: "",
        note: "",
        createdAt: friend.createdAt,
        favorite: false,
      });
    }

    for (const friend of outgoingFriends) {
      content.outgoing.push({
        accountId: friend.accountId,
        groups: [],
        mutual: 0,
        alias: "",
        note: "",
        createdAt: friend.createdAt,
        favorite: false,
      });
    }

    for (const friend of blockedFriends) {
      content.blocklist.push({
        accountId: friend.accountId,
        groups: [],
        mutual: 0,
        alias: "",
        note: "",
        createdAt: friend.createdAt,
        favorite: false,
      });
    }

    return c.json(content);
  });

  app.get("/fortnite/api/v1/:accountId/recent/:type", Validation.verifyToken, async (c) => {
    return c.json([]);
  });

  app.get("/friends/api/v1/:accountId/friends/:friendId", Validation.verifyToken, async (c) => {
    const accountId = c.req.param("accountId");
    const friendId = c.req.param("friendId");
    const timestamp = new Date().toISOString();

    if (!accountId || !friendId)
      return c.json(errors.createError(400, c.req.url, "Missing parameters.", timestamp), 400);

    const user = await friendsService.findFriendByAccountId(accountId);
    const friend = await friendsService.findFriendByAccountId(friendId);

    if (!user || !friend)
      return c.json(errors.createError(400, c.req.url, "Failed to find friends.", timestamp), 400);

    const accepted = friend.accepted.find((accepted) => accepted.accountId === user.accountId);

    if (!accepted)
      return c.json(
        errors.createError(
          400,
          c.req.url,
          `Friendship between ${user.accountId} and ${friend.accountId} does not exist.`,
          timestamp,
        ),
      );

    return c.json({
      accountId: friend.accountId,
      groups: [],
      mutual: 0,
      alias: "",
      note: "",
      favorite: false,
      created: accepted.createdAt,
    });
  });

  app.post(
    "/friends/api/public/friends/:accountId/:friendId",
    Validation.verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");
      const friendId = c.req.param("friendId");
      const timestamp = new Date().toISOString();

      if (!accountId || !friendId)
        return c.json(errors.createError(400, c.req.url, "Missing parameters.", timestamp), 400);

      const frienduser = await friendsService.findFriendByAccountId(accountId);
      const friendInList = await friendsService.findFriendByAccountId(friendId);

      if (!frienduser || !friendInList)
        return c.json(
          errors.createError(400, c.req.url, "Failed to find friends.", timestamp),
          400,
        );

      const user = await userService.findUserByAccountId(frienduser.accountId);
      const friend = await userService.findUserByAccountId(friendInList.accountId);

      if (!user || !friend)
        return c.json(
          errors.createError(400, c.req.url, "Failed to find user or friend.", timestamp),
          400,
        );

      if (user.banned || friend.banned)
        return c.json(
          errors.createError(403, c.req.url, "Friend or User is banned.", timestamp),
          403,
        );

      const acceptedFriends = frienduser.accepted.find(
        (accepted) => accepted.accountId === friend.accountId,
      );

      const incomingFriends = frienduser.incoming.find(
        (incoming) => incoming.accountId === friend.accountId,
      );

      const outgoingFriends = frienduser.outgoing.find(
        (outgoing) => outgoing.accountId === friend.accountId,
      );

      if (acceptedFriends)
        return c.json(
          errors.createError(
            400,
            c.req.url,
            `Friendship between ${user.accountId} and ${friend.accountId} already exists.`,
            timestamp,
          ),
          400,
        );

      if (outgoingFriends)
        return c.json(
          errors.createError(
            400,
            c.req.url,
            `Friendship request has already been sent to ${friend.accountId}`,
            timestamp,
          ),
          400,
        );

      if (user.accountId === friend.accountId)
        return c.json(
          errors.createError(400, c.req.url, "You cannot add yourself.", timestamp),
          400,
        );

      const result = await friendsService.addOrAccept(user.accountId, friend.accountId);
      if (result === "EXISTS")
        return c.json(
          errors.createError(400, c.req.url, "Friendship or request already exists.", timestamp),
          400,
        );

      if (
        frienduser.blocked.some((entry) => entry.accountId === friend.accountId) ||
        friendInList.blocked.some((entry) => entry.accountId === user.accountId)
      )
        return c.json(errors.createError(403, c.req.url, "Friendship is blocked.", timestamp), 403);

      notifyFriendChange(user.accountId, friend.accountId, result);
      return c.body(null, 204);
    },
  );

  app.post("/friends/api/v1/:accountId/friends/:friendId", Validation.verifyToken, async (c) => {
    const accountId = c.req.param("accountId");
    const friendId = c.req.param("friendId");
    const timestamp = new Date().toISOString();

    if (!accountId || !friendId)
      return c.json(errors.createError(400, c.req.url, "Missing parameters.", timestamp), 400);

    const frienduser = await friendsService.findFriendByAccountId(accountId);
    const friendInList = await friendsService.findFriendByAccountId(friendId);

    if (!frienduser || !friendInList)
      return c.json(errors.createError(400, c.req.url, "Failed to find friends.", timestamp), 400);

    const user = await userService.findUserByAccountId(frienduser.accountId);
    const friend = await userService.findUserByAccountId(friendInList.accountId);

    if (!user || !friend)
      return c.json(
        errors.createError(400, c.req.url, "Failed to find user or friend.", timestamp),
        400,
      );

    if (user.banned || friend.banned)
      return c.json(
        errors.createError(403, c.req.url, "Friend or User is banned.", timestamp),
        403,
      );

    const acceptedFriends = frienduser.accepted.find(
      (accepted) => accepted.accountId === friend.accountId,
    );

    const incomingFriends = frienduser.incoming.find(
      (incoming) => incoming.accountId === friend.accountId,
    );

    const outgoingFriends = frienduser.outgoing.find(
      (outgoing) => outgoing.accountId === friend.accountId,
    );

    if (acceptedFriends)
      return c.json(
        errors.createError(
          400,
          c.req.url,
          `Friendship between ${user.accountId} and ${friend.accountId} already exists.`,
          timestamp,
        ),
        400,
      );

    if (outgoingFriends)
      return c.json(
        errors.createError(
          400,
          c.req.url,
          `Friendship request has already been sent to ${friend.accountId}`,
          timestamp,
        ),
        400,
      );

    if (user.accountId === friend.accountId)
      return c.json(errors.createError(400, c.req.url, "You cannot add yourself.", timestamp), 400);

    const result = await friendsService.addOrAccept(user.accountId, friend.accountId);
    if (result === "EXISTS")
      return c.json(
        errors.createError(400, c.req.url, "Friendship or request already exists.", timestamp),
        400,
      );

    if (
      frienduser.blocked.some((entry) => entry.accountId === friend.accountId) ||
      friendInList.blocked.some((entry) => entry.accountId === user.accountId)
    )
      return c.json(errors.createError(403, c.req.url, "Friendship is blocked.", timestamp), 403);

    notifyFriendChange(user.accountId, friend.accountId, result);
    return c.body(null, 204);
  });

  app.delete(
    "/friends/api/v1/:accountId/friends/:friendId",
    Validation.verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");
      const friendId = c.req.param("friendId");
      const timestamp = new Date().toISOString();
      if (!accountId || !friendId)
        return c.json(errors.createError(400, c.req.url, "Missing parameters.", timestamp), 400);

      try {
        const removed = await friendsService.remove(accountId, friendId);
        if (!removed)
          return c.json(
            errors.createError(404, c.req.url, "Friendship or request does not exist.", timestamp),
            404,
          );
        notifyRemoval(accountId, friendId);
        return c.body(null, 204);
      } catch {
        return c.json(errors.createError(404, c.req.url, "Account not found.", timestamp), 404);
      }
    },
  );

  app.put(
    "/friends/api/v1/:accountId/blocklist/:friendId",
    Validation.verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");
      const friendId = c.req.param("friendId");
      const timestamp = new Date().toISOString();
      if (!accountId || !friendId || accountId === friendId)
        return c.json(errors.createError(400, c.req.url, "Invalid parameters.", timestamp), 400);

      try {
        await friendsService.block(accountId, friendId);
        notifyRemoval(accountId, friendId);
        return c.body(null, 204);
      } catch {
        return c.json(errors.createError(404, c.req.url, "Account not found.", timestamp), 404);
      }
    },
  );

  app.delete(
    "/friends/api/v1/:accountId/blocklist/:friendId",
    Validation.verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");
      const friendId = c.req.param("friendId");
      const timestamp = new Date().toISOString();
      if (!accountId || !friendId)
        return c.json(errors.createError(400, c.req.url, "Missing parameters.", timestamp), 400);

      try {
        const removed = await friendsService.unblock(accountId, friendId);
        if (!removed)
          return c.json(errors.createError(404, c.req.url, "Block does not exist.", timestamp), 404);
        return c.body(null, 204);
      } catch {
        return c.json(errors.createError(404, c.req.url, "Account not found.", timestamp), 404);
      }
    },
  );
}

function notifyFriendChange(accountId: string, friendId: string, result: "SENT" | "ACCEPTED") {
  const timestamp = new Date().toISOString();
  if (result === "SENT") {
    sendXmppMessageToId(accountId, friendEvent(friendId, "PENDING", "OUTBOUND", timestamp));
    sendXmppMessageToId(friendId, friendEvent(accountId, "PENDING", "INBOUND", timestamp));
    return;
  }
  sendXmppMessageToId(accountId, friendEvent(friendId, "ACCEPTED", "OUTBOUND", timestamp));
  sendXmppMessageToId(friendId, friendEvent(accountId, "ACCEPTED", "OUTBOUND", timestamp));
}

function friendEvent(accountId: string, status: string, direction: string, timestamp: string) {
  return {
    type: "com.epicgames.friends.core.apiobjects.Friend",
    payload: { accountId, status, direction, created: timestamp, favorite: false },
    timestamp,
  };
}

function notifyRemoval(accountId: string, friendId: string) {
  const timestamp = new Date().toISOString();
  const event = (removedId: string) => ({
    type: "com.epicgames.friends.core.apiobjects.FriendRemoval",
    payload: { accountId: removedId, reason: "DELETED" },
    timestamp,
  });
  sendXmppMessageToId(accountId, event(friendId));
  sendXmppMessageToId(friendId, event(accountId));
}
