import { Sessions, StateMap } from "../../utilities/launcher/sessions";
import {
  accountService,
  app,
  config,
  friendsService,
  logger,
  profilesService,
  receiptsService,
  seasonStatsService,
  userService,
} from "../..";

import { Buffer } from "node:buffer";
import ProfileHelper from "../../utilities/ProfileHelper";
import type { User } from "../../tables/user";
import fs from "node:fs";
import path from "node:path";
import {
  signLauncherToken,
  verifyLauncherToken,
} from "../../utilities/launcher/token";
import { v4 as uuid } from "uuid";

const CALLBACK_URI = config.launcher_callback_uri;
const DISCORD_CLIENT_ID = config.discord_client_id;
const DISCORD_CLIENT_SECRET = config.discord_client_secret;
const DONE_PAGE = `<html><body style="font-family:system-ui;background:#111;color:#aaa;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;font-size:14px">you can close this tab</body></html>`;
const ERROR_PAGE = (msg: string) =>
  `<html><body style="font-family:system-ui;background:#111;color:#f87171;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;font-size:14px">${msg}</body></html>`;

function wsSend(
  socket: { send: (msg: string) => void } | undefined,
  data: object,
) {
  socket?.send(JSON.stringify(data));
}

async function createLauncherUser(discordUser: any): Promise<User | null> {
  const discordId = `${discordUser.id}`;
  const username =
    typeof discordUser.username === "string" && discordUser.username.length > 0
      ? discordUser.username
      : `discord_${discordId}`;
  const accountId = uuid().replace(/-/g, "");
  const password = await Bun.password.hash(uuid());

  const newUser = await userService.create({
    email: `${discordId}@discord.oauth`,
    username,
    password,
    accountId,
    discordId,
    roles: [],
    banned: false,
    has_all_items: false,
    lastLogin: "",
    ac: false,
  });

  if (!newUser) return null;

  const [
    athena,
    profile0,
    common_core,
    campaign,
    metadata,
    theater0,
    collection_book_people0,
    collection_book_schematics0,
    outpost0,
    creative,
  ] = await Promise.all([
    ProfileHelper.createProfile(newUser, "athena"),
    ProfileHelper.createProfile(newUser, "profile0"),
    ProfileHelper.createProfile(newUser, "common_core"),
    ProfileHelper.createProfile(newUser, "campaign"),
    ProfileHelper.createProfile(newUser, "metadata"),
    ProfileHelper.createProfile(newUser, "theater0"),
    ProfileHelper.createProfile(newUser, "collection_book_people0"),
    ProfileHelper.createProfile(newUser, "collection_book_schematics0"),
    ProfileHelper.createProfile(newUser, "outpost0"),
    ProfileHelper.createProfile(newUser, "creative"),
  ]);

  await accountService.create({
    accountId: newUser.accountId,
    discordId,
    arenaHype: 0,
  });

  await Promise.all([
    profilesService.createOrUpdate(newUser.accountId, "profile0", profile0),
    profilesService.createOrUpdate(newUser.accountId, "athena", athena),
    profilesService.createOrUpdate(
      newUser.accountId,
      "common_core",
      common_core,
    ),
    profilesService.createOrUpdate(
      newUser.accountId,
      "common_public",
      common_core,
    ),
    profilesService.createOrUpdate(newUser.accountId, "campaign", campaign),
    profilesService.createOrUpdate(newUser.accountId, "metadata", metadata),
    profilesService.createOrUpdate(newUser.accountId, "theater0", theater0),
    profilesService.createOrUpdate(newUser.accountId, "outpost0", outpost0),
    profilesService.createOrUpdate(newUser.accountId, "creative", creative),
    profilesService.createOrUpdate(
      newUser.accountId,
      "collection_book_people0",
      collection_book_people0,
    ),
    profilesService.createOrUpdate(
      newUser.accountId,
      "collection_book_schematics0",
      collection_book_schematics0,
    ),
    friendsService.create({ accountId: newUser.accountId }),
    receiptsService.create(newUser.accountId, []),
    accountService.createDefaultPermissions(newUser.accountId),
  ]);

  const statsTemplate = ProfileHelper.createStatsTemplate();
  await seasonStatsService.create({
    solos: statsTemplate.solos,
    duos: statsTemplate.duos,
    squads: statsTemplate.squads,
    ltm: statsTemplate.ltm,
    accountId: newUser.accountId,
  });

  return newUser;
}

function collectFiles(
  rootDir: string,
  dir: string,
): Array<{ path: string; size: number }> {
  const results: Array<{ path: string; size: number }> = [];
  let entries: fs.Dirent[];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return results;
  }
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...collectFiles(rootDir, fullPath));
    } else if (entry.isFile()) {
      const relPath = path.relative(rootDir, fullPath).replace(/\\/g, "/");
      results.push({ path: relPath, size: fs.statSync(fullPath).size });
    }
  }
  return results;
}

let cachedManifest: object | null = null;
let cachedMemorySplash: { body: Buffer; contentType: string } | null = null;

function contentTypeFor(filePath: string): string {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".png") return "image/png";
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".webp") return "image/webp";
  if (ext === ".gif") return "image/gif";
  if (ext === ".svg") return "image/svg+xml";
  return "application/octet-stream";
}

function resolveSplashPath(version: string): string | null {
  const splashPath = Bun.env.LAUNCHER_SPLASH_PATH;
  if (!splashPath) return null;

  const resolved = path.resolve(splashPath);
  if (!fs.existsSync(resolved)) return null;

  const stat = fs.statSync(resolved);
  if (stat.isFile()) return resolved;
  if (!stat.isDirectory()) return null;

  const candidates = [
    `${version}.png`,
    `${version}.jpg`,
    `${version}.jpeg`,
    `${version}.webp`,
    `${version}.svg`,
    "splash.png",
    "splash.jpg",
    "splash.jpeg",
    "splash.webp",
    "splash.svg",
  ];

  for (const candidate of candidates) {
    const candidatePath = path.join(resolved, candidate);
    if (fs.existsSync(candidatePath) && fs.statSync(candidatePath).isFile()) {
      return candidatePath;
    }
  }

  return null;
}

async function getMemorySplash(): Promise<{
  body: Buffer;
  contentType: string;
} | null> {
  if (cachedMemorySplash) return cachedMemorySplash;

  const splashFile = Bun.file(
    path.join(__dirname, "..", "..", "memory", "images", "Splash.b64"),
  );
  if (!(await splashFile.exists())) return null;

  const raw = (await splashFile.text()).trim();
  const match = raw.match(/^data:([^;]+);base64,(.+)$/s);
  if (!match) return null;

  cachedMemorySplash = {
    contentType: match[1],
    body: Buffer.from(match[2], "base64"),
  };

  return cachedMemorySplash;
}

function fallbackSplash(version: string): Response {
  const escapedVersion = version.replace(/[<>&"]/g, "");
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#121826"/>
      <stop offset="0.52" stop-color="#264653"/>
      <stop offset="1" stop-color="#e76f51"/>
    </linearGradient>
  </defs>
  <rect width="1280" height="720" fill="url(#bg)"/>
  <rect x="76" y="76" width="1128" height="568" rx="18" fill="rgba(0,0,0,0.26)" stroke="rgba(255,255,255,0.18)" stroke-width="2"/>
  <text x="112" y="335" fill="#ffffff" font-family="Arial, Helvetica, sans-serif" font-size="92" font-weight="800">Fortnite</text>
  <text x="118" y="408" fill="#f7f7f7" font-family="Arial, Helvetica, sans-serif" font-size="34">Build ${escapedVersion}</text>
  <text x="118" y="500" fill="#f0f0f0" font-family="Arial, Helvetica, sans-serif" font-size="24">Launcher assets loaded</text>
</svg>`;

  return new Response(svg, {
    headers: {
      "Content-Type": "image/svg+xml",
      "Cache-Control": "public, max-age=300",
    },
  });
}

function resolveFavoriteCharacter(athena: any): string {
  const favoriteCharacter = athena?.stats?.attributes?.favorite_character;
  if (typeof favoriteCharacter !== "string" || favoriteCharacter.length === 0) {
    return "AthenaCharacter:CID_001_Athena_Commando_F_Default";
  }

  if (favoriteCharacter.startsWith("AthenaCharacter:")) {
    return favoriteCharacter;
  }

  const item = athena?.items?.[favoriteCharacter];
  if (
    typeof item?.templateId === "string" &&
    item.templateId.startsWith("AthenaCharacter:")
  ) {
    return item.templateId;
  }

  return favoriteCharacter;
}

async function getLauncherProfileData(accountId: string) {
  const [athena, commonCore, account] = await Promise.all([
    ProfileHelper.getProfile(accountId, "athena"),
    ProfileHelper.getProfile(accountId, "common_core"),
    accountService.findUserByAccountId(accountId),
  ]);

  return {
    favorite_character: resolveFavoriteCharacter(athena),
    vbucks: commonCore?.items?.["Currency:MtxPurchased"]?.quantity ?? 0,
    level:
      athena?.stats?.attributes?.accountLevel ??
      athena?.stats?.attributes?.level ??
      15,
    arenaHype: account?.arenaHype ?? 0,
  };
}

function normalizeLauncherUsername(value: unknown): string | null {
  if (typeof value !== "string") return null;

  const username = value.trim().replace(/\s+/g, " ");
  if (username.length < 3 || username.length > 20) return null;
  if (!/^[a-zA-Z0-9 _.-]+$/.test(username)) return null;

  return username;
}

async function getLauncherAuthPayload(c: any) {
  const header = c.req.header("authorization");
  const bearerToken =
    typeof header === "string" && header.toLowerCase().startsWith("bearer ")
      ? header.slice(7).trim()
      : null;
  const body = await c.req.json().catch(() => null);
  const bodyToken = typeof body?.token === "string" ? body.token : null;
  const token = bearerToken || bodyToken;

  if (!token) return { body, payload: null, token: null };

  return { body, payload: verifyLauncherToken(token), token };
}

export default function () {
  app.get("/api/launcher/status", (c) =>
    c.json({
      online: true,
      websocket: "/launcher-ws",
      oauthCallback: "/api/launcher/callback/discord",
    }),
  );

  app.get("/api/launcher/callback/discord", async (c) => {
    const code = c.req.query("code");
    const state = c.req.query("state");

    if (!code || !state)
      return c.html(ERROR_PAGE("Missing code or state."), 400);

    const sessionId = StateMap.get(state);
    if (!sessionId)
      return c.html(ERROR_PAGE("Invalid or expired OAuth state."), 400);
    StateMap.delete(state);

    const wsSocket = Sessions.get(sessionId);

    try {
      const tokenRes = await fetch("https://discord.com/api/oauth2/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: DISCORD_CLIENT_ID,
          client_secret: DISCORD_CLIENT_SECRET,
          grant_type: "authorization_code",
          code,
          redirect_uri: CALLBACK_URI,
        }),
      });

      if (!tokenRes.ok) {
        const tokenError = await tokenRes.text();
        logger.error(`Discord launcher token exchange failed: ${tokenError}`);
        throw new Error("token exchange failed");
      }

      const tokenData = (await tokenRes.json()) as any;

      const userRes = await fetch("https://discord.com/api/users/@me", {
        headers: { Authorization: `Bearer ${tokenData.access_token}` },
      });

      if (!userRes.ok) {
        const userError = await userRes.text();
        logger.error(`Discord launcher user fetch failed: ${userError}`);
        throw new Error("failed to fetch discord user");
      }

      const discordUser = (await userRes.json()) as any;

      let user = await userService.findUserByDiscordId(discordUser.id);
      if (!user) {
        const existingAccount = await accountService.findUserByDiscordId(
          discordUser.id,
        );
        user = existingAccount
          ? await userService.findUserByAccountId(existingAccount.accountId)
          : await createLauncherUser(discordUser);
      }

      if (!user) {
        const msg = "Failed to create your launcher account. Please try again.";
        wsSend(wsSocket, { type: "auth_error", message: msg });
        return c.html(ERROR_PAGE(msg), 500);
      }

      if (user.banned) {
        const msg = "Your account has been banned.";
        wsSend(wsSocket, { type: "auth_error", message: msg });
        return c.html(ERROR_PAGE(msg), 403);
      }

      const launcherProfile = await getLauncherProfileData(user.accountId);

      const token = signLauncherToken({
        accountId: user.accountId,
        discordId: user.discordId,
        username: user.username,
        favorite_character: launcherProfile.favorite_character,
        vbucks: launcherProfile.vbucks,
        level: launcherProfile.level,
        arenaHype: launcherProfile.arenaHype,
      });

      wsSend(wsSocket, {
        type: "auth_token",
        token,
        profile: {
          accountId: user.accountId,
          username: user.username,
          favorite_character: launcherProfile.favorite_character,
          vbucks: launcherProfile.vbucks,
          level: launcherProfile.level,
          arenaHype: launcherProfile.arenaHype,
        },
      });

      return c.html(DONE_PAGE);
    } catch (error) {
      const msg = "Authentication failed. Please try again.";
      wsSend(wsSocket, { type: "auth_error", message: msg });
      return c.html(ERROR_PAGE(msg), 500);
    }
  });

  app.patch("/api/launcher/profile/username", async (c) => {
    const { body, payload } = await getLauncherAuthPayload(c);

    if (!payload) {
      return c.json({ error: "Authorization required." }, 401);
    }

    const username = normalizeLauncherUsername(body?.username);
    if (!username) {
      return c.json(
        {
          error:
            "Username must be 3-20 characters and only use letters, numbers, spaces, underscores, periods, or hyphens.",
        },
        400,
      );
    }

    const currentUser = await userService.findUserByAccountId(
      payload.accountId,
    );
    if (!currentUser || currentUser.banned) {
      return c.json({ error: "Account unavailable." }, currentUser ? 403 : 404);
    }

    const existingUser =
      await userService.findUserByUsernameInsensitive(username);
    if (existingUser && existingUser.accountId !== payload.accountId) {
      return c.json({ error: "That username is already taken." }, 409);
    }

    const updated = await userService.updateUser(payload.accountId, {
      username,
    });

    if (!updated) {
      return c.json({ error: "Failed to update username." }, 500);
    }

    const launcherProfile = await getLauncherProfileData(payload.accountId);
    const token = signLauncherToken({
      accountId: payload.accountId,
      discordId: currentUser.discordId,
      username,
      favorite_character: launcherProfile.favorite_character,
      vbucks: launcherProfile.vbucks,
      level: launcherProfile.level,
      arenaHype: launcherProfile.arenaHype,
    });
    const profile = {
      accountId: payload.accountId,
      username,
      favorite_character: launcherProfile.favorite_character,
      vbucks: launcherProfile.vbucks,
      level: launcherProfile.level,
      arenaHype: launcherProfile.arenaHype,
    };

    return c.json({ token, profile });
  });

  app.get("/api/launcher/downloads/manifest", (c) => {
    const buildPath = config.build_path;
    if (!cachedManifest) {
      const reqUrl = new URL(c.req.url);
      const filesBase = `${reqUrl.origin}/api/launcher/downloads/files`;

      if (!buildPath || !fs.existsSync(buildPath)) {
        cachedManifest = { version: "1.0.0", files: [] };
      } else {
        const raw = collectFiles(buildPath, buildPath);
        const files = raw.map(({ path: relPath, size }) => ({
          path: relPath,
          size,
          url: `${filesBase}/${relPath.split("/").map(encodeURIComponent).join("/")}`,
        }));
        cachedManifest = {
          version: config.launcher_version,
          title: `Fortnite ${config.launcher_version}`,
          files,
        };
      }
    }
    return c.json(cachedManifest);
  });

  app.get("/api/launcher/downloads/splash/:version", async (c) => {
    const version = c.req.param("version") || "default";
    const memorySplash = await getMemorySplash();

    if (memorySplash) {
      return new Response(memorySplash.body, {
        headers: {
          "Content-Type": memorySplash.contentType,
          "Cache-Control": "public, max-age=300",
        },
      });
    }

    const splashPath = resolveSplashPath(version);

    if (!splashPath) return fallbackSplash(version);

    const file = Bun.file(splashPath);
    if (!(await file.exists())) return fallbackSplash(version);

    return new Response(file, {
      headers: {
        "Content-Type": contentTypeFor(splashPath),
        "Cache-Control": "public, max-age=300",
      },
    });
  });

  app.get("/api/launcher/downloads/files/*", async (c) => {
    const buildPath = config.build_path;
    if (!buildPath) return c.text("build_path not configured", 503);

    const relEncoded = c.req.path.slice(
      "/api/launcher/downloads/files/".length,
    );
    const relPath = decodeURIComponent(relEncoded);
    const resolved = path.resolve(path.join(buildPath, relPath));

    if (!resolved.startsWith(path.resolve(buildPath) + path.sep)) {
      return c.text("Forbidden", 403);
    }

    const file = Bun.file(resolved);
    if (!(await file.exists())) return c.notFound();
    return new Response(file);
  });
}
