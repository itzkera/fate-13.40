import { ServerRegion, ServerStatus } from "../../tables/matchmaking/servers";
import {
  accountService,
  app,
  config,
  hypeService,
  logger,
  matchmaker,
  profilesService,
  serversService,
  userService,
} from "../..";

import ProfileHelper from "../../utilities/ProfileHelper";

const ADMIN_KEY = config.admin_key;

function serverIdFrom(body: any): string {
  return body.serverId ?? `${body.ip}:${body.port}`;
}

async function findServer(body: any) {
  return serversService.findByServerId(serverIdFrom(body));
}

function isAuthorized(body: any): boolean {
  return !ADMIN_KEY || body.apiKey === ADMIN_KEY || body.adminKey === ADMIN_KEY;
}

async function findUserByGameIdentifier(identifier: unknown) {
  const raw = String(identifier ?? "").trim();
  if (!raw) return null;

  const stripped = raw.replace(/-/g, "");

  return (
    (await userService.findUserByAccountId(stripped)) ??
    (await userService.findUserByUsername(raw)) ??
    (await userService.findUserByUsernameInsensitive(raw)) ??
    null
  );
}

export default function () {
  app.post("/api/v1/server/register", async (c) => {
    const body = (await c.req.json().catch(() => null)) as any;
    if (!body) return c.json({ error: "Invalid JSON body" }, 400);

   const { region, ip } = body;
const playlist = (body.playlist as string).toLowerCase();
    const port = Number(body.port);
    const maxPlayers = Number(body.maxPlayers ?? body.max_players ?? 100);
    const serverId = serverIdFrom({ ...body, port });
    const customKey =
      typeof body.customKey === "string"
        ? body.customKey
        : body.customKey
          ? "custom"
          : "none";

    if (!region || !playlist || !ip || !Number.isFinite(port)) {
      return c.json(
        {
          error: "missing required fields",
          required: ["ip", "port", "region", "playlist"],
          received: body,
        },
        400,
      );
    }

    const existing = await serversService.findByServerId(serverId);
    if (existing) {
      await serversService.update(existing.id, {
        region,
        playlist,
        ip,
        port,
        maxPlayers,
        season: Number(body.season ?? config.currentSeason),
        customKey,
        status: ServerStatus.ONLINE,
        currentPlayers: 0,
      });
    } else {
      await serversService.create({
        serverId,
        region,
        playlist,
        ip,
        port,
        maxPlayers,
        season: Number(body.season ?? config.currentSeason),
        customKey,
        status: ServerStatus.ONLINE,
        currentPlayers: 0,
      });
    }

    matchmaker["gameServers"].set(region, {
  region,
  ip,
  port,
  status: "online",
  currentPlayers: 0,
  maxPlayers: Number(body.maxPlayers ?? body.max_players ?? 100),
});
await matchmaker.startServer(region, playlist);
console.log("server playlist:", playlist);
console.log("client playlists:", Array.from(matchmaker["clients"].values()).map(c => c.playlist));
    return c.json({ success: true, serverId, matchId: serverId });
  });

  app.post("/api/v1/server/gamestarted", async (c) => {
    const body = (await c.req.json().catch(() => null)) as any;
    if (!body) return c.json({ error: "Invalid JSON body" }, 400);

    const server = await findServer(body);
    if (!server) return c.json({ error: "server not found" }, 404);

    await serversService.update(server.id, {
      status: ServerStatus.GAMESTARTED,
    });
    return c.json({ success: true });
  });

  app.post("/api/v1/server/heartbeat", async (c) => {
    const body = (await c.req.json().catch(() => null)) as any;
    if (!body) return c.json({ error: "Invalid JSON body" }, 400);

    const server = await findServer(body);
    if (!server) return c.json({ error: "server not found" }, 404);

    await serversService.update(server.id, {});
    return c.json({ success: true });
  });

  app.post("/api/v1/server/gamestopped", async (c) => {
    const body = (await c.req.json().catch(() => null)) as any;
    if (!body) return c.json({ error: "Invalid JSON body" }, 400);

    const server = await findServer(body);
    if (!server) return c.json({ error: "server not found" }, 404);

    await serversService.update(server.id, {
      status: ServerStatus.GAMEENDED,
      currentPlayers: 0,
    });

    await matchmaker.stopServer(server.region, server.playlist);

    return c.json({ success: true });
  });

  app.post("/api/v1/server/playercount", async (c) => {
    const body = (await c.req.json().catch(() => null)) as any;
    if (!body) return c.json({ error: "Invalid JSON body" }, 400);
    const { count } = body;
    if (count === undefined) return c.json({ error: "missing count" }, 400);

    const server = await findServer(body);
    if (!server) return c.json({ error: "server not found" }, 404);

    await serversService.update(server.id, { currentPlayers: count });
    return c.json({ success: true });
  });

  app.post("/api/v1/server/playerleft", async (c) => {
    const body = (await c.req.json().catch(() => null)) as any;
    if (!body) return c.json({ error: "Invalid JSON body" }, 400);

    await serversService.decrementPlayers(serverIdFrom(body));
    return c.json({ success: true });
  });

  app.post("/api/v1/arena/hype/add", async (c) => {
    const body = (await c.req.json().catch(() => null)) as any;
    if (!body) {
      logger.warn("ArenaHypeAdd: invalid JSON body");
      return c.json({ error: "Invalid JSON body" }, 400);
    }
    const { season, username } = body;
    const amount = Number(body.amount);
    logger.info(
      `ArenaHypeAdd: received username=${String(username ?? "")} amount=${String(body.amount ?? "")} season=${String(season ?? "")}`,
    );
    if (!season) {
      logger.warn("ArenaHypeAdd: missing season");
      return c.json({ error: "missing season" }, 400);
    }

    if (username && body.amount !== undefined) {
      if (!isAuthorized(body)) {
        logger.warn(
          `ArenaHypeAdd: unauthorized request for username=${String(username)}`,
        );
        return c.json({ error: "unauthorized" }, 401);
      }
      if (!Number.isFinite(amount) || amount === 0) {
        logger.warn(`ArenaHypeAdd: invalid amount=${String(body.amount)}`);
        return c.json({ error: "amount must be a non-zero number" }, 400);
      }

      const user = await findUserByGameIdentifier(username);
      if (!user) {
        logger.warn(
          `ArenaHypeAdd: user not found identifier=${String(username)}`,
        );
        return c.json({ error: "user not found" }, 404);
      }

      const account = await accountService.findUserByAccountId(user.accountId);
      if (!account) {
        logger.warn(
          `ArenaHypeAdd: account not found accountId=${user.accountId}`,
        );
        return c.json({ error: "account not found" }, 404);
      }

      const arenaHype = await accountService.addArenaHype(
        user.accountId,
        amount,
      );
      if (arenaHype === null) {
        logger.error(
          `ArenaHypeAdd: account not updated accountId=${user.accountId}`,
        );
        return c.json({ error: "account not updated" }, 500);
      }

      await hypeService.create(Number(season));
      logger.info(
        `ArenaHypeAdd: applied accountId=${user.accountId} username=${user.username} amount=${amount} newHype=${arenaHype}`,
      );
      return c.json({ success: true, accountId: user.accountId, arenaHype });
    }

    await hypeService.create(season);
    logger.info(
      `ArenaHypeAdd: ensured division tokens for season=${String(season)}`,
    );
    return c.json({ success: true });
  });

  app.post("/api/v1/player/reward", async (c) => {
    const body = (await c.req.json().catch(() => null)) as any;
    if (!body) return c.json({ error: "Invalid JSON body" }, 400);
    if (!isAuthorized(body)) return c.json({ error: "unauthorized" }, 401);

    const username = String(body.username ?? "").trim();
    const amount = Number(body.amount ?? 0);
    if (!username || !Number.isFinite(amount) || amount === 0)
      return c.json(
        { error: "username and non-zero amount are required" },
        400,
      );

    const user = await findUserByGameIdentifier(username);
    if (!user) {
      logger.warn(`PlayerReward: user not found for identifier=${username}`);
      return c.json({ error: "user not found" }, 404);
    }

    const commonCore = await ProfileHelper.getProfile(
      user.accountId,
      "common_core",
    );
    if (!commonCore)
      return c.json({ error: "common_core profile not found" }, 404);
    if (!commonCore.items) commonCore.items = {};

    const items = commonCore.items as Record<string, any>;
    const vbucksKey = Object.keys(items).find((k) =>
      items[k].templateId?.startsWith("Currency:Mtx"),
    );
    if (vbucksKey) {
      items[vbucksKey].quantity += amount;
    } else {
      items[crypto.randomUUID()] = {
        templateId: "Currency:MtxPurchased",
        attributes: { platform: "Shared" },
        quantity: amount,
      };
    }

    await profilesService.update(user.accountId, "common_core", commonCore);
    const balance = vbucksKey ? items[vbucksKey].quantity : amount;
    logger.info(
      `PlayerReward: +${amount} V-Bucks to ${user.username} (${body.reason ?? "no reason"}) balance=${balance}`,
    );

    return c.json({
      success: true,
      accountId: user.accountId,
      username: user.username,
      amount,
      balance,
    });
  });

  app.get("/api/v1/arena/hype", async (c) => {
    const hypes = await hypeService.getAll();
    return c.json(hypes);
  });

  app.get("/api/v1/servers", async (c) => {
    const info = matchmaker.getServerInfo();
    return c.json({ success: true, ...info });
  });
}
