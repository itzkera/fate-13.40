import {
  accountService,
  app,
  config,
  clientService,
  logger,
  matchmakingKeysService,
  serversService,
  sessionsService,
  userService,
} from "../..";
import hosts from "../../../hosts.json";
import { Validation } from "../../modules/middleware/validation";
import { Encryption } from "../../utilities/encryption";
import errors from "../../utilities/errors";
import uaparser from "../../utilities/uaparser";
import { v4 as uuid } from "uuid";
import jwt from "jsonwebtoken";
import crypto from "crypto";

type HostsConfig = {
  GameSevers: Record<string, string>;
  Regions: Record<string, { address: string; port: number }>;
};

const { GameSevers, Regions } = hosts as HostsConfig;

function getClientIp(c: any): string {
  const forwarded = c.req.header("x-forwarded-for")?.split(",")[0]?.trim();
  const ip =
    c.req.header("cf-connecting-ip") ??
    c.req.header("x-real-ip") ??
    forwarded ??
    "127.0.0.1";

  return ip.startsWith("::ffff:") ? ip.slice(7) : ip;
}

interface SessionInfo {
  region: string;
  playlist: string;
  bucketId: string;
  ip: string;
  port: number;
  players: string[];
  createdAt: Date;
}

const activeSessions = new Map<string, SessionInfo>();

function getMatchmakerUrl(c: any): string {
  const host = c.req.header("x-forwarded-host") ?? c.req.header("host") ?? "127.0.0.1";
  const hostname = host.split(":")[0];
  const protocol = c.req.header("x-forwarded-proto") === "https" ? "wss" : "ws";

  return `${protocol}://${hostname}:80`;
}

export default function () {
  app.get(
    "/fortnite/api/game/v2/matchmakingservice/ticket/player/:accountId",
    Validation.verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");
      const bucketId = c.req.query("bucketId");
      const timestamp = new Date().toISOString();

      const user = await userService.findUserByAccountId(accountId);

      const useragent = c.req.header("User-Agent");

      if (!useragent)
        return c.json(
          errors.createError(400, c.req.url, "header 'User-Agent' is missing.", timestamp),
          400,
        );

      const uahelper = uaparser(useragent);

      if (!uahelper)
        return c.json(
          errors.createError(400, c.req.url, "Failed to parse User-Agent.", timestamp),
          400,
        );

      const accessToken = c.req.header("Authorization")?.split("bearer ")[1].replace("eg1~", "");

      if (!accessToken || !user)
        return c.json(errors.createError(400, c.req.url, "Failed to find user.", timestamp));

      if (accountId !== user.accountId)
        return c.json(errors.createError(400, c.req.url, "This is not your account.", timestamp));

      if (user.banned)
        return c.json(errors.createError(403, c.req.url, "You are banned", timestamp), 403);

      const bucketIds = bucketId?.split(":");

      if (bucketIds!.length < 4 || bucketIds!.length !== 4 || typeof bucketId !== "string")
        return c.json(errors.createError(400, c.req.url, "Invalid BucketId.", timestamp), 400);

      if (!bucketIds![2] || !bucketIds)
        return c.json(errors.createError(400, c.req.url, "Invalid BucketId.", timestamp), 400);

      const playlist = bucketIds![3];
      const region = bucketIds![2];

      const matchmakingKey = c.req.query("player.option.customKey");
      if (matchmakingKey) {
        await matchmakingKeysService.create({ interaction: accountId, key: matchmakingKey });
      } else {
        const allKeysForUser = (await matchmakingKeysService.findAll()).filter(
          (x) => x.interaction == accountId,
        );

        for (const key of allKeysForUser) {
          await matchmakingKeysService.delete(key.id);
        }
      }

      const payload = {
        playerId: accountId,
        partyPlayerIds: [accountId],
        bucketId: bucketId,
        attributes: c.req.queries(),
        expireAt: new Date(Date.now() + 60000).toISOString(),
        nonce: crypto.randomBytes(16).toString("hex"),
      };

      const regionInfo = Regions[region as keyof typeof Regions];

      const userIp = getClientIp(c);

      activeSessions.set(userIp, {
        region,
        playlist,
        bucketId: bucketId!,
        ip: regionInfo?.address || "127.0.0.1",
        port: regionInfo?.port || 6767,
        players: [accountId],
        createdAt: new Date(),
      });

      const base64Payload = Buffer.from(JSON.stringify(payload)).toString("base64");

      const matchmakingData = jwt.sign(
        {
          accountId: accountId,
          region: region,
          playlist: playlist,
          type: typeof matchmakingKey === "string" ? "custom" : "normal",
          key: typeof matchmakingKey === "string" ? matchmakingKey : undefined,
          bucket: bucketId,
          version: uahelper.season,
        },
        config.client_secret,
      );

      return c.json({
        serviceUrl: getMatchmakerUrl(c),
        ticketType: "matchmaker",
        payload: base64Payload,
        signature: matchmakingData,
      });
    },
  );

  app.get(
    "/fortnite/api/game/v2/matchmaking/account/:accountId/session/:sessionId",
    Validation.verifyToken,
    async (c) => {
      const sessionId = c.req.param("sessionId");
      const accountId = c.req.param("accountId");

      return c.json({
        accountId: accountId,
        sessionId: sessionId,
        key: "none",
      });
    },
  );

  app.get("/fortnite/api/matchmaking/session/:sessionId", Validation.verifyToken, async (c) => {
    const sessionId = c.req.param("sessionId");

    const timestamp = new Date().toISOString();
    const userIp = getClientIp(c);

    const client = await clientService.findBySessionId(sessionId);
    const ipSession = activeSessions.get(userIp);
    const region = client?.region ?? ipSession?.region;
    const playlist = client?.playlist ?? ipSession?.playlist;
    const bucketId = ipSession?.bucketId ?? `13920814:1:${region}:${playlist}`;
    const regionInfo = region ? Regions[region as keyof typeof Regions] : undefined;
    const serverIp = regionInfo?.address ?? ipSession?.ip ?? "127.0.0.1";
    const serverPort = regionInfo?.port ?? ipSession?.port ?? 7777;

    if (!region || !playlist) {
      logger.warn(`MatchmakingSession: session not found sessionId=${sessionId} ip=${userIp}`);
      return c.json(
        errors.createError(404, c.req.url, "Matchmaking session not found.", timestamp),
        404,
      );
    }

    const buildUniqueId = parseInt(bucketId.split(":")[0]) || 13920814;

    return c.json({
      id: sessionId,
      ownerId: uuid().replace(/-/gi, "").toUpperCase(),
      ownerName: "[DS]fortnite-liveeugcec1c2e30ubrcore0a-z8hj-1968",
      serverName: "[DS]fortnite-liveeugcec1c2e30ubrcore0a-z8hj-1968",
      serverAddress: GameSevers[serverIp] ?? serverIp,
      serverPort,
      maxPublicPlayers: 220,
      openPublicPlayers: 175,
      maxPrivatePlayers: 0,
      openPrivatePlayers: 0,
      attributes: {
        REGION_s: region,
        GAMEMODE_s: "FORTATHENA",
        ALLOWBROADCASTING_b: true,
        SUBREGION_s: "GB",
        DCID_s: "FORTNITE-LIVEEUGCEC1C2E30UBRCORE0A-14840880",
        tenant_s: "Fortnite",
        MATCHMAKINGPOOL_s: "Any",
        STORMSHIELDDEFENSETYPE_i: 0,
        HOTFIXVERSION_i: 0,
        PLAYLISTNAME_s: playlist,
        SESSIONKEY_s: uuid().replace(/-/gi, "").toUpperCase(),
        TENANT_s: "Fortnite",
        BEACONPORT_i: 15009,
      },
      publicPlayers: [],
      privatePlayers: [],
      totalPlayers: 45,
      allowJoinInProgress: false,
      shouldAdvertise: false,
      isDedicated: false,
      usesStats: false,
      allowInvites: false,
      usesPresence: false,
      allowJoinViaPresence: true,
      allowJoinViaPresenceFriendsOnly: false,
      buildUniqueId,
      lastUpdated: new Date().toISOString(),
      started: false,
    });
  });

  app.post(
    "/fortnite/api/matchmaking/session/:sessionId/join",
    Validation.verifyToken,
    async (c) => {
      const sessionId = c.req.param("sessionId");
      const timestamp = new Date().toISOString();

      return c.body(null, 200);
    },
  );

  app.get(
    "/fortnite/api/matchmaking/session/findPlayer/:sessionId",
    Validation.verifyToken,
    async (c) => {
      const sessionId = c.req.param("sessionId");
      const timestamp = new Date().toISOString();

      return c.json([], 200);
    },
  );
}
