import { app, userService } from "../..";
import { peekMobileAuthCode } from "../../utilities/launcher/mobileauthcodes";
import errors from "../../utilities/errors";

const STYLES = `
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #0d0d0d;
    font-family: 'Segoe UI', sans-serif;
    color: #fff;
  }
  .card {
    background: #1a1a2e;
    border: 1px solid #2a2a4a;
    border-radius: 16px;
    padding: 40px 36px;
    width: 100%;
    max-width: 420px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.5);
  }
  h1 { font-size: 1.6rem; margin-bottom: 6px; }
  p { color: #aaa; font-size: 0.9rem; margin-bottom: 28px; }
  label { display: block; font-size: 0.85rem; color: #ccc; margin-bottom: 8px; }
  input {
    width: 100%;
    padding: 12px 14px;
    border-radius: 8px;
    border: 1px solid #3a3a5e;
    background: #0d0d1e;
    color: #fff;
    font-size: 0.95rem;
    outline: none;
    transition: border-color 0.2s;
    margin-bottom: 20px;
  }
  input:focus { border-color: #5865f2; }
  button {
    width: 100%;
    padding: 13px;
    border-radius: 8px;
    border: none;
    background: #5865f2;
    color: #fff;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
  }
  button:hover { background: #4752c4; }
  .msg { margin-top: 18px; font-size: 0.85rem; text-align: center; min-height: 20px; }
  .msg.error { color: #f87171; }
`;

function loginPage(error?: string) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Fate</title>
  <style>${STYLES}</style>
</head>
<body>
  <div class="card">
    <h1>Mobile Login</h1>
    <p>Run <strong>/mobile</strong> in Discord, then enter the code below.</p>
    <form method="GET" action="/auth/mobile/exchange">
      <label for="code">Code</label>
      <input id="code" name="code" type="text" placeholder="Code goes here..." autocomplete="off" ${error ? `value=""` : ""} />
      <button type="submit">Login</button>
    </form>
    ${error ? `<div class="msg error">${error}</div>` : ""}
  </div>
</body>
</html>`;
}

export default function () {
  app.get("/auth/mobile", (c) => {
     const error = c.req.query("error");
    return c.html(loginPage(error));
  });


  const renderMobileLogin = (c: any) => {
    const error = c.req.query("error");
    return c.html(loginPage(error));
  };

  app.get("/id/login", renderMobileLogin);
  app.get("/id/register", renderMobileLogin);

 app.get("/auth/mobile/exchange", async (c) => {
    const code = (c.req.query("code") ?? "").trim();

    if (!code) {
      return c.redirect("/auth/mobile?error=Please+enter+your+auth+code.");
    }

    const accountId = peekMobileAuthCode(code);
    if (!accountId) {
      return c.redirect("/auth/mobile?error=Invalid+or+expired+auth+code.");
    }

    const user = await userService.findUserByAccountId(accountId);
    if (!user) {
      return c.redirect("/auth/mobile?error=Account+not+found.");
    }

    const target = "com.epicgames.fortnite://authorize/?code=" + encodeURIComponent(code);
    return c.html(`<!DOCTYPE html>
<html><head><meta charset="UTF-8"/></head>
<body>
<script>window.location.href=${JSON.stringify(target)};</script>
</body></html>`);
  });
}
