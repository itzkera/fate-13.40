import { app, config, deviceAuthService, logger, tokensService, userService } from "../..";
import type { User } from "../../tables/user";
import errors from "../../utilities/errors";
import TokenUtilities from "../../utilities/tokens";
import { v4 as uuid } from "uuid";
import jwt, { type JwtPayload } from "jsonwebtoken";
import crypto from "node:crypto";
import { createExchangeCode, redeemExchangeCode } from "../../utilities/launcher/exchangecodes";
import { redeemMobileAuthCode } from "../../utilities/launcher/mobileauthcodes";

export function validateBase64(input: string) {
  return /^[A-Za-z0-9+/]*={0,2}$/.test(input);
}

export default function () {
  app.delete("/account/api/oauth/sessions/kill", async (c) => c.body(null, 200));

  app.post("/account/api/oauth/token", async (c) => {
    const authHeader = c.req.header("Authorization");
    const body: any = await c.req.parseBody();
    const grantType = String(body.grant_type ?? "");
    const clientId = authHeader?.toLowerCase().startsWith("basic ")
      ? Buffer.from(authHeader.slice("basic ".length), "base64").toString().split(":")[0]
      : "clientId";

    if (grantType === "client_credentials") {
      const clientToken = jwt.sign(
        {
          p: crypto.randomBytes(128).toString("base64"),
          clsvc: "fortnite",
          t: "s",
          mver: false,
          clid: clientId,
          ic: true,
          am: "client_credentials",
          iat: Math.floor(Date.now() / 1000),
          jti: uuid(),
          token_creation_time: new Date().toISOString(),
          expires_in: 1,
        },
        config.client_secret,
        { expiresIn: 3600 },
      );

      return c.json({
        access_token: `eg1~${clientToken}`,
        expires_in: 3600,
        expires_at: "9999-12-02T01:12:01.100Z",
        token_type: "bearer",
        client_id: clientId,
        internal_client: true,
        client_service: "fortnite",
      });
    }

    let user: User | null = null;

    if (grantType === "exchange_code") {
      const exchangeCode = body.exchange_code;
      if (!exchangeCode)
        return c.json(errors.createError(400, c.req.url, "'exchange_code' is missing.", new Date().toISOString()), 400);

      const exchangedAccountId = redeemExchangeCode(String(exchangeCode));
      if (!exchangedAccountId)
        return c.json(errors.createError(400, c.req.url, "Invalid exchange code.", new Date().toISOString()), 400);

      user = await userService.findUserByAccountId(exchangedAccountId);
      if (!user)
        return c.json(errors.createError(404, c.req.url, "Failed to find user.", new Date().toISOString()), 404);
    } else if (grantType === "authorization_code") {
      const code = body.code;
      if (!code)
        return c.json(
          errors.createError(400, c.req.url, "'code' is missing.", new Date().toISOString()),
          400,
        );

      const mobileAccountId = redeemMobileAuthCode(String(code));
      if (!mobileAccountId)
        return c.json(
          errors.createError(400, c.req.url, "Invalid or expired authorization code.", new Date().toISOString()),
          400,
        );

      user = await userService.findUserByAccountId(mobileAccountId);
      if (!user)
        return c.json(errors.createError(404, c.req.url, "Failed to find user.", new Date().toISOString()), 404);
    } else if (grantType === "device_auth") {
      const deviceAccountId = String(body.account_id ?? "");
      const deviceId = String(body.device_id ?? "");
      const secret = String(body.secret ?? "");

      if (!deviceAccountId || !deviceId || !secret)
        return c.json(
          errors.createError(400, c.req.url, "'account_id', 'device_id', and 'secret' are required.", new Date().toISOString()),
          400,
        );

      const deviceAuth = await deviceAuthService.findByAccountIdAndSecret(deviceAccountId, deviceId, secret);
      if (!deviceAuth)
        return c.json(
          errors.createError(401, c.req.url, "Invalid device auth credentials.", new Date().toISOString()),
          401,
        );

      await deviceAuthService.updateLastAccess(deviceId, {
        location: "Unknown",
        ipAddress: c.req.header("x-forwarded-for") ?? "127.0.0.1",
        dateTime: new Date().toISOString(),
      });

      user = await userService.findUserByAccountId(deviceAccountId);
    } else if (grantType === "refresh_token") {
      const refreshToken = String(body.refresh_token ?? "").replace("eg1~", "");
      try {
        const decoded = jwt.verify(refreshToken, config.client_secret, {
          ignoreExpiration: true,
        }) as JwtPayload;
        user = await userService.findUserByAccountId(decoded.sub as string);
      } catch {
        return c.json(errors.createError(400, c.req.url, "Invalid refresh token.", new Date().toISOString()), 400);
      }
    } else if (grantType === "password" || !grantType) {
      const username = typeof body.username === "string" ? body.username.trim() : "";
      const password = typeof body.password === "string" ? body.password : "";

      if (!username || !password) {
        return c.json(
          errors.createError(400, c.req.url, "username and password are required.", new Date().toISOString()),
          400,
        );
      }

      user = username.includes("@")
        ? await userService.findUserByEmail(username.toLowerCase())
        : (await userService.findUserByAccountId(username)) ??
          (await userService.findUserByUsername(username));

      if (!user || !(await Bun.password.verify(password, user.password))) {
        return c.json(
          errors.createError(404, c.req.url, "Invalid account credentials.", new Date().toISOString()),
          404,
        );
      }
    } else {
      return c.json(
        errors.createError(400, c.req.url, `Unsupported grant_type '${grantType}'.`, new Date().toISOString()),
        400,
      );
    }

    if (!user)
      return c.json(errors.createError(404, c.req.url, "Failed to find user.", new Date().toISOString()), 404);

    if (user.banned)
      return c.json(errors.createError(403, c.req.url, "This user is banned.", new Date().toISOString()), 403);

    const accessToken = await TokenUtilities.createAccessToken(clientId, grantType || "password", user);
    const refreshToken = await TokenUtilities.createRefreshToken(clientId, user);

    return c.json({
      access_token: `eg1~${accessToken}`,
      expires_in: 28800,
      expires_at: "9999-12-02T01:12:01.100Z",
      token_type: "bearer",
      refresh_token: `eg1~${refreshToken}`,
      refresh_expires: 86400,
      refresh_expires_at: "9999-12-02T01:12:01.100Z",
      account_id: user.accountId,
      client_id: clientId,
      internal_client: true,
      client_service: "fortnite",
      displayName: user.username,
      app: "fortnite",
      in_app_id: user.accountId,
      device_id: "deviceId",
    });
  });

  app.delete("/account/api/oauth/sessions/kill/:token", async (c) => {
    const token = c.req.param("token");
    const Authorization = c.req.header("Authorization");
    const timestamp = new Date().toISOString();

    if (!token)
      return c.json(
        errors.createError(400, c.req.url, "Parameter 'token' is missing.", timestamp),
        400,
      );

    if (!Authorization)
      return c.json(errors.createError(400, c.req.url, "Invalid Token.", timestamp), 400);

    const decodedToken = jwt.verify(token.replace("eg1~", ""), config.client_secret) as JwtPayload;

    if (typeof decodedToken === "string" || !decodedToken)
      return c.json(errors.createError(400, c.req.url, "Invalid Token.", timestamp), 400);

    const user = await userService.findUserByAccountId(decodedToken.sub as string);

    if (!user)
      return c.json(errors.createError(404, c.req.url, "Failed to find user.", timestamp), 404);

    await tokensService.getTokenByTypeAndAccountId("accesstoken", user.accountId);
    await tokensService.getTokenByTypeAndAccountId("refreshtoken", user.accountId);

    return c.body(null, 200);
  });

  app.post("/account/api/oauth/createExchangeCode", async (c) => {
    const timestamp = new Date().toISOString();

    const body = await c.req.json();

    if (!body) {
      logger.error(`Invalid 'body': ${body}`);
      return c.json(errors.createError(400, c.req.url, "'body' is missing.", timestamp), 400);
    }

    if (!body.accountId) {
      logger.error(`Invalid 'accountId': ${body.accountId}`);
      return c.json(errors.createError(400, c.req.url, "'accountId' is missing.", timestamp), 400);
    }

    if (body.endpointAccessToken !== config.client_secret) {
      logger.error(`Invalid 'accessToken': ${body.endpointAccessToken}`);
      return c.json(errors.createError(400, c.req.url, "Invalid 'accessToken'.", timestamp), 400);
    }

    await tokensService.create(
      {
        type: "exchangecode",
        accountId: body.accountId,
        token: uuid().replace(/-/g, ""),
        clientId: "",
        grant: "exchange_code",
      },
      body.accountId,
    );

    const code = await tokensService.getTokenByTypeAndAccountId("exchangecode", body.accountId);

    if (!code)
      return c.json(errors.createError(500, c.req.url, "Failed to create token.", timestamp), 500);

    return c.json({
      code: code.token,
    });
  });

  app.get("/account/api/oauth/exchange", async (c) => {
    const timestamp = new Date().toISOString();
    const authorization = c.req.header("Authorization") ?? "";

    if (!authorization.toLowerCase().startsWith("bearer eg1~"))
      return c.json(errors.createError(401, c.req.url, "Authentication required.", timestamp), 401);

    const rawToken = authorization.slice("bearer eg1~".length);

    let decoded: JwtPayload;
    try {
      decoded = jwt.verify(rawToken, config.client_secret) as JwtPayload;
    } catch {
      return c.json(errors.createError(401, c.req.url, "Invalid token.", timestamp), 401);
    }

    const user = await userService.findUserByAccountId(decoded.sub as string);
    if (!user)
      return c.json(errors.createError(404, c.req.url, "Failed to find user.", timestamp), 404);

    const code = createExchangeCode(user.accountId);
    const creatingClientId: string = decoded.clid ?? "";

    return c.json({
      expiresInSeconds: 300,
      code,
      creatingClientId,
    });
  });

  app.get("/account/api/oauth/verify", async (c) => {
    const body: any = await c.req.parseBody();
    const authorization = c.req.header("authorization");

    let accountId = body.username || "Nexa";
    if (accountId.includes("@")) {
      accountId = accountId.split("@")[0];
    }

    return c.json({
      token: authorization,
      session_id: "9a1f5e80b47d2c3e6f8a0dc592b4fe7d",
      token_type: "bearer",
      client_id: "clientId",
      internal_client: true,
      client_service: "fortnite",
      account_id: accountId,
      expires_in: 28800,
      expires_at: "9999-12-02T01:12:01.100Z",
      auth_method: "exchange_code",
      displayName: accountId,
      app: "fortnite",
      in_app_id: accountId,
      device_id: "deviceId",
    });
  });

  function encodeToken(data: object) {
    return Buffer.from(JSON.stringify(data)).toString("base64");
  }

  function decodeToken(token: string): any | null {
    try {
      return JSON.parse(Buffer.from(token, "base64").toString());
    } catch {
      return null;
    }
  }

  app.post("/auth/v1/oauth/token", (c) => {
    return c.json({
      access_token: encodeToken({ oauth: true }),
      token_type: "bearer",
      expires_in: 2069,
      expires_at: "2069-01-01T00:00:00.000Z",
      nonce: "none",
      features: ["AntiCheat", "Connect", "Ecom"],
      deployment_id: "wowdeployid",
      organization_id: "woworgid",
      organization_user_id: "woworguserid",
      product_id: "prod-fn",
      product_user_id: "wowproductuserid",
      product_user_id_created: false,
      id_token: "wowidtoken",
      sandbox_id: "fn",
    });
  });

  app.get("/epic/id/v2/sdk/accounts", (c) => {
    return c.json([
      {
        accountId: uuid().replace(/-/g, ""),
        displayName: uuid().replace(/-/g, ""),
        preferredLanguage: "en",
        cabinedMode: false,
        empty: false,
      },
    ]);
  });

  app.post("/epic/oauth/v2/token", async (c) => {
    const body = await c.req.formData();
    const refresh_token = body.get("refresh_token");
    if (!refresh_token) {
      return c.json({ error: "Missing refresh_token" }, 400);
    }

    const timestamp = new Date().toISOString();

    const decodedToken = jwt.verify(
      refresh_token.toString().replace("eg1~", ""),
      config.client_secret,
    ) as JwtPayload;

    if (typeof decodedToken === "string" || !decodedToken)
      return c.json(errors.createError(400, c.req.url, "Invalid Token.", timestamp), 400);

    return c.json({
      scope: "basic_profile friends_list openid presence",
      token_type: "bearer",
      access_token: encodeToken({ accountId: decodedToken.sub }),
      expires_in: 2069,
      expires_at: "2069-01-01T00:00:00.000Z",
      refresh_token: "wowrefreshtoken",
      refresh_expires_in: 2067,
      refresh_expires_at: "2067-01-01T00:00:00.000Z",
      account_id: decodedToken.sub,
      client_id: "wowclientid",
      application_id: "wowappid",
      selected_account_id: decodedToken.sub,
      id_token: "wowidtoken",
    });
  });

  app.post("/telemetry/data/datarouter/api/v1/public/data", (c) => c.body(null, 204));
  app.post("/datarouter/api/v1/public/data", (c) => c.body(null, 204));

  app.all("/v1/epic-settings/public/users/:accountId/values", (c) =>
    c.json({
      response: {
        settings: [
          {
            namespace: "profile",
            settingName: "allow-non-squad-users-to-see-my-username",
            effectiveValue: true,
            effectiveSource: "preference",
            parentLimit: true,
          },
          {
            namespace: "profile",
            settingName: "can-see-player-usernames-from-other-squads",
            effectiveValue: true,
            effectiveSource: "preference",
            parentLimit: true,
          },
          {
            namespace: "chat",
            settingName: "filter-out-mature-language",
            effectiveValue: false,
            effectiveSource: "preference",
            parentLimit: false,
          },
          {
            namespace: "chat",
            settingName: "text",
            effectiveValue: "everybody",
            effectiveSource: "preference",
            parentLimit: "everybody",
          },
          {
            namespace: "chat",
            settingName: "voice",
            effectiveValue: "everybody",
            effectiveSource: "preference",
            parentLimit: "everybody",
          },
        ],
      },
      meta: {
        requestId: "",
        timestamp: new Date(),
      },
    }),
  );

  app.post("/publickey/*/publickey/", (c) => c.json([]));
  app.post("/epic/oauth/v2/tokenInfo", (c) =>
    c.json({
      active: true,
      token_type: "bearer",
      expires_in: 2067,
      expires_at: "2069-01-01T00:00:00.000Z",
      client_id: "ec684b8c687f479fadea3cb2ad83f5c6",
      application_id: "fghi4567FNFBKFz3E4TROb0bmPS8h1GW",
    }),
  );

  app.get("/epic/friends/v1/:accountId/blocklist", (c) => c.json([]));
  app.post("/epic/oauth/v2/revoke", (c) => c.body(null, 204));
}
