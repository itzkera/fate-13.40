import type { Context } from "hono";
import crypto from "node:crypto";
import axios from "axios";
import jwt from "jsonwebtoken";
import { app, userService, friendsService } from "../..";
import errors from "../../utilities/errors";
import uaparser from "../../utilities/uaparser";
import { v4 as uuid } from "uuid";
import { sendXmppMessageToId } from "../../modules/xmpp/functions/SendMessageToId";

interface PartyConnection {
  id: string;
  connected_at: string;
  updated_at: string;
  yield_leadership: boolean;
  meta: Record<string, any>;
}

interface PartyMember {
  account_id: string;
  meta: Record<string, any>;
  connections: PartyConnection[];
  revision: number;
  updated_at: string;
  joined_at: string;
  role: string;
}

interface PartyInvite {
  party_id: string;
  sent_by: string;
  meta: any;
  sent_to: string;
  sent_at: string;
  updated_at: string;
  expires_at: string;
  status: string;
}

interface PartyPing {
  sent_by: string;
  sent_to: string;
  sent_at: string;
  expires_at: string;
  meta: any;
}

interface PartyIntention {
  requester_id: string;
  requester_dn: string;
  requester_pl: string;
  requester_pl_dn: string;
  requestee_id: string;
  meta: any;
  expires_at: string;
  sent_at: string;
}

interface Party {
  id: string;
  created_at: string;
  updated_at: string;
  config: Record<string, any>;
  members: PartyMember[];
  applicants: any[];
  meta: Record<string, any>;
  invites: PartyInvite[];
  revision: number;
  intentions: PartyIntention[];
}

interface VoiceParticipant {
  puid: string;
  clientIP: string;
  hardMuted: boolean;
}

interface VoiceInfo {
  name: string;
  url: string;
  tokens: Record<string, string>;
}

const parties: Record<string, Party> = {};
const pings: PartyPing[] = [];
const vcParticipants: Record<string, VoiceParticipant[]> = {};
const vcInfo: Record<string, VoiceInfo> = {};
let lastClient: { access_token: string; token_type: string; expires_at: string } | undefined;

function makeId(): string {
  return uuid().replace(/-/gi, "");
}

function getCallerAccountId(c: Context): string | null {
  try {
    const header = c.req.header("Authorization");
    if (!header) return null;

    const token = header.replace("bearer eg1~", "").replace("Bearer eg1~", "");
    const decoded = jwt.decode(token);

    if (!decoded || typeof decoded === "string") return null;
    return (decoded.sub as string) ?? null;
  } catch {
    return null;
  }
}

function notFound(c: Context, message: string) {
  return c.json(errors.createError(404, c.req.url, message, new Date().toISOString()), 404);
}

function unauthorized(c: Context, message: string) {
  return c.json(errors.createError(403, c.req.url, message, new Date().toISOString()), 403);
}

function base64URLEncode(value: string): string {
  return Buffer.from(value)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

function vxGenerateToken(key: string, payload: object): string {
  const header = base64URLEncode("{}");
  const body = base64URLEncode(JSON.stringify(payload));
  const toSign = `${header}.${body}`;

  const signature = crypto
    .createHmac("sha256", key)
    .update(toSign)
    .digest("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");

  return `${header}.${body}.${signature}`;
}

export default function () {
  app.get(
    "/party/api/v1/Fortnite/user/:accountId/notifications/undelivered/count",
    async (c) => {
      const accountId = c.req.param("accountId");
      const party = Object.values(parties).find(
        (m) => m.members.findIndex((x) => x.account_id === accountId) !== -1,
      );

      return c.json({
        pings: pings.filter((x) => x.sent_to === accountId).length,
        invites: party ? party.invites.filter((p) => p.sent_to === accountId).length : 0,
      });
    },
  );

  app.get("/party/api/v1/Fortnite/user/:accountId", async (c) => {
    const accountId = c.req.param("accountId");
    const current = Object.values(parties).filter(
      (m) => m.members.findIndex((x) => x.account_id === accountId) !== -1,
    );

    return c.json({
      current,
      pending: [],
      invites: [],
      pings: pings.filter((x) => x.sent_to === accountId),
    });
  });

  app.post("/party/api/v1/Fortnite/parties", async (c) => {
    const body = await c.req.json();

    if (!body.join_info || !body.join_info.connection) return c.json({});

    const id = makeId();
    const now = new Date().toISOString();

    const party: Party = {
      id,
      created_at: now,
      updated_at: now,
      config: body.config,
      members: [
        {
          account_id: (body.join_info.connection.id || "").split("@prod")[0],
          meta: body.join_info.meta || {},
          connections: [
            {
              id: body.join_info.connection.id || "",
              connected_at: now,
              updated_at: now,
              yield_leadership: body.join_info.connection.yield_leadership || false,
              meta: body.join_info.connection.meta || {},
            },
          ],
          revision: 0,
          updated_at: now,
          joined_at: now,
          role: "CAPTAIN",
        },
      ],
      applicants: [],
      meta: body.meta || {},
      invites: [],
      revision: 0,
      intentions: [],
    };

    parties[id] = party;
    return c.json(party);
  });

  app.patch("/party/api/v1/Fortnite/parties/:pid", async (c) => {
    const pid = c.req.param("pid");
    const body = await c.req.json();
    const callerId = getCallerAccountId(c);
    const party = parties[pid];

    if (!party) return notFound(c, `Party ${pid} does not exist!`);

    const editingMember = party.members.find((m) => m.account_id === callerId);
    if (editingMember && editingMember.role !== "CAPTAIN")
      return unauthorized(c, `User ${callerId} is not allowed to edit party ${pid}!`);

    if (body.config) {
      for (const prop of Object.keys(body.config)) party.config[prop] = body.config[prop];
    }

    const metaDelete: string[] = body.meta?.delete ?? [];
    const metaUpdate: Record<string, any> = body.meta?.update ?? {};

    for (const prop of metaDelete) delete party.meta[prop];
    for (const prop of Object.keys(metaUpdate)) party.meta[prop] = metaUpdate[prop];

    party.revision = body.revision;

    const captain = party.members.find((member) => member.role === "CAPTAIN");
    party.updated_at = new Date().toISOString();

    party.members.forEach((member) => {
      sendXmppMessageToId(member.account_id, {
        captain_id: captain?.account_id,
        created_at: party.created_at,
        invite_ttl_seconds: 14400,
        max_number_of_members: party.config.max_size,
        ns: "Fortnite",
        party_id: party.id,
        party_privacy_type: party.config.joinability,
        party_state_overriden: {},
        party_state_removed: metaDelete,
        party_state_updated: metaUpdate,
        party_sub_type: party.meta["urn:epic:cfg:party-type-id_s"],
        party_type: "DEFAULT",
        revision: party.revision,
        sent: new Date().toISOString(),
        type: "com.epicgames.social.party.notification.v0.PARTY_UPDATED",
        updated_at: new Date().toISOString(),
      });
    });

    return c.body(null, 204);
  });

  app.patch(
    "/party/api/v1/Fortnite/parties/:pid/members/:accountId/meta",
    async (c) => {
      const pid = c.req.param("pid");
      const accountId = c.req.param("accountId");
      const body = await c.req.json();
      const callerId = getCallerAccountId(c);
      const party = parties[pid];

      if (!party) return notFound(c, `Party ${pid} does not exist!`);

      const mIndex = party.members.findIndex((m) => m.account_id === accountId);
      const member = party.members[mIndex];
      if (!member) return c.body(null, 404);

      if (callerId !== accountId)
        return unauthorized(c, `User ${callerId} is not allowed to edit member ${accountId}!`);

      const deletes: Record<string, any> = body.delete ?? {};
      const updates: Record<string, any> = body.update ?? {};

      for (const prop of Object.keys(deletes)) delete member.meta[prop];
      for (const prop of Object.keys(updates)) member.meta[prop] = updates[prop];

      member.revision = body.revision;
      member.updated_at = new Date().toISOString();
      party.updated_at = new Date().toISOString();

      party.members.forEach((member2) => {
        sendXmppMessageToId(member2.account_id, {
          account_id: accountId,
          account_dn: member.meta["urn:epic:member:dn_s"],
          member_state_updated: updates,
          member_state_removed: deletes,
          member_state_overridden: {},
          party_id: party.id,
          updated_at: new Date().toISOString(),
          sent: new Date().toISOString(),
          revision: member.revision,
          ns: "Fortnite",
          type: "com.epicgames.social.party.notification.v0.MEMBER_STATE_UPDATED",
        });
      });

      return c.body(null, 204);
    },
  );

  app.get("/party/api/v1/Fortnite/parties/:pid", async (c) => {
    const pid = c.req.param("pid");
    const party = parties[pid];

    if (!party) return notFound(c, `Party ${pid} does not exist!`);
    return c.json(party);
  });

  app.delete(
    "/party/api/v1/Fortnite/parties/:pid/members/:accountId",
    async (c) => {
      const pid = c.req.param("pid");
      const accountId = c.req.param("accountId");
      const callerId = getCallerAccountId(c);
      const party = parties[pid];

      if (!party) return notFound(c, `Party ${pid} does not exist!`);

      const mIndex = party.members.findIndex((m) => m.account_id === accountId);
      const member = party.members[mIndex];

      if (callerId !== accountId && member && member.role !== "CAPTAIN")
        return unauthorized(c, `User ${callerId} is not allowed to delete member ${accountId}!`);

      party.members.forEach((m) => {
        sendXmppMessageToId(m.account_id, {
          account_id: accountId,
          member_state_update: {},
          ns: "Fortnite",
          party_id: party.id,
          revision: party.revision || 0,
          sent: new Date().toISOString(),
          type: "com.epicgames.social.party.notification.v0.MEMBER_LEFT",
        });
      });

      if (mIndex !== -1) party.members.splice(mIndex, 1);

      if (party.members.length === 0) {
        delete parties[pid];
        return c.body(null, 204);
      }

      const key = party.meta["Default:RawSquadAssignments_j"]
        ? "Default:RawSquadAssignments_j"
        : "RawSquadAssignments_j";

      if (party.meta[key]) {
        const rsa = JSON.parse(party.meta[key]);
        const idx = rsa.RawSquadAssignments.findIndex(
          (a: any) => a.memberId === accountId,
        );
        if (idx !== -1) rsa.RawSquadAssignments.splice(idx, 1);
        party.meta[key] = JSON.stringify(rsa);

        let captain = party.members.find((m) => m.role === "CAPTAIN");
        if (!captain) {
          party.members[0].role = "CAPTAIN";
          captain = party.members[0];
        }

        party.updated_at = new Date().toISOString();

        party.members.forEach((m) => {
          sendXmppMessageToId(m.account_id, {
            captain_id: captain?.account_id,
            created_at: party.created_at,
            invite_ttl_seconds: 14400,
            max_number_of_members: 16,
            ns: "Fortnite",
            party_id: party.id,
            party_privacy_type: party.config.joinability,
            party_state_overriden: {},
            party_state_removed: [],
            party_state_updated: { [key]: JSON.stringify(rsa) },
            party_sub_type: party.meta["urn:epic:cfg:party-type-id_s"],
            party_type: "DEFAULT",
            revision: party.revision,
            sent: new Date().toISOString(),
            type: "com.epicgames.social.party.notification.v0.PARTY_UPDATED",
            updated_at: new Date().toISOString(),
          });
        });
      }

      return c.body(null, 204);
    },
  );

  const joinParty = async (c: Context, party: Party, accountId: string) => {
    const body = await c.req.json();

    const existingIndex = party.members.findIndex((m) => m.account_id === accountId);
    if (existingIndex !== -1) return c.json({ status: "JOINED", party_id: party.id });

    const now = new Date().toISOString();
    const member: PartyMember = {
      account_id: (body.connection.id || "").split("@prod")[0],
      meta: body.meta || {},
      connections: [
        {
          id: body.connection.id || "",
          connected_at: now,
          updated_at: now,
          yield_leadership: body.connection.yield_leadership ? true : false,
          meta: body.connection.meta || {},
        },
      ],
      revision: 0,
      updated_at: now,
      joined_at: now,
      role: body.connection.yield_leadership ? "CAPTAIN" : "MEMBER",
    };

    party.members.push(member);

    const key = party.meta["Default:RawSquadAssignments_j"]
      ? "Default:RawSquadAssignments_j"
      : "RawSquadAssignments_j";

    let rsa: any;
    if (party.meta[key]) {
      rsa = JSON.parse(party.meta[key]);
      rsa.RawSquadAssignments.push({
        memberId: (body.connection.id || "").split("@prod")[0],
        absoluteMemberIdx: party.members.length - 1,
      });
      party.meta[key] = JSON.stringify(rsa);
      party.revision++;
    }

    party.updated_at = new Date().toISOString();

    const captain = party.members.find((m) => m.role === "CAPTAIN") || {
      account_id: "",
    };

    party.members.forEach((m) => {
      sendXmppMessageToId(m.account_id, {
        account_dn: body.connection.meta["urn:epic:member:dn_s"],
        account_id: (body.connection.id || "").split("@prod")[0],
        connection: {
          connected_at: new Date().toISOString(),
          id: body.connection.id,
          meta: body.connection.meta,
          updated_at: new Date().toISOString(),
        },
        joined_at: new Date().toISOString(),
        member_state_updated: body.meta || {},
        ns: "Fortnite",
        party_id: party.id,
        revision: 0,
        sent: new Date().toISOString(),
        type: "com.epicgames.social.party.notification.v0.MEMBER_JOINED",
        updated_at: new Date().toISOString(),
      });

      sendXmppMessageToId(m.account_id, {
        captain_id: captain.account_id,
        created_at: party.created_at,
        invite_ttl_seconds: 14400,
        max_number_of_members: party.config.max_size,
        ns: "Fortnite",
        party_id: party.id,
        party_privacy_type: party.config.joinability,
        party_state_overriden: {},
        party_state_removed: [],
        party_state_updated: rsa ? { [key]: JSON.stringify(rsa) } : {},
        party_sub_type: party.meta["urn:epic:cfg:party-type-id_s"],
        party_type: "DEFAULT",
        revision: party.revision,
        sent: new Date().toISOString(),
        type: "com.epicgames.social.party.notification.v0.PARTY_UPDATED",
        updated_at: new Date().toISOString(),
      });
    });

    return c.json({ status: "JOINED", party_id: party.id });
  };

  app.post(
    "/party/api/v1/Fortnite/parties/:pid/members/:accountId/join",
    async (c) => {
      const pid = c.req.param("pid");
      const accountId = c.req.param("accountId");
      const party = parties[pid];

      if (!party) return notFound(c, `Party ${pid} does not exist!`);
      return joinParty(c, party, accountId);
    },
  );

  app.post(
    "/party/api/v1/Fortnite/parties/:pid/members/:accountId/promote",
    async (c) => {
      const pid = c.req.param("pid");
      const accountId = c.req.param("accountId");
      const callerId = getCallerAccountId(c);
      const party = parties[pid];

      if (!party) return notFound(c, `Party ${pid} does not exist!`);

      const captainIndex = party.members.findIndex((m) => m.role === "CAPTAIN");
      if (party.members[captainIndex].account_id !== callerId)
        return unauthorized(c, `User ${callerId} is not allowed to promote member ${accountId}!`);

      const newCaptainIndex = party.members.findIndex((m) => m.account_id === accountId);
      if (captainIndex !== -1) party.members[captainIndex].role = "MEMBER";
      if (newCaptainIndex !== -1) party.members[newCaptainIndex].role = "CAPTAIN";

      party.updated_at = new Date().toISOString();

      party.members.forEach((member) => {
        sendXmppMessageToId(member.account_id, {
          account_id: accountId,
          member_state_update: {},
          ns: "Fortnite",
          party_id: party.id,
          revision: party.revision || 0,
          sent: new Date().toISOString(),
          type: "com.epicgames.social.party.notification.v0.MEMBER_NEW_CAPTAIN",
        });
      });

      return c.body(null, 204);
    },
  );

  app.post(
    "/party/api/v1/Fortnite/user/:accountId/pings/:pingerId",
    async (c) => {
      const accountId = c.req.param("accountId");
      const pingerId = c.req.param("pingerId");
      const body = await c.req.json();
      const uahelper = uaparser(c.req.header("User-Agent"));

      const existing = pings
        .filter((p) => p.sent_to === accountId)
        .findIndex((p) => p.sent_by === pingerId);
      if (existing !== -1) pings.splice(existing, 1);

      const expires = new Date();
      expires.setHours(expires.getHours() + 1);

      const ping: PartyPing = {
        sent_by: pingerId,
        sent_to: accountId,
        sent_at: new Date().toISOString(),
        expires_at: expires.toISOString(),
        meta: body.meta,
      };
      pings.push(ping);

      const pinger = await userService.findUserByAccountId(pingerId);

      sendXmppMessageToId(accountId, {
        expires: ping.expires_at,
        meta: body.meta,
        ns: "Fortnite",
        pinger_dn: pinger?.username,
        pinger_id: pingerId,
        sent: ping.sent_at,
        version: String(uahelper?.build ?? 0).padEnd(5, "0"),
        type: "com.epicgames.social.party.notification.v0.PING",
      });

      return c.json(ping);
    },
  );

  app.delete(
    "/party/api/v1/Fortnite/user/:accountId/pings/:pingerId",
    async (c) => {
      const accountId = c.req.param("accountId");
      const pingerId = c.req.param("pingerId");

      const index = pings
        .filter((p) => p.sent_to === accountId)
        .findIndex((p) => p.sent_by === pingerId);
      if (index !== -1) pings.splice(index, 1);

      return c.body(null, 204);
    },
  );

  app.get(
    "/party/api/v1/Fortnite/user/:accountId/pings/:pingerId/parties",
    async (c) => {
      const accountId = c.req.param("accountId");
      const pingerId = c.req.param("pingerId");

      let query: { sent_by: string }[] = pings.filter(
        (p) => p.sent_to === accountId && p.sent_by === pingerId,
      );
      if (query.length === 0) query = [{ sent_by: pingerId }];

      const result = query
        .map((y) => {
          const party = Object.values(parties).find(
            (x) => x.members.findIndex((m) => m.account_id === y.sent_by) !== -1,
          );
          if (!party) return null;
          return {
            id: party.id,
            created_at: party.created_at,
            updated_at: party.updated_at,
            config: party.config,
            members: party.members,
            applicants: [],
            meta: party.meta,
            invites: [],
            revision: party.revision || 0,
          };
        })
        .filter((x) => x !== null);

      return c.json(result);
    },
  );

  app.post(
    "/party/api/v1/Fortnite/user/:accountId/pings/:pingerId/join",
    async (c) => {
      const accountId = c.req.param("accountId");
      const pingerId = c.req.param("pingerId");

      let query: { sent_by: string }[] = pings.filter(
        (p) => p.sent_to === accountId && p.sent_by === pingerId,
      );
      if (query.length === 0) query = [{ sent_by: pingerId }];

      const party = Object.values(parties).find(
        (p) => p.members.findIndex((m) => m.account_id === query[0].sent_by) !== -1,
      );
      if (!party) return notFound(c, "Party does not exist!");

      return joinParty(c, party, accountId);
    },
  );

  app.post(
    "/party/api/v1/Fortnite/parties/:pid/invites/:accountId",
    async (c) => {
      const pid = c.req.param("pid");
      const accountId = c.req.param("accountId");
      const callerId = getCallerAccountId(c);
      const body = await c.req.json();
      const uahelper = uaparser(c.req.header("User-Agent"));
      const party = parties[pid];

      if (!party) return notFound(c, `Party ${pid} does not exist!`);

      const existing = party.invites
        .filter((p) => p.sent_to === accountId)
        .findIndex((p) => p.sent_by === callerId);
      if (existing !== -1) party.invites.splice(existing, 1);

      const expires = new Date();
      expires.setHours(expires.getHours() + 1);

      const invite: PartyInvite = {
        party_id: party.id,
        sent_by: callerId ?? "",
        meta: body,
        sent_to: accountId,
        sent_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        expires_at: expires.toISOString(),
        status: "SENT",
      };

      party.invites.push(invite);
      party.updated_at = new Date().toISOString();

      const friends = await friendsService.findFriendByAccountId(callerId ?? "");
      const accepted = friends?.accepted ?? [];
      const inviter = party.members.find((x) => x.account_id === callerId);

      sendXmppMessageToId(accountId, {
        expires: invite.expires_at,
        meta: body,
        ns: "Fortnite",
        party_id: party.id,
        inviter_dn: inviter?.meta["urn:epic:member:dn_s"],
        inviter_id: callerId,
        invitee_id: accountId,
        members_count: party.members.length,
        sent_at: invite.sent_at,
        updated_at: invite.updated_at,
        friends_ids: party.members
          .filter((m) => accepted.find((f) => f.accountId === m.account_id))
          .map((m) => m.account_id),
        sent: new Date().toISOString(),
        type: "com.epicgames.social.party.notification.v0.INITIAL_INVITE",
      });

      if (c.req.query("sendPing") === "true") {
        const existingPing = pings
          .filter((p) => p.sent_to === accountId)
          .findIndex((p) => p.sent_by === callerId);
        if (existingPing !== -1) pings.splice(existingPing, 1);

        const pingExpires = new Date();
        pingExpires.setHours(pingExpires.getHours() + 1);

        pings.push({
          sent_by: callerId ?? "",
          sent_to: accountId,
          sent_at: new Date().toISOString(),
          expires_at: pingExpires.toISOString(),
          meta: body,
        });

        sendXmppMessageToId(accountId, {
          expires: invite.expires_at,
          meta: body.meta,
          ns: "Fortnite",
          pinger_dn: inviter?.meta["urn:epic:member:dn_s"],
          pinger_id: callerId,
          sent: invite.sent_at,
          version: String(uahelper?.build ?? 0).padEnd(5, "0"),
          type: "com.epicgames.social.party.notification.v0.PING",
        });
      }

      return c.body(null, 204);
    },
  );

  const declineInvite = async (c: Context) => {
    const pid = c.req.param("pid");
    const accountId = c.req.param("accountId");
    const body = await c.req.json().catch(() => ({}));
    const party = parties[pid];

    if (!party) return notFound(c, `Party ${pid} does not exist!`);

    const invite = party.invites.find((p) => p.sent_to === accountId);
    if (!invite) return notFound(c, `Invite ${pid} does not exist!`);

    const inviter = party.members.find((x) => x.account_id === invite.sent_by);

    if (inviter)
      sendXmppMessageToId(invite.sent_by, {
        expires: invite.expires_at,
        meta: body,
        ns: "Fortnite",
        party_id: party.id,
        inviter_dn: inviter.meta["urn:epic:member:dn_s"],
        inviter_id: invite.sent_by,
        invitee_id: accountId,
        sent_at: invite.sent_at,
        updated_at: invite.updated_at,
        sent: new Date().toISOString(),
        type: "com.epicgames.social.party.notification.v0.INVITE_CANCELLED",
      });

    return c.body(null, 204);
  };

  app.post("/party/api/v1/Fortnite/parties/:pid/invites/:accountId/decline", declineInvite);
  app.post(
    "/party/api/v1/Fortnite/parties/:pid/invites/:accountId/:source/decline",
    declineInvite,
  );

  app.post(
    "/party/api/v1/Fortnite/members/:accountId/intentions/:senderId",
    async (c) => {
      const accountId = c.req.param("accountId");
      const senderId = c.req.param("senderId");
      const body = await c.req.json();

      const party = Object.values(parties).find(
        (x) => x.members.findIndex((m) => m.account_id === senderId) !== -1,
      );
      if (!party) return notFound(c, "Party does not exist!");

      const sender = party.members.find((x) => x.account_id === senderId);
      const captain = party.members.find((member) => member.role === "CAPTAIN");
      const friends = await friendsService.findFriendByAccountId(accountId);
      const accepted = friends?.accepted ?? [];

      const expires = new Date();
      expires.setHours(expires.getHours() + 1);

      const intention: PartyIntention = {
        requester_id: senderId,
        requester_dn: sender?.meta["urn:epic:member:dn_s"],
        requester_pl: captain?.account_id ?? "",
        requester_pl_dn: captain?.meta["urn:epic:member:dn_s"],
        requestee_id: accountId,
        meta: body,
        expires_at: expires.toISOString(),
        sent_at: new Date().toISOString(),
      };

      party.intentions.push(intention);

      sendXmppMessageToId(accountId, {
        expires_at: intention.expires_at,
        requester_id: senderId,
        requester_dn: sender?.meta["urn:epic:member:dn_s"],
        requester_pl: captain?.account_id,
        requester_pl_dn: captain?.meta["urn:epic:member:dn_s"],
        requestee_id: accountId,
        meta: body,
        sent_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        friends_ids: party.members
          .filter((m) => accepted.find((f) => f.accountId === m.account_id))
          .map((m) => m.account_id),
        members_count: party.members.length,
        party_id: party.id,
        ns: "Fortnite",
        sent: new Date().toISOString(),
        type: "com.epicgames.social.party.notification.v0.INITIAL_INTENTION",
      });

      return c.json(intention);
    },
  );

  app.post(
    "/party/api/v1/Fortnite/parties/:pid/members/:accountId/conferences/connection",
    async (c) => {
      const pid = c.req.param("pid");
      const accountId = c.req.param("accountId");
      const body = await c.req.json();

      let { vivox, rtcp } = body.providers;

      if (rtcp) {
        if (!lastClient || new Date(lastClient.expires_at).getTime() <= Date.now()) {
          const response = await axios.post(
            "https://api.epicgames.dev/auth/v1/oauth/token",
            "grant_type=client_credentials&deployment_id=8949d22a1748462abe3e938fd7e19e5c",
            {
              headers: { "Content-Type": "application/x-www-form-urlencoded" },
              auth: {
                username: "xyza7891InagL5qaPE6DzJBNn14sBWgF",
                password: "NvJM0I6mKNEMCnn89DtEJTiZRfWW6YsAZjicl6IVols",
              },
            },
          );

          lastClient = response.data;
        }

        if (!vcParticipants[pid]) vcParticipants[pid] = [];

        const participant: VoiceParticipant = {
          puid: accountId,
          clientIP: c.req.header("x-forwarded-for") ?? "",
          hardMuted: false,
        };
        if (!vcParticipants[pid].find((m) => m.puid === participant.puid))
          vcParticipants[pid].push(participant);

        const toProperCase = (s: string) => s.split("")[0].toUpperCase() + s.slice(1);

        const room = await axios.post(
          `https://api.epicgames.dev/rtc/v1/8949d22a1748462abe3e938fd7e19e5c/room/${pid}`,
          { participants: vcParticipants[pid] },
          {
            headers: {
              authorization:
                toProperCase(lastClient!.token_type) + " " + lastClient!.access_token,
            },
          },
        );

        const joinToken = room.data;
        const tokenMap: Record<string, string> = {};
        for (const part of joinToken.participants) tokenMap[part.puid] = part.token;

        vcInfo[pid] = {
          name: joinToken.roomId,
          url: joinToken.clientBaseUrl,
          tokens: tokenMap,
        };

        rtcp = {
          participant_token: vcInfo[pid].tokens[accountId],
          client_base_url: vcInfo[pid].url,
          room_name: vcInfo[pid].name,
        };
      } else {
        const channelUri = `sip:confctl-g-epicgames.p-${pid}@mtu1xp.vivox.com`;
        const userUri = `sip:.epicgames.${accountId}.@mtu1xp.vivox.com`;

        const vivoxClaims = {
          iss: "epicgames",
          sub: accountId,
          exp: Math.floor((Date.now() + 2 * 60 * 60 * 1000) / 1000),
          vxa: "join",
          f: userUri,
          t: channelUri,
        };

        const token = vxGenerateToken("zcETsPpEAysznTyDXK4TEzwLQPcTvTAO", vivoxClaims);

        vivox = {
          authorization_token: token,
          channel_uri: channelUri,
          user_uri: userUri,
        };
      }

      return c.json({ providers: { rtcp, vivox } });
    },
  );
}
