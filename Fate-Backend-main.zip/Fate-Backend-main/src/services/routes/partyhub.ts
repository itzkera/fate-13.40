import { app, config, friendsService, userService } from "../..";
import errors from "../../utilities/errors";
import jwt, { type JwtPayload } from "jsonwebtoken";

function extractOperationName(body: any): string | null {
  if (body?.operationName) return body.operationName;
  if (body?.query) {
    const match = body.query.match(/(?:query|mutation|subscription)\s+(\w+)/);
    if (match) return match[1];
  }
  return null;
}

export default function () {
  app.all("/partyhub/graphql", async (c) => {
    const authorization = c.req.header("Authorization") ?? "";

    if (!authorization.toLowerCase().startsWith("bearer eg1~")) {
      return c.json(
        errors.createError(401, c.req.url, "Authentication required.", new Date().toISOString()),
        401,
      );
    }

    const rawToken = authorization.slice("bearer eg1~".length);
    let accountId: string | null = null;
    try {
      const decoded = jwt.verify(rawToken, config.client_secret) as JwtPayload;
      accountId = decoded.sub ?? null;
    } catch {
      return c.json(
        errors.createError(401, c.req.url, "Invalid token.", new Date().toISOString()),
        401,
      );
    }

    const user = await userService.findUserByAccountId(accountId!);
    if (!user) {
      return c.json(
        errors.createError(404, c.req.url, "Account not found.", new Date().toISOString()),
        404,
      );
    }

    let body: any = {};
    const contentType = c.req.header("content-type") ?? "";
    if (contentType.includes("application/json")) {
      body = await c.req.json().catch(() => ({}));
    }

    const operationName = extractOperationName(body);

    switch (operationName) {
      case "GetMyAccount":
        return c.json({
          data: {
            Fortnite: {
              __typename: "FortniteMutation",
              myProfile: {
                __typename: "FortProfile",
                id: user.accountId,
              },
            },
            Account: {
              __typename: "AccountQuery",
              myAccount: {
                __typename: "Account",
                id: user.accountId,
                displayName: user.username,
                email: user.email,
                country: "EU",
                externalAuths: [
                  {
                    __typename: "ExternalAuth",
                    type: "epic",
                    externalDisplayName: user.username,
                  },
                ],
              },
            },
          },
        });

      case "EulaAccepted":
        return c.json({
          data: {
            Eula: {
              __typename: "EulaQuery",
              hasAccountAccepted: {
                __typename: "Eula",
                accepted: true,
              },
            },
          },
        });

      case "GetStatusPerService":
        return c.json({
          data: {
            LightSwitch: {
              __typename: "LightSwitchQuery",
              fortniteStatus: {
                __typename: "LightSwitchServiceStatus",
                status: "UP",
                banned: false,
              },
              kairosStatus: {
                __typename: "LightSwitchServiceStatus",
                status: "DOWN",
              },
            },
            SocialBan: {
              __typename: "SocialBanQuery",
              summary: {
                __typename: "SocialBanSummary",
                bans: [],
              },
            },
            ContentControl: {
              __typename: "ContentControlQuery",
              namespace: {
                __typename: "ContentControlNamespace",
                result: {
                  __typename: "ContentControlRules",
                  canUseVoiceChat: true,
                },
              },
            },
          },
          extensions: {},
        });

      case "UpdateUserSetting":
      case "SetPrivacySetting":
      case "UpdatePrivacySetting":
        return c.json({
          data: {
            UserSettings: {
              __typename: "UserSettingsMutation",
              updateSetting: {
                __typename: "UserSettingMutationStatus",
                success: true,
              },
            },
          },
        });

      case "GetPrivacySetting":
      case "GetPrivacySettings": {
        return c.json({
          data: {
            PrivacySettings: {
              __typename: "PrivacySettingsQuery",
              privacy: {
                __typename: "PrivacySettings",
                optOutOfPublicLeaderboards: false,
              },
            },
          },
        });
      }

      case "GetBlockedUsers": {
        const friendsRecord = await friendsService.findFriendByAccountId(user.accountId).catch(() => null);
        const blocked = (friendsRecord?.blocked ?? []).map((f) => ({
          __typename: "BlockedUser",
          accountId: f.accountId,
        }));

        return c.json({
          data: {
            Friends: {
              __typename: "FriendsQuery",
              blocklist: {
                __typename: "BlockedUserList",
                blockedUsers: blocked,
              },
            },
          },
        });
      }

      case "GetFriends":
      case "GetFriendsV2": {
        const friendsRecord = await friendsService.findFriendByAccountId(user.accountId).catch(() => null);
        const accepted = (friendsRecord?.accepted ?? []).map((f) => ({
          __typename: "Friend",
          accountId: f.accountId,
          alias: f.alias ?? "",
          note: "",
          favorite: false,
        }));

        return c.json({
          data: {
            Friends: {
              __typename: "FriendsQuery",
              friends: {
                __typename: "FriendsList",
                friends: accepted,
              },
            },
          },
        });
      }

      case "GetIncomingFriendRequests": {
        const friendsRecord = await friendsService.findFriendByAccountId(user.accountId).catch(() => null);
        const incoming = (friendsRecord?.incoming ?? []).map((f) => ({
          __typename: "FriendRequest",
          accountId: f.accountId,
          favorite: false,
        }));

        return c.json({
          data: {
            Friends: {
              __typename: "FriendsQuery",
              incomingFriendRequests: {
                __typename: "FriendRequestList",
                friendRequests: incoming,
              },
            },
          },
        });
      }

      case "GetOutgoingFriendRequests": {
        const friendsRecord = await friendsService.findFriendByAccountId(user.accountId).catch(() => null);
        const outgoing = (friendsRecord?.outgoing ?? []).map((f) => ({
          __typename: "FriendRequest",
          accountId: f.accountId,
          favorite: false,
        }));

        return c.json({
          data: {
            Friends: {
              __typename: "FriendsQuery",
              outgoingFriendRequests: {
                __typename: "FriendRequestList",
                friendRequests: outgoing,
              },
            },
          },
        });
      }

      case "GetFriendRequests":
      case "GetFriendRequestsV2": {
        const friendsRecord = await friendsService.findFriendByAccountId(user.accountId).catch(() => null);
        const incoming = (friendsRecord?.incoming ?? []).map((f) => ({
          __typename: "FriendRequest",
          accountId: f.accountId,
          favorite: false,
        }));
        const outgoing = (friendsRecord?.outgoing ?? []).map((f) => ({
          __typename: "FriendRequest",
          accountId: f.accountId,
          favorite: false,
        }));

        return c.json({
          data: {
            Friends: {
              __typename: "FriendsQuery",
              incomingFriendRequests: {
                __typename: "FriendRequestList",
                friendRequests: incoming,
              },
              outgoingFriendRequests: {
                __typename: "FriendRequestList",
                friendRequests: outgoing,
              },
            },
          },
        });
      }

      case "SendFriendRequest":
      case "AcceptFriendRequest": {
        const friendId = getFriendId(body.variables, user.accountId);
        if (!friendId)
          return c.json({ errors: [{ message: "Missing friend account ID." }] }, 400);
        try {
          await friendsService.addOrAccept(user.accountId, friendId);
        } catch {
          return c.json({ errors: [{ message: "Unable to update friendship." }] }, 400);
        }
        return c.json({
          data: {
            Friends: {
              __typename: "FriendsMutation",
              success: true,
            },
          },
        });
      }

      case "DeclineFriendRequest":
      case "RemoveFriend": {
        const friendId = getFriendId(body.variables, user.accountId);
        if (!friendId)
          return c.json({ errors: [{ message: "Missing friend account ID." }] }, 400);
        try {
          await friendsService.remove(user.accountId, friendId);
        } catch {
          return c.json({ errors: [{ message: "Unable to update friendship." }] }, 400);
        }
        return c.json({
          data: {
            Friends: {
              __typename: "FriendsMutation",
              success: true,
            },
          },
        });
      }

      case "GetPartyInvitations":
        return c.json({
          data: {
            Party: {
              __typename: "PartyQuery",
              invitations: [],
            },
          },
        });

      case "GetRecentPlayers":
        return c.json({
          data: {
            Friends: {
              __typename: "FriendsQuery",
              recentPlayers: {
                __typename: "RecentPlayerList",
                players: [],
              },
            },
          },
        });

      case "getMySocialBanSummary":
        return c.json({
          data: {
            SocialBan: {
              __typename: "SocialBanQuery",
              summary: {
                __typename: "SocialBanSummary",
                warnings: [],
                bans: [],
              },
            },
          },
        });

      default:
        return c.json(
          errors.createError(400, c.req.url, `Unknown operation: ${operationName}`, new Date().toISOString()),
          400,
        );
    }
  });
}

function getFriendId(variables: any, ownAccountId: string): string | null {
  const candidates = [
    variables?.friendId,
    variables?.friendAccountId,
    variables?.targetAccountId,
    variables?.accountId,
    variables?.input?.friendId,
    variables?.input?.accountId,
  ];
  return candidates.find((value) => typeof value === "string" && value !== ownAccountId) ?? null;
}
