import { app, config, itemStorageService, userService } from "../..";
import axios from "axios";
import uaparser from "../../utilities/uaparser";
import errors from "../../utilities/errors";
import { ShopGenerator } from "../../modules/shop/shop";
import { ShopHelper } from "../../modules/shop/helpers/shophelper";

export default function () {
  app.get("/fortnite/api/storefront/v2/keychain", async (c) => {
    return c.json(require("../../memory/keychain.json"));
  });

  app.get("/fortnite/api/storefront/v2/catalog", async (c) => {
    const timestamp = new Date().toISOString();
    const useragent = c.req.header("User-Agent");

    if (!useragent)
      return c.json(
        errors.createError(400, c.req.url, "header 'User-Agent' is missing.", timestamp),
        400,
      );

    const uahelper = uaparser(useragent);

    if (!uahelper)
      return c.json(
        errors.createError(400, c.req.url, "Failed to parse User-Agent.", timestamp),
        400,
      );

    if (uahelper.season === 0) return c.json({});
    if (uahelper.season >= 26) return c.json(require("../../memory/aaa.json"));
    const [storefrontData] = await Promise.all([itemStorageService.getItemByType("storefront")]);

    if (!storefrontData)
      return c.json(
        errors.createError(400, c.req.url, "Failed to get current storefront.", timestamp),
        400,
      );

    return c.json(storefrontData.data);
  });

  app.get("/catalog/api/shared/bulk/offers", async (c) => {
    return c.json([]);
  });

  app.get(
    "/fortnite/api/storefront/v2/gift/check_eligibility/recipient/:friendId/offer/:offerId",
    async (c) => {
      return c.json({
        eligible: true,
        reason: "",
      });
    },
  );
}
