import { z } from "zod";
import { app, config, logger, profilesService, userService } from "../..";
import errors from "../../utilities/errors";
import { handleProfileSelection } from "../../utilities/profile_cache";
import type { Lootlist } from "../../../types/profilesdefs";

export default function () {
  app.post("/gamesessions/stats/operations/ApplyMatchStats/:accountId", async (c) => {
    const timestamp = new Date().toISOString();

    const adminKey = c.req.header("x-admin-key");
    if (!config.admin_key || adminKey !== config.admin_key)
      return c.json(errors.createError(401, c.req.url, "Unauthorized.", timestamp), 401);

    const accountId = c.req.param("accountId");

    try {
      const [user] = await Promise.all([userService.findUserByAccountId(accountId)]);

      if (!user) {
        return c.json(errors.createError(404, c.req.url, "User not found!", timestamp), 404);
      }

      const [common_core, athena] = await Promise.all([
        handleProfileSelection("common_core", user.accountId),
        handleProfileSelection("athena", user.accountId),
      ]);

      if (!common_core || !athena) {
        return c.json(errors.createError(404, c.req.url, "Profile not found!", timestamp), 404);
      }

      let changes: object[] = [];

      const { eliminations, isVictory } = await c.req.json();

      const lootList: Lootlist[] = [];

      let currency = eliminations * 50;
      if (isVictory) {
        currency += 200;
      }

      for (const pastSeason of athena.stats.attributes!.past_seasons!) {
        if (pastSeason.seasonNumber === config.currentSeason) {
          pastSeason.numWins += isVictory ? 1 : 0;

          lootList.push({
            itemType: "Currency:MtxPurchased",
            itemGuid: "Currency:MtxPurchased",
            itemProfile: "common_core",
            quantity: currency,
          });

          changes.push({
            itemType: "Currency:MtxPurchased",
            itemGuid: "Currency:MtxPurchased",
            quantity: currency,
          });

          common_core.items["GiftBox:GB_MakeGood"] = {
            templateId: "GiftBox:GB_MakeGood",
            attributes: {
              max_level_bonus: 0,
              fromAccountId: "Server",
              lootList,
            },
            quantity: 1,
          };

          common_core.items["Currency:MtxPurchased"].quantity += currency;
          changes.push({ amountGained: currency });
          break;
        }
      }

      await profilesService.updateMultiple([
        { accountId: user.accountId, type: "athena", data: athena },
        { accountId: user.accountId, type: "common_core", data: common_core },
      ]);

      return c.json({});
    } catch (error) {
      logger.error(`Error applying match stats: ${error}`);
      return c.json(errors.createError(500, c.req.url, "Internal server error.", timestamp), 500);
    }
  });
}
