import { app, friendsService, logger, tokensService, userService } from "../..";
import errors from "../../utilities/errors";

export default function () {
  app.post("/xmpp/api/auth", async (c) => {
    const body = await c.req.json();

    const timestamp = new Date().toISOString();
    const { username, password } = body;

    if (!username || !password) {
      return c.json(
        errors.createError(400, c.req.url, "Username and password are required.", timestamp),
        400,
      );
    }

    const user = await userService.findUserByAccountId(username);
    if (!user) {
      return c.json(errors.createError(401, c.req.url, "User not found.", timestamp), 401);
    }

    const accessToken = await tokensService.getToken(password.replace("eg1~", ""));
    if (!accessToken || accessToken.accountId !== user.accountId) {
      logger.error(`XMPP Auth failed for user ${username}: Invalid token.`);
      return c.json(errors.createError(401, c.req.url, "Invalid token.", timestamp), 401);
    }

    return c.json({
      success: true,
      accountId: user.accountId,
      username: user.username,
    });
  });

  app.get("/xmpp/api/friends/:accountId", async (c) => {
    const accountId = c.req.param("accountId");
    const timestamp = new Date().toISOString();
    const user = await userService.findUserByAccountId(accountId);

    if (!user) {
      return c.json(errors.createError(404, c.req.url, "User not found.", timestamp), 404);
    }

    const friends = await friendsService.findFriendByAccountId(accountId);
    if (!friends) {
      return c.json(errors.createError(404, c.req.url, "Friends list not found.", timestamp), 404);
    }

    return c.json({
      friends: friends.accepted.map((f) => f.accountId),
    });
  });
}
