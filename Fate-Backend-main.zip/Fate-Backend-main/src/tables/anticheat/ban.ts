import { BaseEntity, Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity("bans")
export class Ban extends BaseEntity {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "varchar", length: 64, nullable: false })
  accountId!: string;

  @Column({ type: "varchar", length: 255, nullable: true })
  reason?: string;

  @Column("boolean", { default: false })
  isShadowBanned!: boolean;

  @Column({ type: "varchar", length: 255, nullable: true })
  shadowBanReason?: string;

  @Column({ type: "timestamptz", nullable: true })
  shadowBanStart?: Date;

  @Column({ type: "timestamptz", nullable: true })
  shadowBanEnd?: Date;

  @Column("boolean", { default: false })
  isRecentlyUnbanned!: boolean;

  @Column({ type: "timestamptz", nullable: true })
  unbannedAt?: Date;
}
