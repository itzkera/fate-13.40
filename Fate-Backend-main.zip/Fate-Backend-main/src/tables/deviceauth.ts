import { BaseEntity, Column, Entity, PrimaryGeneratedColumn } from "typeorm";

export interface DeviceAuthAccess {
  location: string;
  ipAddress: string;
  dateTime: string;
}

@Entity()
export class DeviceAuth extends BaseEntity {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ unique: true })
  deviceId!: string;

  @Column()
  accountId!: string;

  @Column()
  secret!: string;

  @Column({ default: "" })
  userAgent!: string;

  @Column("jsonb")
  created!: DeviceAuthAccess;

  @Column("jsonb", { nullable: true, default: null })
  lastAccess!: DeviceAuthAccess | null;
}
