import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity({ name: "matchmaking" })
export class Matchmaking {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "varchar", length: 255 })
  key!: string;

  @Column({ type: "varchar", length: 255 })
  address!: string;

  @Column({ type: "int" })
  port!: number;
}
