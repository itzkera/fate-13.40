import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
  BeforeUpdate,
} from "typeorm";

@Entity("clients")
@Index(["playerId"])
@Index(["socketId"])
@Index(["sessionId"])
export class Client {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "varchar", unique: true })
  playerId!: string;

  @Column({ type: "varchar" })
  accountId!: string;

  @Column({ type: "varchar", unique: true })
  socketId!: string;

  @Column({ type: "varchar" })
  playlist!: string;

  @Column({ type: "varchar" })
  region!: string;

  @Column({ type: "int", default: 1 })
  season!: number;

  @Column({ type: "varchar", default: "none" })
  customKey!: string;

  @Column({ type: "varchar" })
  ticketId!: string;

  @Column({ type: "varchar" })
  matchId!: string;

  @Column({ type: "varchar" })
  sessionId!: string;

  @Column({ type: "timestamp", default: () => "CURRENT_TIMESTAMP" })
  connectedAt!: Date;

  @Column({ type: "timestamp", default: () => "CURRENT_TIMESTAMP" })
  lastActivity!: Date;

  @CreateDateColumn()
  createdAt!: Date;

  @UpdateDateColumn()
  updatedAt!: Date;
}
