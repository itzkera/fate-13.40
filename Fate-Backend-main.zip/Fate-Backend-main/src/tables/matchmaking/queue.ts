import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";

export enum QueueStatus {
  CONNECTING = "connecting",
  WAITING = "waiting",
  QUEUED = "queued",
  SESSIONASSIGNMENT = "sessionassignment",
  PLAYING = "playing",
}

@Entity("queues")
@Index(["playerId"])
@Index(["accountId"])
@Index(["playlist"])
@Index(["region"])
@Index(["customKey"])
@Index(["joinedAt"])
@Index(["status"])
@Index(["playlist", "region", "customKey", "season", "status"])
export class Queue {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "varchar", unique: true })
  playerId!: string;

  @Column({ type: "varchar" })
  accountId!: string;

  @Column({ type: "varchar" })
  playlist!: string;

  @Column({ type: "varchar" })
  region!: string;

  @Column({ type: "int", default: 1 })
  season!: number;

  @Column({ type: "varchar", default: "none" })
  customKey!: string;

  @Column({ type: "varchar", unique: true })
  ticketId!: string;

  @Column({ type: "varchar" })
  matchId!: string;

  @Column({ type: "varchar" })
  sessionId!: string;

  @Column({ type: "timestamp", default: () => "CURRENT_TIMESTAMP" })
  joinedAt!: Date;

  @Column({ type: "enum", enum: QueueStatus, default: QueueStatus.CONNECTING })
  status!: QueueStatus;

  @Column({ type: "boolean", default: false })
  preventMessage!: boolean;

  @CreateDateColumn()
  createdAt!: Date;

  @UpdateDateColumn()
  updatedAt!: Date;
}
