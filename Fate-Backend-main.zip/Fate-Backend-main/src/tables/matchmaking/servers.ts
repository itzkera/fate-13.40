import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
  BeforeUpdate,
} from "typeorm";

export enum ServerRegion {
  NAE = "NAE",
  NAW = "NAW",
  EU = "EU",
  OCE = "OCE",
  ASIA = "ASIA",
  ME = "ME",
}

export enum ServerStatus {
  OFFLINE = "offline",
  ONLINE = "online",
  GAMESTARTED = "gamestarted",
  GAMEENDED = "gameended",
}

@Entity("servers")
@Index(["serverId"])
@Index(["region"])
@Index(["playlist"])
@Index(["status"])
@Index(["customKey"])
export class Server {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "varchar", unique: true })
  serverId!: string;

  @Column({
    type: "enum",
    enum: ServerRegion,
  })
  region!: ServerRegion;

  @Column({ type: "varchar" })
  playlist!: string;

  @Column({
    type: "enum",
    enum: ServerStatus,
    default: ServerStatus.OFFLINE,
  })
  status!: ServerStatus;

  @Column({ type: "int", default: 100 })
  maxPlayers!: number;

  @Column({ type: "int", default: 0 })
  currentPlayers!: number;

  @Column({ type: "int", default: 1 })
  season!: number;

  @Column({ type: "varchar", default: "none" })
  customKey!: string;

  @Column({ type: "varchar" })
  ip!: string;

  @Column({ type: "int" })
  port!: number;

  @CreateDateColumn()
  createdAt!: Date;

  @UpdateDateColumn()
  updatedAt!: Date;

  @BeforeUpdate()
  updateTimestamp() {
    this.updatedAt = new Date();
  }
}
