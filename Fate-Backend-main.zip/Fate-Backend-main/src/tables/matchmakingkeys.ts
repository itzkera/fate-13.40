import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity({ name: "matchmaking_key" })
export class MatchmakingKeys {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "varchar", length: 255 })
  interaction!: string;

  @Column({ type: "varchar", length: 255 })
  key!: string;
}
