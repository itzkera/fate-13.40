import crypto from "node:crypto";

const TTL_MS = 5 * 60 * 1000;

interface Entry {
    accountId: string;
    expiresAt: number;
}

const store = new Map<string, Entry>();

function purgeExpired() {
    const now = Date.now();
    for (const [code, entry] of store.entries()) {
        if (now > entry.expiresAt) store.delete(code);
    }
}

export function createExchangeCode(accountId: string): string {
    purgeExpired();
    const code = crypto.randomBytes(16).toString("hex");
    store.set(code, { accountId, expiresAt: Date.now() + TTL_MS });
    return code;
}

export function redeemExchangeCode(code: string): string | null {
    const entry = store.get(code);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
        store.delete(code);
        return null;
    }
    store.delete(code);
    return entry.accountId;
}

export function revokeExchangeCode(code: string): boolean {
    if (!store.has(code)) return false;
    store.delete(code);
    return true;
}

export function listExchangeCodes(): Array<{ code: string; accountId: string; expiresAt: number }> {
    purgeExpired();
    return Array.from(store.entries()).map(([code, entry]) => ({
        code,
        accountId: entry.accountId,
        expiresAt: entry.expiresAt,
    }));
}
