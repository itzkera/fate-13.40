import crypto from "node:crypto";

const TTL_MS = 5 * 60 * 1000;

interface Entry {
  accountId: string;
  expiresAt: number;
}

const store = new Map<string, Entry>();

function purgeExpired() {
  const now = Date.now();
  for (const [code, entry] of store.entries()) {
    if (now > entry.expiresAt) store.delete(code);
  }
}

export function createMobileAuthCode(accountId: string): string {
  purgeExpired();
  for (const [code, entry] of store.entries()) {
    if (entry.accountId === accountId && Date.now() < entry.expiresAt) return code;
  }
  const code = crypto.randomUUID();
  store.set(code, { accountId, expiresAt: Date.now() + TTL_MS });
  return code;
}

export function peekMobileAuthCode(code: string): string | null {
  const entry = store.get(code);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    store.delete(code);
    return null;
  }
  return entry.accountId;
}

export function redeemMobileAuthCode(code: string): string | null {
  const entry = store.get(code);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    store.delete(code);
    return null;
  }
  store.delete(code);
  return entry.accountId;
}
