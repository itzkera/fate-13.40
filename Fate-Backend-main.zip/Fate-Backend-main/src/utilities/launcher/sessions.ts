import type { ServerWebSocket } from "bun";

export interface LauncherSocket {
    sessionId: string;
    accountId?: string;
}

export const Sessions = new Map<string, ServerWebSocket<LauncherSocket>>();
export const StateMap = new Map<string, string>();
