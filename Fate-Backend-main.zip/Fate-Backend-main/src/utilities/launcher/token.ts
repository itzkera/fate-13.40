import jwt from "jsonwebtoken";
import { config } from "../..";

export interface LauncherTokenPayload {
    accountId: string;
    discordId: string;
    username: string;
    favorite_character?: string;
    vbucks: number;
    level: number;
    arenaHype?: number;
}

export function signLauncherToken(payload: LauncherTokenPayload): string {
    return jwt.sign(payload, `${config.client_secret}_launcher_v1`, { expiresIn: "24h" });
}

export function verifyLauncherToken(token: string): LauncherTokenPayload | null {
    try {
        return jwt.verify(token, `${config.client_secret}_launcher_v1`) as LauncherTokenPayload;
    } catch {
        return null;
    }
}
