import crypto from "node:crypto";
import { Sessions, StateMap, type LauncherSocket } from "./sessions";
import handler from "./wshandler";
import { logger } from "../..";

export function upgradeLauncherWS(request: Request, server: any): Response | undefined {
    const upgrade = request.headers.get("upgrade");
    if (upgrade?.toLowerCase() !== "websocket") {
        return new Response("Expected WebSocket upgrade", { status: 426 });
    }

    const sessionId = crypto.randomUUID();
    const upgraded = server.upgrade(request, { data: { sessionId } });
    if (!upgraded) {
        logger.error(`Launcher WS upgrade rejected: ${new URL(request.url).pathname}`);
        return new Response("WebSocket upgrade failed", { status: 400 });
    }

    return undefined;
}

export const launcherWebSocketHandlers = {
    open(socket: any) {
        Sessions.set(socket.data.sessionId, socket);
        logger.info(`Launcher WS connected: ${socket.data.sessionId}`);
    },

    async message(socket: any, message: string | Buffer) {
        await handler.handle(socket, message.toString());
    },

    close(socket: any) {
        for (const [state, sessionId] of StateMap.entries()) {
            if (sessionId === socket.data.sessionId) StateMap.delete(state);
        }
        Sessions.delete(socket.data.sessionId);
        logger.info(`Launcher WS disconnected: ${socket.data.sessionId}`);
    },
};
