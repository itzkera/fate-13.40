import type { ServerWebSocket } from "bun";
import crypto from "node:crypto";
import { type LauncherSocket, StateMap } from "./sessions";
import { verifyLauncherToken } from "./token";
import { createExchangeCode } from "./exchangecodes";
import {
  accountService,
  config,
  itemStorageService,
  serversService,
  userService,
} from "../..";
import { serverState } from "../state";
import ProfileHelper from "../ProfileHelper";
import { ServerStatus } from "../../tables/matchmaking/servers";

const SERVER_STALE_MS = Number(Bun.env.GAMESERVER_STALE_MS ?? 120_000);
const DEFAULT_NEWS = [
  {
    title: "Chapter 2 Season 3",
    body: "Re-experience the glory of Fortnite Chapter 2 Season 3 in 2026 using Lexa.",
    image:
      "https://www.washingtonpost.com/wp-apps/imrs.php?src=https://arc-anglerfish-washpost-prod-washpost.s3.amazonaws.com/public/ZCG77OCGZRCHDAQPBZRIGMVB7M.png&w=1440&impolicy=high_res",
  },
  {
    title: "Lexa Release",
    body: "Lexa is out hosting Fortnite Chapter 2 Season 3 for everyone to play!",
    image:
      "https://sm.ign.com/t/ign_nordic/video/f/fortnite-c/fortnite-chapter-2-season-3-battle-pass-gameplay-trailer_e7dc.1280.jpg",
  },
  {
    title: "Arena!",
    body: "Arena lategame is out for everyone to play! The arena rewards are visible in the game, and there is also V-Bucks upon kills and win.",
    image:
      "https://win.gg/wp-content/uploads/2022/08/Late-Game-Arena.webp.webp",
  },
];

function send(socket: ServerWebSocket<LauncherSocket>, data: object) {
  socket.send(JSON.stringify(data));
}

function sendError(socket: ServerWebSocket<LauncherSocket>, message: string) {
  send(socket, { type: "error", message });
}

function resolveFavoriteCharacter(
  athena: any,
  favoriteCharacter: unknown,
): string {
  if (typeof favoriteCharacter !== "string" || favoriteCharacter.length === 0) {
    return "AthenaCharacter:CID_001_Athena_Commando_F_Default";
  }

  if (favoriteCharacter.startsWith("AthenaCharacter:")) {
    return favoriteCharacter;
  }

  const item = athena?.items?.[favoriteCharacter];
  if (
    typeof item?.templateId === "string" &&
    item.templateId.startsWith("AthenaCharacter:")
  ) {
    return item.templateId;
  }

  return favoriteCharacter;
}

function isFreshServer(updatedAt: Date | string): boolean {
  const updatedAtMs = new Date(updatedAt).getTime();
  return (
    Number.isFinite(updatedAtMs) && Date.now() - updatedAtMs <= SERVER_STALE_MS
  );
}

async function getProfilePayload(
  payload: ReturnType<typeof verifyLauncherToken>,
) {
  if (!payload) return null;

  const [user, account, athena, commonCore] = await Promise.all([
    userService.findUserByAccountId(payload.accountId),
    accountService.findUserByAccountId(payload.accountId),
    ProfileHelper.getProfile(payload.accountId, "athena"),
    ProfileHelper.getProfile(payload.accountId, "common_core"),
  ]);

  return {
    accountId: payload.accountId,
    username: user?.username ?? payload.username,
    favorite_character: resolveFavoriteCharacter(
      athena,
      athena?.stats?.attributes?.favorite_character ??
        payload.favorite_character,
    ),
    vbucks:
      commonCore?.items?.["Currency:MtxPurchased"]?.quantity ?? payload.vbucks,
    level:
      athena?.stats?.attributes?.accountLevel ??
      athena?.stats?.attributes?.level ??
      payload.level,
    arenaHype: account?.arenaHype ?? payload.arenaHype ?? 0,
  };
}

async function getLauncherShopPayload() {
  const storefront = await itemStorageService.getItemByType("storefront");
  const shopData = storefront?.data as any;

  if (Array.isArray(shopData?.storefronts)) {
    return shopData;
  }

  const createCatalogEntries = (items: any[]) => {
    let priority = 0;
    return (items ?? []).map((item: any) => {
      priority += 1;
      const grants =
        Array.isArray(item.items) && item.items.length > 0
          ? [
              ...(item.item ? [{ templateId: item.item, quantity: 1 }] : []),
              ...item.items
                .filter((e: any) => e && typeof e.item === "string")
                .map((e: any) => ({ templateId: e.item, quantity: 1 })),
            ]
          : item.item
            ? [{ templateId: item.item, quantity: 1 }]
            : [];
      return {
        offerId: `item://${item.offerId}`,
        sortPriority: priority,
        catalogGroupPriority: priority,
        prices: [{ finalPrice: Number(item.price) || 0 }],
        itemGrants: grants,
      };
    });
  };

  return {
    storefronts: [
      {
        name: "BRDailyStorefront",
        catalogEntries:
          createCatalogEntries(
            shopData?.catalogItems?.BRDailyStorefront ?? [],
          ) ?? [],
      },
      {
        name: "BRWeeklyStorefront",
        catalogEntries:
          createCatalogEntries(
            shopData?.catalogItems?.BRWeeklyStorefront ?? [],
          ) ?? [],
      },
    ],
  };
}

export default {
  async handle(socket: ServerWebSocket<LauncherSocket>, raw: string) {
    let msg: Record<string, unknown> | null = null;
    try {
      msg = JSON.parse(raw) as Record<string, unknown>;
    } catch {
      return sendError(socket, "Invalid message.");
    }

    if (!msg || typeof msg.type !== "string") {
      return sendError(socket, "Invalid message.");
    }

    if (msg.type === "discord_oauth_login") {
      const state = crypto.randomUUID();
      StateMap.set(state, socket.data.sessionId);
      const params = new URLSearchParams({
        client_id: config.discord_client_id,
        redirect_uri: config.launcher_callback_uri,
        response_type: "code",
        scope: "identify",
        state,
      });
      return send(socket, {
        type: "oauth_url",
        url: `https://discord.com/api/oauth2/authorize?${params.toString()}`,
      });
    }

    const tokenStr = msg.token as string | undefined;
    if (!tokenStr) return sendError(socket, "Authorization required.");

    const payload = verifyLauncherToken(tokenStr);
    if (!payload) return sendError(socket, "Invalid or expired token.");

    socket.data.accountId = payload.accountId;

    switch (msg.type) {
      case "exchange": {
        const code = createExchangeCode(payload.accountId);
        return send(socket, { type: "exchange_code", exchange_code: code });
      }

      case "profile": {
        const profile = await getProfilePayload(payload);
        return send(socket, {
          type: "profile",
          data: profile,
        });
      }

      case "news": {
        return send(socket, {
          type: "news",
          data: {
            messages:
              serverState.news.length > 0 ? serverState.news : DEFAULT_NEWS,
          },
        });
      }

      case "shop": {
        try {
          const data = await getLauncherShopPayload();
          return send(socket, { type: "shop", data });
        } catch {
          return sendError(socket, "Failed to load shop.");
        }
      }

      case "build": {
        return send(socket, {
          type: "build",
          data: { season: 13, build: "13.40", version: "0.0.3" },
        });
      }

      case "server_status": {
        const servers = await serversService.findAll();
        const activeServers = [];

        for (const server of servers) {
          const activeStatus =
            server.status === ServerStatus.ONLINE ||
            server.status === ServerStatus.GAMESTARTED;

          if (!activeStatus) continue;

          if (!isFreshServer(server.updatedAt)) {
            await serversService.update(server.id, {
              status: ServerStatus.GAMEENDED,
              currentPlayers: 0,
            });
            continue;
          }

          activeServers.push(server);
        }

        return send(socket, {
          type: "server_status",
          servers: activeServers.map((server) => ({
            ip: server.ip,
            port: server.port,
            region: server.region,
            playlist: server.playlist,
            bGameStarted: server.status === ServerStatus.GAMESTARTED,
            playerCount: server.currentPlayers,
            matchId: server.serverId,
          })),
        });
      }

      default:
        return sendError(socket, `Unknown message type: "${msg.type}"`);
    }
  },
};
