import { LRUCache } from "lru-cache";
import { logger } from "..";
import type { IProfile } from "../../types/profilesdefs";
import ProfileHelper from "./ProfileHelper";
import type { ProfileId } from "./responses";

export const profileCache = new LRUCache<string, { data: IProfile; timestamp: number }>({
  max: 1000,
  ttl: 1000 * 60 * 1,
});

type AllowedProfileTypes =
  | "athena"
  | "common_core"
  | "profile0"
  | "common_public"
  | "campaign"
  | "metadata"
  | "theater0"
  | "collection_book_people0"
  | "collection_book_schematics0"
  | "outpost0"
  | "creative"
  | "collections"
  | "id"
  | "hasId"
  | "reload";

const profileTypes = new Map<ProfileId, AllowedProfileTypes>([
  ["athena", "athena"],
  ["profile0", "profile0"],
  ["common_core", "common_core"],
  ["common_public", "common_public"],
  ["campaign", "campaign"],
  ["metadata", "metadata"],
  ["theater0", "theater0"],
  ["creative", "creative"],
  ["collections", "collections"],
  ["collection_book_people0", "collection_book_people0"],
  ["collection_book_schematics0", "collection_book_schematics0"],
  ["outpost0", "outpost0"],
]);

export async function handleProfileSelection(
  profileId: ProfileId,
  accountId: string,
): Promise<IProfile | null> {
  const profileType = profileTypes.get(profileId);

  if (!profileType) {
    logger.error(`Invalid Profile Type: ${profileId}`);
    return null;
  }

  const cacheKey = `${accountId}:${profileId}`;
  const cachedEntry = profileCache.get(cacheKey);

  if (cachedEntry) {
    return cachedEntry.data;
  }

  const profile = await ProfileHelper.getProfile(accountId, profileType);

  if (!profile) {
    return null;
  }

  profileCache.set(cacheKey, { data: profile, timestamp: Date.now() });

  return profile;
}
