import fetch from "node-fetch";
import https from "https";
import { config, logger } from "..";

export default async function RefreshAccount(accountId: string, username: string) {
  try {
  } catch (error) {
    logger.error(`Error: ${error}`);
  }
}
