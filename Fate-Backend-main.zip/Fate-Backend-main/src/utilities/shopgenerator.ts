import rotate from "../modules/shop/rotate/rotate";

export async function generateShop(): Promise<void> {
    await rotate();
}
