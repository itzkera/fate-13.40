export type AuditEntry = {
    id: string;
    timestamp: string;
    admin: string;
    action: string;
    target?: string;
    details?: Record<string, any>;
};

export type Hotfix = {
    id: string;
    name: string;
    content: string;
    createdAt: string;
};

export const serverState = {
    status: "UP" as "UP" | "DOWN",
    discordOAuthEnabled: true,
    matchmakingEnabled: true,
    autorotateEnabled: true,
    news: [] as Array<{ id: string; title: string; body: string; image: string }>,
    events: [] as Array<{ id: string; title: string; body: string; image: string }>,
    hotfixes: [] as Hotfix[],
    scheduledRotations: [] as Array<{
        id: string;
        date: string;
        items: string[];
    }>,
    scheduleTimeouts: new Map<string, ReturnType<typeof setTimeout>>(),
    auditLog: [] as AuditEntry[],
};
