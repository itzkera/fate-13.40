export interface UserAgentInfo {
  buildId?: string;
  buildString: string;
}

export interface SeasonInfo {
  season: number;
  build?: number;
  netcl?: string;
  buildUpdate: number;
  lobby: string;
  background: string;
}

export default function uaparser(userAgent: string | undefined): SeasonInfo | null {
  if (!userAgent) return null;

  const getBuildID = (): string | undefined => {
    const clMatch = userAgent.match(/CL-(\d+)/);
    return clMatch?.[1];
  };

  const getBuildUpdate = (): number => {
    const releaseMatch = userAgent.match(/Release-(\d+\.\d+)/);
    const build = parseFloat(releaseMatch?.[1] ?? "");
    return Number.isFinite(build) ? build : 0.0;
  };

  const handleValidBuild = ({ buildId }: UserAgentInfo): SeasonInfo => {
    const netcl = buildId;
    const buildUpdate = getBuildUpdate();

    let season = Math.floor(buildUpdate);
    let build = buildUpdate;
    let lobby = "";
    let background = "";

    switch (true) {
      case !netcl:
        season = 0;
        build = 0.0;
        lobby = "LobbySeason0";
        break;

      case Number(netcl) < 3724489:
        season = 0;
        build = 0.0;
        lobby = "Season0";
        break;

      case Number(netcl) <= 3790078:
        season = 1;
        build = 1.0;
        lobby = "LobbySeason1";
        break;

      case buildUpdate === 2.0:
        season = 2;
        build = 2.0;
        lobby = "LobbyWinterDecor";
        break;

      case season === 6:
        lobby = `Lobby${season}`;
        background = "fortnitemares";
        break;

      case season === 10:
        lobby = `Lobby${season}`;
        background = "seasonx";
        break;

      default:
        lobby = `Lobby${season}`;
        background = `season${season}`;
        break;
    }

    return {
      season,
      build,
      netcl,
      buildUpdate,
      lobby,
      background,
    };
  };

  const buildID = getBuildID();
  const buildUpdate = getBuildUpdate();

  if (buildID || buildUpdate > 0) {
    return handleValidBuild({ buildId: buildID, buildString: String(buildUpdate) });
  }

  return null;
}
