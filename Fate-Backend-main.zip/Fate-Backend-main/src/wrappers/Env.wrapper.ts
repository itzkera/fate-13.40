import { readFileSync, existsSync } from "fs";
import { join } from "path";
import { z } from "zod";
import ini from "ini";

type ConfigType = z.infer<typeof configSchema>;

const configSchema = z.object({
  port: z.number(),
  environment: z.enum(["production", "testing"]).default("production"),

  databaseUrl: z.string(),
  drop: z.boolean().default(false),

  bot_token: z.string().default(""),
  guild_id: z.string(),
  webhook_url: z.string().default(""),
  discord_client_id: z.string().default(""),
  discord_client_secret: z.string().default(""),

  client_secret: z.string(),
  jwt_secret: z.string().default("admin_secret"),
  admin_key: z.string().default(""),
  admin_discord_ids: z.array(z.string()).default([]),

  admin_frontend_url: z.string().default("http://localhost:3000"),
  admin_redirect_uri: z.string().default(""),

  launcher_port: z.number().default(7777),
  launcher_callback_uri: z.string().default(""),
  launcher_version: z.string().default("1.0.0"),
  build_path: z.string().default(""),

  currentSeason: z.number(),
  regions: z.array(z.string()).default(["EU"]),
  eu_gameserver: z.string().default(""),
  nae_gameserver: z.string().default(""),
  max_players: z.number().default(100),
  min_players_custom: z.number().default(2),
  max_players_custom: z.number().default(100),
});

export default class Config {
  private config: ConfigType;

  constructor() {
    const iniPath = join(process.cwd(), "config.ini");
    if (!existsSync(iniPath)) throw new Error("config.ini not found in working directory");

    const raw = ini.parse(readFileSync(iniPath, "utf-8"));

    const s = raw.server ?? {};
    const db = raw.database ?? {};
    const discord = raw.discord ?? {};
    const security = raw.security ?? {};
    const admin = raw.admin ?? {};
    const launcher = raw.launcher ?? {};
    const game = raw.game ?? {};

    const parsedConfig = configSchema.safeParse({
      port: parseInt(s.port, 10),
      environment: s.environment,

      databaseUrl: db.url,
      drop: String(db.drop) === "true",

      bot_token: discord.bot_token,
      guild_id: String(discord.guild_id ?? ""),
      webhook_url: discord.webhook_url ?? "",
      discord_client_id: String(discord.client_id ?? ""),
      discord_client_secret: discord.client_secret ?? "",

      client_secret: security.client_secret,
      jwt_secret: security.jwt_secret ?? "admin_secret",
      admin_key: security.admin_key ?? "",
      admin_discord_ids: security.admin_discord_ids
        ? String(security.admin_discord_ids).split(",").map((id: string) => id.trim()).filter(Boolean)
        : [],

      admin_frontend_url: admin.frontend_url ?? "http://localhost:3000",
      admin_redirect_uri: admin.redirect_uri ?? "",

      launcher_port: parseInt(launcher.port ?? "7777", 10),
      launcher_callback_uri: launcher.callback_uri ?? "",
      launcher_version: String(launcher.version ?? "1.0.0"),
      build_path: launcher.build_path ?? "",

      currentSeason: parseInt(game.season, 10),
      regions: game.regions ? String(game.regions).split(",").map((r: string) => r.trim()) : ["EU"],
      eu_gameserver: game.eu_gameserver ?? "",
      nae_gameserver: game.nae_gameserver ?? "",
      max_players: parseInt(game.max_players ?? "100", 10),
      min_players_custom: parseInt(game.min_players_custom ?? "2", 10),
      max_players_custom: parseInt(game.max_players_custom ?? "100", 10),
    });

    if (!parsedConfig.success)
      throw new Error(parsedConfig.error.errors.map((err) => err.message).join("\n"));

    this.config = parsedConfig.data;
  }

  public getConfig(): ConfigType {
    return this.config;
  }
}
