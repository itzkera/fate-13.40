import { config, logger } from "..";

export function GetDefaultEngine(): string {
  return `[OnlineSubsystemMcp.Xmpp]
#Domain="ws://12"
ServerAddr="ws://69.10.63.35"
bUseSSL=false
#bUsePlainTextAuth=true
ServerPort=80

[OnlineSubsystemMcp.Xmpp Prod]
#Domain="ilyskies.wtf"
ServerAddr="ws://69.10.63.35"
bUseSSL=false
#bUsePlainTextAuth=true
ServerPort=80

[OnlineSubsystemMcp]
bUsePartySystemV2=false

[OnlineSubsystemMcp.OnlinePartySystemMcpAdapter]
bUsePartySystemV2=false

[OnlineSubsystem]
bHasVoiceEnabled=true

[OnlineSubsystemMcp.OnlineIdentityMcp]
bAutoLoginToXmpp=true
bShouldReconnectXmpp=true
bOfflineAccountToken=true
bOfflineClientToken=true
bVerifyAuthIncludesPermissions=true


[Voice]
bEnabled=true

[XMPP]
bEnableWebsockets=true
bEnabled=true

[/Script/Engine.InputSettings]
+ConsoleKeys=Tilde
+ConsoleKeys=F8

[/Script/FortniteGame.FortPlayerController]
TurboBuildInterval=0.005f
TurboBuildFirstInterval=0.005f
bClientSideEditPrediction=false

[HTTP.Curl]
bAllowSeekFunction=false

[LwsWebSocket]
bDisableCertValidation=true

[ConsoleVariables]
Store.EnableCatabaScreen=1
Store.EnableCatabaHighlights=1
FortPlaylistManager.CachedPlaylistsEnabled=1
Fort.Rollback.UseCosmeticFlowOnlyWhereRequired=1
Athena.Frontend.ShowMPLobbyOnboardingModal=0
Sparks.Catalog.MidiDecryptionKey="KbSsGNCQFmVZJE4VVIvUwRuY0zrVf3sNm//2zrfPYUU="
Fort.Rollback.DisableRarityTags=0
CMS.DisableFileCache=true
FortMatchmakingV2.EnableContentBeacon=0
FortMatchmakingV2.ContentBeaconFailureCancelsMatchmaking=0
Fort.ShutdownWhenContentBeaconFails=0
net.AllowEncryption=0

[Core.Log]
LogXmpp=Verbose

[/Script/Qos.QosRegionManager]
NumTestsPerRegion=2
PingTimeout=3.0
!DatacenterDefinitions=ClearArray
+DatacenterDefinitions=(Id="VA", RegionId="NAE", bEnabled=true, Servers[0]=(Address="ping-nae.ds.on.epicgames.com", Port=22222))
+DatacenterDefinitions=(Id="DE", RegionId="EU", bEnabled=true, Servers[0]=(Address="ping-eu.ds.on.epicgames.com", Port=22222))
`;
}

export function GetDefaultGame(version: number): string {
  let def: string = `[/Script/EngineSettings.GeneralProjectSettings]
ProjectID=(A=-2011270876,B=1182903154,C=-965786730,D=-1399474123)
ProjectName=Fortnite
ProjectDisplayedTitle=NSLOCTEXT("Lexa", "FortniteMainWindowTitle", "Lexa")
ProjectVersion=1.0.0
CompanyName=Epic Games, Inc.
CompanyDistinguishedName="CN=Epic Games, O=Epic Games, L=Cary, S=North Carolina, C=US"
CopyrightNotice=Copyright Epic Games, Inc. All Rights Reserved.

[VoiceChatManager]
bEnabled=true
bEnableOnLoadingScreen=true
bObtainJoinTokenFromPartyService=true
bAllowStateTransitionOnLoadingScreen=false
MaxRetries=5
RetryTimeJitter=1.0
RetryTimeBase=3.0
RetryTimeMultiplier=1.0
MaxRetryDelay=240.0
RequestJoinTokenTimeout=10.0
JoinChannelTimeout=120.0
VoiceChatImplementation=Vivox
NetworkTypePollingDelay=0.0
PlayJoinSoundRecentLeaverDelaySeconds=30.0
DefaultInputVolume=1.0
DefaultOutputVolume=1.0
JoinTimeoutRecoveryMethod=Reinitialize
JoinErrorWorkaroundMethod=ResetConnection
NetworkChangeRecoveryMethod=ResetConnection
bEnableBluetoothMicrophone=false
VideoPreferredFramerate=0
bEnableEOSReservedAudioStreams=true

[VoiceChat.EOS]
bEnabled=true
bAllowLogout=false

ReplayStreamerOverride=FortniteDSSReplayStreamer

[/Script/FortniteGame.FortGlobals]
bEnableCreativeMode=false

[/Script/FortniteGame.FortPlayspaceGameState]
bUsePlayspaceSystem=true

[/Script/FortniteGame.FortGameStateAthena]
; BR: Whether to allow the player to build through objects that would normally block placement
bAllowBuildingThroughBlockingObjects=true

[/Script/FortniteGame.FortTextHotfixConfig]
+TextReplacements=(Category=Game, bIsMinimalPatch=True, Namespace="", Key="9F28701D47C7B91B048FEBA378ADDEAE", NativeString="Epic Games", LocalizedStrings=(("en","Lexa")))
+TextReplacements=(Category=Game, bIsMinimalPatch=True, Namespace="", Key="0BDA5AB64D20E843B2CF009897EBA8FC", NativeString="BATTLE ROYALE", LocalizedStrings=(("ar", "BATTLE ROYALE"),("en", "BATTLE ROYALE"),("de", "BATTLE ROYALE"),("es", "BATTLE ROYALE"),("es-419", "BATTLE ROYALE"),("fr", "BATTLE ROYALE"),("it", "BATTLE ROYALE"),("ja", "BATTLE ROYALE"),("ko", "BATTLE ROYALE"),("pl", "BATTLE ROYALE"),("pt-BR", "BATTLE ROYALE"),("ru", "BATTLE ROYALE"),("tr", "BATTLE ROYALE"),("zh-CN", "BATTLE ROYALE"),("zh-Hant", "BATTLE ROYALE")))


[/Script/FortniteGame.FortGameInstance]
KairosMinSupportedAppVersion=20
bBattleRoyaleMatchmakingEnabled=true
!FrontEndPlaylistData=ClearArray
FrontEndPlaylistData=(PlaylistName=Playlist_DefaultSolo, PlaylistAccess=(bEnabled=true, bIsDefaultPlaylist=true, bVisibleWhenDisabled=True, bDisplayAsNew=false, CategoryIndex=0, bDisplayAsLimitedTime=false, DisplayPriority=3))
;+FrontEndPlaylistData=(PlaylistName=Playlist_DefaultDuo, PlaylistAccess=(bEnabled=false, bIsDefaultPlaylist=true, bVisibleWhenDisabled=True, bDisplayAsNew=false, CategoryIndex=0, bDisplayAsLimitedTime=false, DisplayPriority=4))
;+FrontEndPlaylistData=(PlaylistName=Playlist_DefaultSquad, PlaylistAccess=(bEnabled=True, bIsDefaultPlaylist=true, bVisibleWhenDisabled=false, bDisplayAsNew=false, CategoryIndex=0, bDisplayAsLimitedTime=false, DisplayPriority=6))
;+FrontEndPlaylistData=(PlaylistName=Playlist_PlaygroundV2, PlaylistAccess=(bEnabled=False, bIsDefaultPlaylist=false, bVisibleWhenDisabled=true, bDisplayAsNew=true, CategoryIndex=1, bDisplayAsLimitedTime=false, DisplayPriority=15))
;+FrontEndPlaylistData=(PlaylistName=Playlist_BattleLab, PlaylistAccess=(bEnabled=False, bIsDefaultPlaylist=false, bVisibleWhenDisabled=true, bDisplayAsNew=false, CategoryIndex=1, bDisplayAsLimitedTime=false, DisplayPriority=16))

; Arena
+FrontEndPlaylistData=(PlaylistName=Playlist_ShowdownAlt_Solo, PlaylistAccess=(bEnabled=True, bIsDefaultPlaylist=true, bVisibleWhenDisabled=true, bDisplayAsNew=true, CategoryIndex=1, bDisplayAsLimitedTime=false, DisplayPriority=17))
+FrontEndPlaylistData=(PlaylistName=Playlist_ShowdownAlt_Duos, PlaylistAccess=(bEnabled=False, bIsDefaultPlaylist=true, bVisibleWhenDisabled=true, bDisplayAsNew=true, CategoryIndex=1, bDisplayAsLimitedTime=false, DisplayPriority=19))
+ExperimentalBucketPercentList=(ExperimentNum=23,Name="BattlePassPurchaseScreen",BucketPercents=(0, 50, 50))

[/Script/FortniteGame.FortPlayerPawn]
NavLocationValidityDistance=500
MoveSoundStimulusBroadcastInterval=0.5
bCharacterPartsCastIndirectShadows=true

[/Script/FortniteGame.FortOnlineAccount]
bShouldAthenaQueryRecentPlayers=false
bEnableEulaCheck=false
bShouldCheckIfPlatformAllowed=false
bDisablePurchasingOnRedemptionFailure=false

[/Script/FortniteGame.FortPlayerControllerAthena]
bNoInGameMatchmaking=true

[VoiceChat.Vivox]
bEnabled=true
ServerUrl="https://mtu1xp-mad.vivox.com"
ServiceUrl="https://mtu1xp-mad.vivox.com"
Domain="https://unity.vivox.com/appconfig/46738-lunar-79863-udash"
Issuer="46738-lunar-79863-udash"
Key="ikvUeQAPzWGPKuAYfsiKMbLCgHIdzG2K"
SecretKey="ikvUeQAPzWGPKuAYfsiKMbLCgHIdzG2K"

[VoiceChat.EOS]
bEnabled=true

[EOSSDK]
ProductName=VoicePlugin
ProductVersion=0.1
ProductId="d3df2e4cdf384ae0a2d87faa746d9f95"
SandboxId="d4ede3c68024456a85135250c48595a1"
DeploymentId="8bf4df3e0d154871b5c71b94d2f8994d"
ClientId="xyza7891WBgblbBRIWSsYVvQLjyUSvIo"
ClientSecret="CsDH07ei7JX5nlChe3XrthvsSsn1g4huyXAPLf3hmN8"

[/Script/FortniteGame.FortChatManager]
bShouldRequestGeneralChatRooms=true
bShouldJoinGlobalChat=true
bShouldJoinFounderChat=false
bIsAthenaGlobalChatEnabled=true
RecommendChatFailureDelay=30
RecommendChatBackoffMultiplier=2.0
RecommendChatRandomWindow=120.0
RecommendChatFailureCountCap=7

[OnlinePartyEmbeddedCommunication]
bRetainPartyStateFields=false
bPerformAutoPromotion=true
InviteNotificationDelaySeconds=1.0

[/Script/Party.SocialSettings]
bMustSendPrimaryInvites=true
bLeavePartyOnDisconnect=false
bSetDesiredPrivacyOnLocalPlayerBecomesLeader=false
DefaultMaxPartySize=16`;

  return def;
}

export function GetDefaultRuntimeOptions(): string {
  return `
[/Script/FortniteGame.FortRuntimeOptions]
!DisabledFrontendNavigationTabs=ClearArray
+DisabledFrontendNavigationTabs=(TabName="AthenaStore",TabState=EFortRuntimeOptionTabState::Hidden)
!ExperimentalCohortPercent=ClearArray
!AthenaStarterGameMode=ClearArray
!HiddenSettings=ClearArray
!DisabledFrontendNavigationTabs=ClearArray
bShowStoreBanner=true
bEnableCatabaDynamicBackground=true
bShouldAllowNightNightMode=true
bForceEverybodyToGoNightNight=false
bEnableSocialTab=false
bSkipTrailerMovie=false
bWaitForServerToBeInitializedBeforeTravelingFeatureEnabled=false
bEnableRufusOnePageShop=false
bIsOutOfSeasonMode=false
bHabaneroEnabled=false
bSkipSubgameSelect=true
+AthenaStarterGameMode="Playlist_DefaultSolo"
+AthenaStarterGameMode="Playlist_DefaultDuo"
+AthenaStarterGameMode="Playlist_DefaultSquad"
+ExperimentalCohortPercent=(CohortPercent=100,ExperimentNum=14)
+ExperimentalCohortPercent=(CohortPercent=100,ExperimentNum=15)
+ExperimentalCohortPercent=(CohortPercent=100,ExperimentNum=20)
+ExperimentalCohortPercent=(CohortPercent=100,ExperimentNum=21)
+ExperimentalCohortPercent=(CohortPercent=100,ExperimentNum=22)
+ExperimentalCohortPercent=(CohortPercent=100,ExperimentNum=23)
+ExperimentalCohortPercent=(CohortPercent=100,ExperimentNum=24)
+ExperimentalBucketPercentList=(ExperimentNum=35,Name="AllowShopBillboardOfferGroups",BucketPercents=(0,100))
+ExperimentalBucketPercentList=(ExperimentNum=36,Name="AllowShopBillboardOfferGroups_2",BucketPercents=(0,100))
+ExperimentalBucketPercentList=(ExperimentNum=37,Name="AllowShopBillboardOfferGroups_3",BucketPercents=(0,100))
+ExperimentalBucketPercentList=(ExperimentNum=38,Name="AllowShopBillboardOfferGroups_4",BucketPercents=(0,100))
+ExperimentalBucketPercentList=(ExperimentNum=39,Name="AllowShopBillboardOfferGroups_5",BucketPercents=(0,100))
+ExperimentalBucketPercentList=(ExperimentNum=40,Name="AllowShopBillboardOfferGroups_6",BucketPercents=(0,100))
+ExperimentalBucketPercentList=(ExperimentNum=41,Name="AllowShopBillboardOfferGroups_7",BucketPercents=(0,100))
+ExperimentalBucketPercentList=(ExperimentNum=42,Name="AllowShopBillboardOfferGroups_8",BucketPercents=(0,100))
+ExperimentalBucketPercentList=(ExperimentNum=43,Name="AllowShopBillboardOfferGroups_9",BucketPercents=(0,100))
+ExperimentalBucketPercentList=(ExperimentNum=44,Name="AllowShopBillboardOfferGroups_10",BucketPercents=(0,100))
+ExperimentalBucketPercentList=(ExperimentNum=45,Name="AllowShopBillboardOfferGroups_11",BucketPercents=(0,100))
+ExperimentalBucketPercentList=(ExperimentNum=46,Name="AllowShopBillboardOfferGroups_12",BucketPercents=(0,100))`;
}
