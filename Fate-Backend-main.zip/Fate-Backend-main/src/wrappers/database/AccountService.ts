import { Repository, UpdateQueryBuilder } from "typeorm";
import Database from "../Database.wrapper";
import { logger } from "../..";
import { Account } from "../../tables/account";
import NodeCache from "node-cache";
import type { Permission } from "../../../types/permissionsdefs";

export default class AccountService {
  private accountRepository: Repository<Account>;
  private cache: NodeCache;

  constructor(private database: Database) {
    this.accountRepository = this.database.getRepository("account");
    this.cache = new NodeCache();
  }

  private getRandomTTL(): number {
    return Math.floor(Math.random() * (300 - 60 + 1)) + 60;
  }

  public async findUserByAccountId(accountId: string): Promise<Account | null> {
    try {
      const cachedAccount = this.cache.get<Account>(`account_${accountId}`);
      if (cachedAccount) {
        return cachedAccount;
      } else {
        const account = await this.accountRepository
          .createQueryBuilder("account")
          .where("account.accountId = :accountId", { accountId })
          .getOne();

        if (account) {
          const ttl = this.getRandomTTL();
          this.cache.set(`account_${accountId}`, account, ttl);
        }

        return account || null;
      }
    } catch (error) {
      logger.error(`Error finding account: ${error}`);
      return null;
    }
  }

  public async findUserByDiscordId(discordId: string): Promise<Account | null> {
    try {
      const cachedAccount = this.cache.get<Account>(`account_discord_${discordId}`);
      if (cachedAccount) {
        return cachedAccount;
      } else {
        const account = await this.accountRepository
          .createQueryBuilder("account")
          .where("account.discordId = :discordId", { discordId })
          .getOne();

        if (account) {
          const ttl = this.getRandomTTL();
          this.cache.set(`account_discord_${discordId}`, account, ttl);
        }

        return account || null;
      }
    } catch (error) {
      logger.error(`Error finding account: ${error}`);
      return null;
    }
  }

  public async create(account: Partial<Account>): Promise<Account | null> {
    try {
      const newAccount = this.accountRepository.create(account);
      await this.accountRepository.save(newAccount);
      return newAccount;
    } catch (error) {
      logger.error(`Error creating account: ${error}`);
      return null;
    }
  }

  public async delete(accountId: string): Promise<boolean> {
    try {
      const account = await this.accountRepository.findOne({ where: { accountId } });
      if (!account) return false;

      this.cache.del(`account_${accountId}`);
      this.cache.del(`account_discord_${account.discordId}`);

      const result = await this.accountRepository.delete({ accountId });
      return result.affected === 1;
    } catch (error) {
      logger.error(`Error deleting account: ${error}`);
      return false;
    }
  }

  public async createDefaultPermissions(accountId: string): Promise<boolean> {
    try {
      const defaultPermissions: Permission[] = [
        {
          resource: "fortnite:cloudstorage:system",
          abilities: "READ",
          action: 1,
        },
        {
          resource: "fortnite:cloudstorage:system:*",
          abilities: "READ",
          action: 1,
        },
        {
          resource: `friends:${accountId}`,
          abilities: "READ,UPDATE,DELETE",
          action: 2,
        },
        {
          resource: `fortnite:profile:${accountId}:commands`,
          abilities: "*",
          action: 5,
        },
        {
          resource: `fortnite:profile:${accountId}:receipts`,
          abilities: "*",
          action: 5,
        },
        {
          resource: "fortnite:calender",
          abilities: "READ",
          action: 1,
        },
        {
          resource: "fortnite:cloudstorage:system:DefaultEngine.ini",
          abilities: "READ",
          action: 1,
        },
        {
          resource: "fortnite:cloudstorage:system:DefaultGame.ini",
          abilities: "READ",
          action: 1,
        },
        {
          resource: "fortnite:cloudstorage:system:DefaultRuntimeOptions.ini",
          abilities: "READ",
          action: 1,
        },
        {
          resource: "fortnite:stats",
          abilities: "READ",
          action: 1,
        },
      ];

      await this.updateAccount(accountId, { permissions: defaultPermissions });
      return true;
    } catch (error) {
      logger.error(`Error creating default permissions: ${error}`);
      return false;
    }
  }

  public async updateAccount(accountId: string, updateData: Partial<Account>): Promise<boolean> {
    try {
      const queryBuilder: UpdateQueryBuilder<Account> = this.accountRepository
        .createQueryBuilder()
        .update(Account)
        .set(updateData as any)
        .where("accountId = :accountId", { accountId });

      const result = await queryBuilder.execute();

      if (result.affected === 0) {
        logger.error(`No rows updated for account ${accountId}.`);
        return false;
      }

      this.cache.del(`account_${accountId}`);
      return true;
    } catch (error) {
      logger.error(`Error updating account: ${error}`);
      return false;
    }
  }

  public async addArenaHype(accountId: string, amount: number): Promise<number | null> {
    try {
      const result = await this.accountRepository
        .createQueryBuilder()
        .update(Account)
        .set({
          arenaHype: () => `GREATEST(0, "arenaHype" + ${amount})`,
        })
        .where("accountId = :accountId", { accountId })
        .returning(["arenaHype"])
        .execute();

      if (result.affected === 0) {
        logger.error(`No rows updated for account ${accountId}.`);
        return null;
      }

      this.cache.del(`account_${accountId}`);
      return Number(result.raw[0]?.arenaHype ?? 0);
    } catch (error) {
      logger.error(`Error adding arena hype for account ${accountId}: ${error}`);
      return null;
    }
  }
}
