import { Repository } from "typeorm";
import Database from "../Database.wrapper";
import { logger } from "../../";
import { Ban } from "../../tables/anticheat/ban";

export default class BanService {
  private banRepository: Repository<Ban>;

  constructor(private database: Database) {
    this.banRepository = this.database.getRepository("bans");
  }

  public async findByAccountId(accountId: string): Promise<Ban | null> {
    try {
      return await this.banRepository.findOne({ where: { accountId } });
    } catch (error) {
      logger.error(`Error finding ban for ${accountId}: ${error}`);
      return null;
    }
  }

  public async createOrUpdate(ban: Partial<Ban> & { accountId: string }): Promise<Ban | null> {
    try {
      const upsertResult = await this.banRepository.upsert(ban, { conflictPaths: ["accountId"] });
      return upsertResult.generatedMaps[0] as Ban;
    } catch (error) {
      logger.error(`Error creating/updating ban: ${error}`);
      return null;
    }
  }

  public async deleteByAccountId(accountId: string): Promise<boolean> {
    try {
      const result = await this.banRepository.delete({ accountId });
      return result.affected !== undefined && result.affected! > 0;
    } catch (error) {
      logger.error(`Error deleting ban for ${accountId}: ${error}`);
      return false;
    }
  }

  public async setShadowBan(
    accountId: string,
    shadow: Partial<
      Pick<Ban, "isShadowBanned" | "shadowBanReason" | "shadowBanStart" | "shadowBanEnd">
    >,
  ): Promise<boolean> {
    try {
      const result = await this.banRepository
        .createQueryBuilder()
        .update(Ban)
        .set(shadow as any)
        .where("accountId = :accountId", { accountId })
        .execute();
      return result.affected !== undefined && result.affected > 0;
    } catch (error) {
      logger.error(`Error updating shadow ban for ${accountId}: ${error}`);
      return false;
    }
  }
}
