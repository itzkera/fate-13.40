import { Repository, UpdateQueryBuilder } from "typeorm";
import Database from "../Database.wrapper";
import { logger } from "../..";
import { Client } from "../../tables/matchmaking/clients";

export default class ClientService {
  private clientRepository: Repository<Client>;

  constructor(private database: Database) {
    this.clientRepository = this.database.getRepository("clients");
  }

  public async findById(id: string): Promise<Client | null> {
    try {
      const client = await this.clientRepository
        .createQueryBuilder("client")
        .where("client.id = :id", { id })
        .getOne();
      return client || null;
    } catch (error) {
      logger.error(`Error finding client: ${error}`);
      return null;
    }
  }

  public async findByPlayerId(playerId: string): Promise<Client | null> {
    try {
      const client = await this.clientRepository
        .createQueryBuilder("client")
        .where("client.playerId = :playerId", { playerId })
        .getOne();
      return client || null;
    } catch (error) {
      logger.error(`Error finding client by playerId: ${error}`);
      return null;
    }
  }

  public async updateByPlayerId(playerId: string, updateData: Partial<Client>): Promise<boolean> {
    try {
      const result = await this.clientRepository
        .createQueryBuilder()
        .update(Client)
        .set(updateData as any)
        .where("playerId = :playerId", { playerId })
        .execute();

      if (result.affected === 0) {
        logger.error(`No rows updated for client with playerId ${playerId}.`);
        return false;
      }

      return true;
    } catch (error) {
      logger.error(`Error updating client by playerId: ${error}`);
      return false;
    }
  }

  public async findBySocketId(socketId: string): Promise<Client | null> {
    try {
      const client = await this.clientRepository
        .createQueryBuilder("client")
        .where("client.socketId = :socketId", { socketId })
        .getOne();
      return client || null;
    } catch (error) {
      logger.error(`Error finding client by socketId: ${error}`);
      return null;
    }
  }

  public async findBySessionId(sessionId: string): Promise<Client | null> {
    try {
      const client = await this.clientRepository
        .createQueryBuilder("client")
        .where("client.sessionId = :sessionId", { sessionId })
        .getOne();
      return client || null;
    } catch (error) {
      logger.error(`Error finding client by sessionId: ${error}`);
      return null;
    }
  }

  public async findByMatchId(matchId: string): Promise<Client[]> {
    try {
      return await this.clientRepository
        .createQueryBuilder("client")
        .where("client.matchId = :matchId", { matchId })
        .getMany();
    } catch (error) {
      logger.error(`Error finding clients by matchId: ${error}`);
      return [];
    }
  }

  public async findInactive(minutesInactive: number = 5): Promise<Client[]> {
    try {
      const thresholdDate = new Date(Date.now() - minutesInactive * 60 * 1000);
      return await this.clientRepository
        .createQueryBuilder("client")
        .where("client.lastActivity < :threshold", { threshold: thresholdDate })
        .getMany();
    } catch (error) {
      logger.error(`Error finding inactive clients: ${error}`);
      return [];
    }
  }

  public async findAll(): Promise<Client[]> {
    try {
      return await this.clientRepository.createQueryBuilder("client").getMany();
    } catch (error) {
      logger.error(`Error finding all clients: ${error}`);
      return [];
    }
  }

  public async create(client: Partial<Client>): Promise<Client | null> {
    try {
      const newClient = this.clientRepository.create(client);
      await this.clientRepository.save(newClient);
      return newClient;
    } catch (error) {
      logger.error(`Error creating client: ${error}`);
      return null;
    }
  }

  public async delete(id: string): Promise<boolean> {
    try {
      const result = await this.clientRepository.delete({ id });
      return result.affected === 1;
    } catch (error) {
      logger.error(`Error deleting client: ${error}`);
      return false;
    }
  }

  public async deleteByPlayerId(playerId: string): Promise<boolean> {
    try {
      const result = await this.clientRepository.delete({ playerId });
      return result.affected === 1;
    } catch (error) {
      logger.error(`Error deleting client by playerId: ${error}`);
      return false;
    }
  }

  public async update(id: string, updateData: Partial<Client>): Promise<boolean> {
    try {
      const result = await this.clientRepository
        .createQueryBuilder()
        .update(Client)
        .set(updateData as any)
        .where("id = :id", { id })
        .execute();
      return result.affected !== 0;
    } catch (error) {
      logger.error(`Error updating client: ${error}`);
      return false;
    }
  }

  public async updateLastActivity(playerId: string): Promise<boolean> {
    try {
      const result = await this.clientRepository
        .createQueryBuilder()
        .update(Client)
        .set({ lastActivity: new Date() })
        .where("playerId = :playerId", { playerId })
        .execute();
      return result.affected === 1;
    } catch (error) {
      logger.error(`Error updating last activity: ${error}`);
      return false;
    }
  }

  public async countActive(): Promise<number> {
    try {
      return await this.clientRepository.createQueryBuilder("client").getCount();
    } catch (error) {
      logger.error(`Error counting active clients: ${error}`);
      return 0;
    }
  }
}
