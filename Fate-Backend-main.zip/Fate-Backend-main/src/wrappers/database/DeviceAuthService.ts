import type { Repository } from "typeorm";
import { DeviceAuth } from "../../tables/deviceauth";
import type Database from "../Database.wrapper";
import { logger } from "../..";

export default class DeviceAuthService {
  private repository: Repository<DeviceAuth>;

  constructor(private database: Database) {
    this.repository = this.database.getRepository(DeviceAuth);
  }

  public async create(data: Omit<DeviceAuth, "id">): Promise<DeviceAuth | null> {
    try {
      const entity = this.repository.create(data);
      return await this.repository.save(entity);
    } catch (error) {
      logger.error(`Error creating DeviceAuth: ${error}`);
      return null;
    }
  }

  public async findByDeviceId(deviceId: string): Promise<DeviceAuth | null> {
    try {
      return await this.repository.findOne({ where: { deviceId } }) ?? null;
    } catch (error) {
      logger.error(`Error finding DeviceAuth by deviceId: ${error}`);
      return null;
    }
  }

  public async findAllByAccountId(accountId: string): Promise<DeviceAuth[]> {
    try {
      return await this.repository.find({ where: { accountId } });
    } catch (error) {
      logger.error(`Error finding DeviceAuths for accountId ${accountId}: ${error}`);
      return [];
    }
  }

  public async deleteByDeviceId(deviceId: string, accountId: string): Promise<boolean> {
    try {
      const result = await this.repository.delete({ deviceId, accountId });
      return (result.affected ?? 0) > 0;
    } catch (error) {
      logger.error(`Error deleting DeviceAuth: ${error}`);
      return false;
    }
  }

  public async updateLastAccess(
    deviceId: string,
    access: { location: string; ipAddress: string; dateTime: string },
  ): Promise<void> {
    try {
      await this.repository.update({ deviceId }, { lastAccess: access });
    } catch (error) {
      logger.error(`Error updating DeviceAuth lastAccess: ${error}`);
    }
  }

  public async findByAccountIdAndSecret(
    accountId: string,
    deviceId: string,
    secret: string,
  ): Promise<DeviceAuth | null> {
    try {
      return (
        (await this.repository.findOne({ where: { accountId, deviceId, secret } })) ?? null
      );
    } catch (error) {
      logger.error(`Error verifying DeviceAuth credentials: ${error}`);
      return null;
    }
  }
}
