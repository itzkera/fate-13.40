import type { Repository } from "typeorm";
import type { Friend, Friends } from "../../tables/friends";
import type Database from "../Database.wrapper";
import { logger } from "../..";

export default class FriendsService {
  private friendsRepository: Repository<Friends>;

  constructor(private database: Database) {
    this.friendsRepository = this.database.getRepository("friends");
  }

  public async findFriendByAccountId(accountId: string): Promise<Friends | null> {
    try {
      const friend = await this.friendsRepository
        .createQueryBuilder("friends")
        .where("friends.accountId = :accountId", { accountId })
        .getOne();
      return friend;
    } catch (error) {
      logger.error(`Error finding friend: ${error}`);
      return null;
    }
  }

  public async create(friends: Partial<Friends>): Promise<Friends | null> {
    try {
      const newFriend = this.friendsRepository.create(friends);
      await this.friendsRepository.save(newFriend);
      return newFriend;
    } catch (error) {
      logger.error(`Error creating friend: ${error}`);
      return null;
    }
  }

  public async addOrAccept(
    accountId: string,
    friendId: string,
  ): Promise<"SENT" | "ACCEPTED" | "EXISTS"> {
    return this.friendsRepository.manager.transaction(async (manager) => {
      const repository = manager.getRepository(this.friendsRepository.target);
      const [firstId, secondId] = [accountId, friendId].sort();
      const records = await repository
        .createQueryBuilder("friends")
        .setLock("pessimistic_write")
        .where("friends.accountId IN (:...ids)", { ids: [firstId, secondId] })
        .orderBy("friends.accountId", "ASC")
        .getMany();
      const user = records.find((record) => record.accountId === accountId);
      const target = records.find((record) => record.accountId === friendId);

      if (!user || !target) throw new Error("Friends record not found");
      if (
        user.blocked.some((entry) => entry.accountId === friendId) ||
        target.blocked.some((entry) => entry.accountId === accountId)
      )
        throw new Error("Friendship is blocked");
      if (user.accepted.some((entry) => entry.accountId === friendId)) return "EXISTS";

      const now = new Date().toISOString();
      const incoming = user.incoming.find((entry) => entry.accountId === friendId);
      if (incoming) {
        user.incoming = user.incoming.filter((entry) => entry.accountId !== friendId);
        target.outgoing = target.outgoing.filter((entry) => entry.accountId !== accountId);
        user.accepted = [...user.accepted, { ...incoming, createdAt: now }];
        target.accepted = [...target.accepted, this.entry(accountId, now)];
        await repository.save([user, target]);
        return "ACCEPTED";
      }

      if (user.outgoing.some((entry) => entry.accountId === friendId)) return "EXISTS";

      user.outgoing = [...user.outgoing, this.entry(friendId, now)];
      target.incoming = [...target.incoming, this.entry(accountId, now)];
      await repository.save([user, target]);
      return "SENT";
    });
  }

  public async remove(accountId: string, friendId: string): Promise<boolean> {
    return this.updatePair(accountId, friendId, (user, target) => {
      const existed = [user.accepted, user.incoming, user.outgoing].some((list) =>
        list.some((entry) => entry.accountId === friendId),
      );
      user.accepted = user.accepted.filter((entry) => entry.accountId !== friendId);
      user.incoming = user.incoming.filter((entry) => entry.accountId !== friendId);
      user.outgoing = user.outgoing.filter((entry) => entry.accountId !== friendId);
      target.accepted = target.accepted.filter((entry) => entry.accountId !== accountId);
      target.incoming = target.incoming.filter((entry) => entry.accountId !== accountId);
      target.outgoing = target.outgoing.filter((entry) => entry.accountId !== accountId);
      return existed;
    });
  }

  public async block(accountId: string, friendId: string): Promise<void> {
    await this.updatePair(accountId, friendId, (user, target) => {
      user.accepted = user.accepted.filter((entry) => entry.accountId !== friendId);
      user.incoming = user.incoming.filter((entry) => entry.accountId !== friendId);
      user.outgoing = user.outgoing.filter((entry) => entry.accountId !== friendId);
      target.accepted = target.accepted.filter((entry) => entry.accountId !== accountId);
      target.incoming = target.incoming.filter((entry) => entry.accountId !== accountId);
      target.outgoing = target.outgoing.filter((entry) => entry.accountId !== accountId);
      if (!user.blocked.some((entry) => entry.accountId === friendId))
        user.blocked = [...user.blocked, this.entry(friendId)];
    });
  }

  public async unblock(accountId: string, friendId: string): Promise<boolean> {
    return this.updatePair(accountId, friendId, (user) => {
      const existed = user.blocked.some((entry) => entry.accountId === friendId);
      user.blocked = user.blocked.filter((entry) => entry.accountId !== friendId);
      return existed;
    });
  }

  private entry(accountId: string, createdAt = new Date().toISOString()): Friend {
    return { accountId, createdAt, alias: "" };
  }

  private async updatePair<T>(
    accountId: string,
    friendId: string,
    update: (user: Friends, target: Friends) => T,
  ): Promise<T> {
    return this.friendsRepository.manager.transaction(async (manager) => {
      const repository = manager.getRepository(this.friendsRepository.target);
      const ids = [accountId, friendId].sort();
      const records = await repository
        .createQueryBuilder("friends")
        .setLock("pessimistic_write")
        .where("friends.accountId IN (:...ids)", { ids })
        .orderBy("friends.accountId", "ASC")
        .getMany();
      const user = records.find((record) => record.accountId === accountId);
      const target = records.find((record) => record.accountId === friendId);
      if (!user || !target) throw new Error("Friends record not found");

      const result = update(user, target);
      await repository.save([user, target]);
      return result;
    });
  }

  public async delete(accountId: string): Promise<boolean> {
    try {
      const result = await this.friendsRepository.delete({ accountId });
      if (result.affected === 1) return true;
      return false;
    } catch (error) {
      logger.error(`Error deleting friends: ${error}`);
      return false;
    }
  }
}
