import { Repository } from "typeorm";
import Database from "../Database.wrapper";
import { Hardwares } from "../../tables/anticheat/hardwares";
import { logger } from "../..";

export default class HardwaresService {
  private hardwaresRepository: Repository<Hardwares>;

  constructor(private database: Database) {
    this.hardwaresRepository = this.database.getRepository("hardwares");
  }

  public async getByAccountId(accountId: string): Promise<Hardwares | null> {
    try {
      return await this.hardwaresRepository.findOne({ where: { accountId } });
    } catch (error) {
      logger.error(`Error fetching hardware for ${accountId}: ${error}`);
      return null;
    }
  }

  public async findByHwid(hwid: string): Promise<Hardwares | null> {
    try {
      return await this.hardwaresRepository.findOne({ where: { hwid } });
    } catch (error) {
      logger.error(`Error fetching hardware by hwid ${hwid}: ${error}`);
      return null;
    }
  }

  public async createOrUpdate(
    record: Partial<Hardwares> & { accountId: string },
  ): Promise<Hardwares | null> {
    try {
      const upsertResult = await this.hardwaresRepository.upsert(record, {
        conflictPaths: ["accountId"],
      });
      return upsertResult.generatedMaps[0] as Hardwares;
    } catch (error) {
      logger.error(`Error creating/updating hardware: ${error}`);
      return null;
    }
  }

  public async setBannedByAccount(accountId: string, banned: boolean): Promise<boolean> {
    try {
      const result = await this.hardwaresRepository
        .createQueryBuilder()
        .update(Hardwares)
        .set({ isBanned: banned })
        .where("accountId = :accountId", { accountId })
        .execute();

      return result.affected !== undefined && result.affected > 0;
    } catch (error) {
      logger.error(`Error updating hardware ban for ${accountId}: ${error}`);
      return false;
    }
  }
}
