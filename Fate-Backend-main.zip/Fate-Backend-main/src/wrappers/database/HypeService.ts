import { In, type Repository } from "typeorm";
import { Hype } from "../../tables/hype";
import type Database from "../Database.wrapper";
import { logger } from "../..";

export default class HypeService {
  private hypeRepository: Repository<Hype>;

  constructor(private database: Database) {
    this.hypeRepository = this.database.getRepository("hype");
  }

  public async create(season: number) {
    const divisions = [
      { name: `Arena_S${season}_Division1`, min: 0, max: 499 },
      { name: `Arena_S${season}_Division2`, min: 500, max: 999 },
      { name: `Arena_S${season}_Division3`, min: 1000, max: 1499 },
      { name: `Arena_S${season}_Division4`, min: 1500, max: 1999 },
      { name: `Arena_S${season}_Division5`, min: 2000, max: 2499 },
      { name: `Arena_S${season}_Division6`, min: 2500, max: 2999 },
      { name: `Arena_S${season}_Division7`, min: 3000, max: "9007199254740991" },
    ];

    const hypeEntities = divisions.map(({ name, min, max }, index) => ({
      name,
      minimum_required_hype: min,
      division: index + 1,
      maximum_required_hype: max.toString(),
    }));

    const existingEntities = await this.hypeRepository.find({
      where: { name: In(hypeEntities.filter((x) => x.name).map((x) => x.name)) },
    });
    if (existingEntities.length > 0) return;

    await this.hypeRepository.save(hypeEntities);
  }

  public async getAll(): Promise<Hype[]> {
    try {
      const allHypes = await this.hypeRepository.find();
      return allHypes;
    } catch (error) {
      void logger.error(`Failed to getAll:${error}`);
      throw error;
    }
  }

  public async update(newData: Partial<Hype[]>) {
    const allExistingTokens = await this.hypeRepository.find();

    allExistingTokens.forEach((token) => {
      const newDataItem = newData.find((item) => item !== undefined && item.name === token.name);
      if (newDataItem) {
        token.minimum_required_hype = newDataItem.minimum_required_hype;
        token.division = newDataItem.division;
        token.maximum_required_hype = newDataItem.maximum_required_hype;
      }
    });

    await this.hypeRepository.save(allExistingTokens);
  }
}
