import { Repository, UpdateQueryBuilder } from "typeorm";
import Database from "../Database.wrapper";
import { logger } from "../..";
import { MatchmakingKeys } from "../../tables/matchmakingkeys";

export default class MatchmakingKeysService {
  private matchmakingKeysRepository: Repository<MatchmakingKeys>;

  constructor(private database: Database) {
    this.matchmakingKeysRepository = this.database.getRepository("matchmaking_key");
  }

  public async findById(id: string): Promise<MatchmakingKeys | null> {
    try {
      const matchmakingKey = await this.matchmakingKeysRepository
        .createQueryBuilder("matchmaking_key")
        .where("matchmaking_key.id = :id", { id })
        .getOne();

      return matchmakingKey || null;
    } catch (error) {
      logger.error(`Error finding matchmaking key: ${error}`);
      return null;
    }
  }

  public async findByInteraction(interaction: string): Promise<MatchmakingKeys | null> {
    try {
      const matchmakingKey = await this.matchmakingKeysRepository
        .createQueryBuilder("matchmaking_key")
        .where("matchmaking_key.interaction = :interaction", { interaction })
        .getOne();

      return matchmakingKey || null;
    } catch (error) {
      logger.error(`Error finding matchmaking key by interaction: ${error}`);
      return null;
    }
  }

  public async findByKey(key: string): Promise<MatchmakingKeys | null> {
    try {
      const matchmakingKey = await this.matchmakingKeysRepository
        .createQueryBuilder("matchmaking_key")
        .where("matchmaking_key.key = :key", { key })
        .getOne();

      return matchmakingKey || null;
    } catch (error) {
      logger.error(`Error finding matchmaking key by key: ${error}`);
      return null;
    }
  }

  public async findAll(): Promise<MatchmakingKeys[]> {
    try {
      const matchmakingKeysList = await this.matchmakingKeysRepository
        .createQueryBuilder("matchmaking_key")
        .getMany();

      return matchmakingKeysList;
    } catch (error) {
      logger.error(`Error finding all matchmaking keys: ${error}`);
      return [];
    }
  }

  public async create(matchmakingKey: Partial<MatchmakingKeys>): Promise<MatchmakingKeys | null> {
    try {
      const newMatchmakingKey = this.matchmakingKeysRepository.create(matchmakingKey);
      await this.matchmakingKeysRepository.save(newMatchmakingKey);
      return newMatchmakingKey;
    } catch (error) {
      logger.error(`Error creating matchmaking key: ${error}`);
      return null;
    }
  }

  public async delete(id: string): Promise<boolean> {
    try {
      const matchmakingKey = await this.matchmakingKeysRepository.findOne({ where: { id } });
      if (!matchmakingKey) return false;

      const result = await this.matchmakingKeysRepository.delete({ id });
      return result.affected === 1;
    } catch (error) {
      logger.error(`Error deleting matchmaking key: ${error}`);
      return false;
    }
  }

  public async update(id: string, updateData: Partial<MatchmakingKeys>): Promise<boolean> {
    try {
      const queryBuilder: UpdateQueryBuilder<MatchmakingKeys> = this.matchmakingKeysRepository
        .createQueryBuilder()
        .update(MatchmakingKeys)
        .set(updateData as any)
        .where("id = :id", { id });

      const result = await queryBuilder.execute();

      if (result.affected === 0) {
        logger.error(`No rows updated for matchmaking key ${id}.`);
        return false;
      }

      return true;
    } catch (error) {
      logger.error(`Error updating matchmaking key: ${error}`);
      return false;
    }
  }
}
