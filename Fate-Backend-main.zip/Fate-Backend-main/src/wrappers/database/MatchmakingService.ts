import { Repository, UpdateQueryBuilder } from "typeorm";
import Database from "../Database.wrapper";
import { logger } from "../..";
import { Matchmaking } from "../../tables/matchmaking";

export default class MatchmakingService {
  private matchmakingRepository: Repository<Matchmaking>;

  constructor(private database: Database) {
    this.matchmakingRepository = this.database.getRepository("matchmaking");
  }

  public async findById(id: string): Promise<Matchmaking | null> {
    try {
      const matchmaking = await this.matchmakingRepository
        .createQueryBuilder("matchmaking")
        .where("matchmaking.id = :id", { id })
        .getOne();

      return matchmaking || null;
    } catch (error) {
      logger.error(`Error finding matchmaking: ${error}`);
      return null;
    }
  }

  public async findByKey(key: string): Promise<Matchmaking | null> {
    try {
      const matchmaking = await this.matchmakingRepository
        .createQueryBuilder("matchmaking")
        .where("matchmaking.key = :key", { key })
        .getOne();

      return matchmaking || null;
    } catch (error) {
      logger.error(`Error finding matchmaking by key: ${error}`);
      return null;
    }
  }

  public async findAll(): Promise<Matchmaking[]> {
    try {
      const matchmakingList = await this.matchmakingRepository
        .createQueryBuilder("matchmaking")
        .getMany();

      return matchmakingList;
    } catch (error) {
      logger.error(`Error finding all matchmaking entries: ${error}`);
      return [];
    }
  }

  public async create(matchmaking: Partial<Matchmaking>): Promise<Matchmaking | null> {
    try {
      const newMatchmaking = this.matchmakingRepository.create(matchmaking);
      await this.matchmakingRepository.save(newMatchmaking);
      return newMatchmaking;
    } catch (error) {
      logger.error(`Error creating matchmaking: ${error}`);
      return null;
    }
  }

  public async delete(id: string): Promise<boolean> {
    try {
      const matchmaking = await this.matchmakingRepository.findOne({ where: { id } });
      if (!matchmaking) return false;

      const result = await this.matchmakingRepository.delete({ id });
      return result.affected === 1;
    } catch (error) {
      logger.error(`Error deleting matchmaking: ${error}`);
      return false;
    }
  }

  public async update(id: string, updateData: Partial<Matchmaking>): Promise<boolean> {
    try {
      const queryBuilder: UpdateQueryBuilder<Matchmaking> = this.matchmakingRepository
        .createQueryBuilder()
        .update(Matchmaking)
        .set(updateData as any)
        .where("id = :id", { id });

      const result = await queryBuilder.execute();

      if (result.affected === 0) {
        logger.error(`No rows updated for matchmaking ${id}.`);
        return false;
      }

      return true;
    } catch (error) {
      logger.error(`Error updating matchmaking: ${error}`);
      return false;
    }
  }
}
