import { Repository, UpdateQueryBuilder } from "typeorm";
import Database from "../Database.wrapper";
import { logger } from "../..";
import { Queue, QueueStatus } from "../../tables/matchmaking/queue";

export default class QueueService {
  private queueRepository: Repository<Queue>;

  constructor(private database: Database) {
    this.queueRepository = this.database.getRepository("queues");
  }

  public async findById(id: string): Promise<Queue | null> {
    try {
      const queue = await this.queueRepository
        .createQueryBuilder("queue")
        .where("queue.id = :id", { id })
        .getOne();
      return queue || null;
    } catch (error) {
      logger.error(`Error finding queue: ${error}`);
      return null;
    }
  }

  public async updateByPlayerId(playerId: string, updateData: Partial<Queue>): Promise<boolean> {
    try {
      const result = await this.queueRepository
        .createQueryBuilder()
        .update(Queue)
        .set(updateData as any)
        .where("playerId = :playerId", { playerId })
        .execute();

      if (result.affected === 0) {
        logger.error(`No rows updated for queue with playerId ${playerId}.`);
        return false;
      }

      return true;
    } catch (error) {
      logger.error(`Error updating queue by playerId: ${error}`);
      return false;
    }
  }

  public async findByPlayerId(playerId: string): Promise<Queue | null> {
    try {
      const queue = await this.queueRepository
        .createQueryBuilder("queue")
        .where("queue.playerId = :playerId", { playerId })
        .getOne();
      return queue || null;
    } catch (error) {
      logger.error(`Error finding queue by playerId: ${error}`);
      return null;
    }
  }

  public async findByTicketId(ticketId: string): Promise<Queue | null> {
    try {
      const queue = await this.queueRepository
        .createQueryBuilder("queue")
        .where("queue.ticketId = :ticketId", { ticketId })
        .getOne();
      return queue || null;
    } catch (error) {
      logger.error(`Error finding queue by ticketId: ${error}`);
      return null;
    }
  }

  public async findQueuedPlayers(
    playlist: string,
    region: string,
    customKey: string = "none",
    season: number = 1,
  ): Promise<Queue[]> {
    try {
      return await this.queueRepository
        .createQueryBuilder("queue")
        .where("queue.playlist = :playlist", { playlist })
        .andWhere("queue.region = :region", { region })
        .andWhere("queue.customKey = :customKey", { customKey })
        .andWhere("queue.season = :season", { season })
        .andWhere("queue.status IN (:...statuses)", {
          statuses: [QueueStatus.QUEUED, QueueStatus.WAITING],
        })
        .orderBy("queue.joinedAt", "ASC")
        .getMany();
    } catch (error) {
      logger.error(`Error finding queued players: ${error}`);
      return [];
    }
  }

  public async findAll(): Promise<Queue[]> {
    try {
      return await this.queueRepository.createQueryBuilder("queue").getMany();
    } catch (error) {
      logger.error(`Error finding all queues: ${error}`);
      return [];
    }
  }

  public async create(queue: Partial<Queue>): Promise<Queue | null> {
    try {
      const newQueue = this.queueRepository.create(queue);
      await this.queueRepository.save(newQueue);
      return newQueue;
    } catch (error) {
      logger.error(`Error creating queue: ${error}`);
      return null;
    }
  }

  public async delete(id: string): Promise<boolean> {
    try {
      const result = await this.queueRepository.delete({ id });
      return result.affected === 1;
    } catch (error) {
      logger.error(`Error deleting queue: ${error}`);
      return false;
    }
  }

  public async deleteByPlayerId(playerId: string): Promise<boolean> {
    try {
      const result = await this.queueRepository.delete({ playerId });
      return result.affected === 1;
    } catch (error) {
      logger.error(`Error deleting queue by playerId: ${error}`);
      return false;
    }
  }

  public async update(id: string, updateData: Partial<Queue>): Promise<boolean> {
    try {
      const result = await this.queueRepository
        .createQueryBuilder()
        .update(Queue)
        .set(updateData as any)
        .where("id = :id", { id })
        .execute();
      return result.affected !== 0;
    } catch (error) {
      logger.error(`Error updating queue: ${error}`);
      return false;
    }
  }

  public async countQueuedPlayers(
    playlist: string,
    region: string,
    customKey: string = "none",
    season: number = 1,
  ): Promise<number> {
    try {
      return await this.queueRepository
        .createQueryBuilder("queue")
        .where("queue.playlist = :playlist", { playlist })
        .andWhere("queue.region = :region", { region })
        .andWhere("queue.customKey = :customKey", { customKey })
        .andWhere("queue.season = :season", { season })
        .andWhere("queue.status = :status", { status: QueueStatus.QUEUED })
        .getCount();
    } catch (error) {
      logger.error(`Error counting queued players: ${error}`);
      return 0;
    }
  }
}
