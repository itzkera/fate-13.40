import { Repository, UpdateQueryBuilder } from "typeorm";
import Database from "../Database.wrapper";
import { logger } from "../..";
import { Server, ServerRegion, ServerStatus } from "../../tables/matchmaking/servers";

export default class ServerService {
  private serverRepository: Repository<Server>;

  constructor(private database: Database) {
    this.serverRepository = this.database.getRepository("servers");
  }

  public async findById(id: string): Promise<Server | null> {
    try {
      const server = await this.serverRepository
        .createQueryBuilder("server")
        .where("server.id = :id", { id })
        .getOne();
      return server || null;
    } catch (error) {
      logger.error(`Error finding server: ${error}`);
      return null;
    }
  }

  public async findByServerId(serverId: string): Promise<Server | null> {
    try {
      const server = await this.serverRepository
        .createQueryBuilder("server")
        .where("server.serverId = :serverId", { serverId })
        .getOne();
      return server || null;
    } catch (error) {
      logger.error(`Error finding server by serverId: ${error}`);
      return null;
    }
  }

  public async findByRegion(region: ServerRegion): Promise<Server[]> {
    try {
      return await this.serverRepository
        .createQueryBuilder("server")
        .where("server.region = :region", { region })
        .getMany();
    } catch (error) {
      logger.error(`Error finding servers by region: ${error}`);
      return [];
    }
  }

  public async findByStatus(status: ServerStatus): Promise<Server[]> {
    try {
      return await this.serverRepository
        .createQueryBuilder("server")
        .where("server.status = :status", { status })
        .getMany();
    } catch (error) {
      logger.error(`Error finding servers by status: ${error}`);
      return [];
    }
  }

  public async findAvailableServers(
    region: ServerRegion,
    playlist: string,
    customKey: string = "none",
    season: number = 1,
  ): Promise<Server[]> {
    try {
      const freshAfter = new Date(Date.now() - Number(Bun.env.GAMESERVER_STALE_MS ?? 120_000));
      return await this.serverRepository
        .createQueryBuilder("server")
        .where("server.region = :region", { region })
        .andWhere("server.playlist = :playlist", { playlist })
        .andWhere("server.customKey = :customKey", { customKey })
        .andWhere("server.season = :season", { season })
        .andWhere("server.status = :status", { status: ServerStatus.ONLINE })
        .andWhere("server.currentPlayers < server.maxPlayers")
        .andWhere("server.updatedAt > :freshAfter", { freshAfter })
        .orderBy("server.currentPlayers", "ASC")
        .getMany();
    } catch (error) {
      logger.error(`Error finding available servers: ${error}`);
      return [];
    }
  }

  public async findAll(): Promise<Server[]> {
    try {
      return await this.serverRepository.createQueryBuilder("server").getMany();
    } catch (error) {
      logger.error(`Error finding all servers: ${error}`);
      return [];
    }
  }

  public async create(server: Partial<Server>): Promise<Server | null> {
    try {
      const newServer = this.serverRepository.create(server);
      await this.serverRepository.save(newServer);
      return newServer;
    } catch (error) {
      logger.error(`Error creating server: ${error}`);
      return null;
    }
  }

  public async delete(id: string): Promise<boolean> {
    try {
      const result = await this.serverRepository.delete({ id });
      return result.affected === 1;
    } catch (error) {
      logger.error(`Error deleting server: ${error}`);
      return false;
    }
  }

  public async update(id: string, updateData: Partial<Server>): Promise<boolean> {
    try {
      const result = await this.serverRepository
        .createQueryBuilder()
        .update(Server)
        .set({ ...updateData, updatedAt: new Date() } as any)
        .where("id = :id", { id })
        .execute();
      return result.affected !== 0;
    } catch (error) {
      logger.error(`Error updating server: ${error}`);
      return false;
    }
  }

  public async incrementPlayers(serverId: string): Promise<boolean> {
    try {
      const result = await this.serverRepository
        .createQueryBuilder()
        .update(Server)
        .set({ currentPlayers: () => "currentPlayers + 1", updatedAt: new Date() } as any)
        .where("serverId = :serverId", { serverId })
        .execute();
      return result.affected === 1;
    } catch (error) {
      logger.error(`Error incrementing players: ${error}`);
      return false;
    }
  }

  public async decrementPlayers(serverId: string): Promise<boolean> {
    try {
      const result = await this.serverRepository
        .createQueryBuilder()
        .update(Server)
        .set({ currentPlayers: () => "GREATEST(currentPlayers - 1, 0)", updatedAt: new Date() } as any)
        .where("serverId = :serverId", { serverId })
        .execute();
      return result.affected === 1;
    } catch (error) {
      logger.error(`Error decrementing players: ${error}`);
      return false;
    }
  }
}
