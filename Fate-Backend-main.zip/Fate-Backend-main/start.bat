@echo off
title euphoria
cls
echo backend should take ~2 mins to start up when you drop db (and on first run)
echo this is because it's inserting quest rewards, etc
call bun install
call bun run src/index.ts
pause